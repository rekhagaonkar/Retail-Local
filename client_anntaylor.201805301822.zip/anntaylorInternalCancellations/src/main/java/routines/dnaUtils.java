package routines;

import java.text.DecimalFormatSymbols;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author georgi.n.nikolov
 *
 */
public class dnaUtils {
	private static Map<String, Object> globalMap = new HashMap<String, Object>();

	public static void setGlobalMap(Map<String, Object> globalMap) {
		dnaUtils.globalMap = globalMap;
	}

	/**
	 * <b>getGlobalVariable</b>: gets variables from the global map. 
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br /> 
	 * {param} string("SYSTEM_NAME") input: The string that is the key in the
	 * map.
	 * 
	 */
	public static String getGlobalVariable(String key) {
		return String.valueOf(globalMap.get(key));
	}

	/**
	 * <b>getDateString</b>: gets the date part from a file name. Doesn't work if the
	 * file name contains extra digits. <br /><br />
	 * 
	 * 
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined 
	 * <br />
	 * {param} string("FILE_NAME") input: The string that represents the file
	 * name
	 * 
	 */
	public static String getDateString(String fileName) {
		Pattern pattern = Pattern.compile("\\d+");
		Matcher matcher = pattern.matcher(fileName);
		StringBuilder builtDate = new StringBuilder();

		while (matcher.find()) {
			String date = matcher.group();
			if (date.length() >= 8) {
				return date;
			} else {
				builtDate.append(date);
			}

		}
		return builtDate.toString();
	}

	/**
	 * <b>isValidString</b>: Evaluates either if a String has any value different than
	 * null and an empty String. If the value is only blanks the function will
	 * return false. <br /><br />
	 * 
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be evaluated
	 * 
	 */
	public static boolean isValidString(String value) {
		return value != null && !value.trim().isEmpty() ? true : false;
	}

	/**
	 * <b>normalizeString</b>: Takes a String value as input and trims is. The function only
	 * checks if the input value is null, if it isn't it trims it.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * normalized.
	 * 
	 */
	public static String normalizeString(String value) {
		return value == null ? null : value.trim();
	}

	/**
	 * <b>validNormalized</b>: Takes a String value as input, checks if it's valid, i.e not a
	 * null or a String with only blanks in it. If the value is valid it is then
	 * normalized, else it returns an empty String.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * normalized.
	 * 
	 */
	public static String validNormalized(String value) {
		return isValidString(value) ? normalizeString(value) : "";
	}

	/**
	 * <b>getDateRef</b>: Measures the time difference between the given date and
	 * 01/01/1970.
	 * <br /><br />
	 * {talendTypes} Integer
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} date("VALUE") input: The date that needs to be measured.
	 * 
	 */
	public static Integer getDateRef(Date date) {
		return Integer.valueOf(Long.toString(TalendDate.diffDateIgnoreDST(date,
				TalendDate.parseDate("yyyyMMdd", "19700101"), "dd")));
	}

	/**
	 * <b>isStringNumeric</b>: Receives a String value that has to be checked
	 * if it is a valid number. The function takes into account locales 
	 * and positive/negative numbers. 
	 * <br /><br />
	 * {talendTypes} boolean | Boolean
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * checked.
	 * 
	 */
	public static boolean isStringNumeric(String value) {
		DecimalFormatSymbols currentLocaleSymbols = DecimalFormatSymbols
				.getInstance();
		char localeMinusSign = currentLocaleSymbols.getMinusSign();

		if (value == null || value.isEmpty() || (!Character.isDigit(value.charAt(0)) && value.charAt(0) != localeMinusSign))
			return false;

		boolean isDecimalSeparatorFound = false;
		char localeDecimalSeparator = currentLocaleSymbols
				.getDecimalSeparator();

		for (char c : value.substring(1).toCharArray()) {
			if (!Character.isDigit(c)) {
				if (c == localeDecimalSeparator && !isDecimalSeparatorFound) {
					isDecimalSeparatorFound = true;
					continue;
				}
				return false;
			}
		}
		return true;
	}

	/**
	 * <b>toFloat</b>: Takes a String value as input parses it as float.
	 * <br /><br />
	 * {talendTypes} float | Float
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * parsed.
	 * 
	 */
	public static float toFloat(String value) {
		return isStringNumeric(value) ? Float.parseFloat(value.replaceAll(",",
				"")) : 0f;
	}

	/**
	 * <b>toDouble</b>: Takes a String value as input parses it as double.
	 * <br /><br />
	 * {talendTypes} double | Double
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * parsed.
	 * 
	 */
	public static double toDouble(String value) {
		return isStringNumeric(value) ? Double.parseDouble(value.replaceAll(
				",", "")) : 0;
	}

	/**
	 * <b>toInt</b>: Takes a String value as input parses it as int.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * parsed.
	 * 
	 */
	public static int toInt(String value) {
		return isStringNumeric(value) ? Integer.parseInt(value.replaceAll(",",
				"")) : 0;
	}
	
	/**
	 * <b>toLong</b>: Takes a String value as input parses it as long.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * parsed.
	 * 
	 */
	public static long toLong(String value) {
		return isStringNumeric(value) ? Long.parseLong(value.replaceAll(",",
				"")) : 0;
	}
	
	/**
	 * <b>toBoolean</b>: Takes a String value as input parses it as boolean.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string value that should be
	 * parsed.
	 * 
	 */
	public static boolean toBoolean(String value) {
		for(Boolean b : Boolean.values()) {
			if (b.equals(value)) 
				return true;
		}
		return false;
	}
	
	enum Boolean {
		TRUE("true"),
		Y("Y"),
		Y1("y"),
		YES("yes"),
		ONE("1");
		
		Boolean(String value) {
		}
	}

	
	/**
	 * <b>splitIntoParts</b>: Split a string into parts and return the array.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string to split.
	 * {param} string("DELIMITER") input: Delimiter for the String.
	 * 
	 */
	public static String[] splitIntoParts(String value, String delimiter) {
		if (isValidString(value)) {
			return null;
		}
		
		return value.split(delimiter);
	}
	
	/**
	 * <b>getElement</b>: Returns the nth element of a String array, where
	 * n is the index parameter.
	 * <br /><br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string array to extract from.
	 * {param} int(INDEX) input: The number of the element in the array.
	 */
	public static String getElement(String[] array, int index) {
		if(array.length < index) {
			return null;
		}
		
		return array[index];
	}

	/**
	 * <b>getPartOfString</b>:  Returns the nth element of a String array 
	 * that is split by delimiter, where n is the index parameter.
	 * <br />
	 * {talendTypes} String
	 * <br />
	 * {Category} User Defined
	 * <br />
	 * {param} string("VALUE") input: The string to extract from.
	 * {param} string("DELIMITER") input: Delimiter for the String.
	 * {param} int(INDEX) input: The number of the element in the array.
	 * 
	 */
	public static String getPartOfString(String value, String delimiter,
			int index) {
		if (!isValidString(value)) {
			return null;
		}

		if (value.split(delimiter).length <= index) {
			return null;
		}

		
		return value.split(delimiter)[index];
	}
}
