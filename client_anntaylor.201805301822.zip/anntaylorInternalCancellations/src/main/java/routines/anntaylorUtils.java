package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * Integer | Integer, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, Integer, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class anntaylorUtils {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
	public static Integer getOnePageVisits(Integer All_Visits, String Pages, String Previous_Page, String Next_Pages) {
		Integer result = null;
		
		result = ((Pages != null && !Pages.isEmpty()) && (Previous_Page  == null || Previous_Page.isEmpty()) && (Next_Pages == null || Next_Pages.isEmpty()) ) ? All_Visits  : null;
		
		return result;
	}
	
	public static Integer getPageViews(Integer Page_Views, String Pages, String Previous_Page, String Next_Pages) {
		Integer result = null;
		
		result = ((Pages != null && !Pages.isEmpty()) && (Previous_Page  == null || Previous_Page.isEmpty()) ) ? Page_Views   : null;
		
		return result;
	}
	
	public static Integer getEntryPageViews(Integer Page_Views, String Pages, String Previous_Page, String Next_Pages) {
		Integer result = null;
		
		result = ((Pages == null || Pages.isEmpty()) && (Previous_Page  != null && !Previous_Page.isEmpty()) && (Next_Pages == null || Next_Pages.isEmpty()) ) ? Page_Views  : null;
		
		return result;
	}
	
	public static Integer getExitPageViews(Integer Page_Views, String Pages, String Previous_Page, String Next_Pages) {
		Integer result = null;
		
		result = ((Pages == null || Pages.isEmpty()) && (Previous_Page  == null || Previous_Page.isEmpty()) && (Next_Pages != null && !Next_Pages.isEmpty()) ) ? Page_Views   : null;
		
		return result;
	}
	
	
	public static String getSiteCat2(String Mobile_Device_Type)
	{
		if(Mobile_Device_Type.equals("Mobile Phone"))	return "Mobile";
			else if(Mobile_Device_Type.equals("Tablet"))	return "Tablet";
					else return "Desktop";
	}
	
	
	public static String getPageType(String pageType,String numberOfResults)
	{
		switch(pageType)
		{
			case "Category Page": return "Category Page";
			case "Homepage": return "Home";
			case "Product Details": return "Product Details Page";
			case "at:store locator": return "Store locator";
			case "Checkout": return "Checkout";
			case "My Account": return "My Account";
			case "Order Confirmation": return "Checkout: Confirmation";
			case "Shopping Bag": return "Cart";
			case "at:404error": return "Error";
			case "Search": if(numberOfResults.equals("0")||numberOfResults.equals("zero"))	return "Search Unsuccessful";
							else return "Search Results";
			case "CC PreApprove Modal": return "Other";
			case "at:sitemap": return "Other";
			case "Credit Card App": return "Other";
			case "customer service": return "Other";
			case "Details Page": return "Other";
			case "Editorial Page": return "Other";
			case "International": return "Other";
			case "Landing Page": return "Other";
			default: return "";
		}
	}
	
	
	public static String getProductId(String productId)
	{
		return productId.replaceFirst("^0+(?!$)", "");
	}
	
	public static String getPromoClass(String promo, String orderPromo) {
		
		//if (promo.equals(orderPromo)) {
		//	return "{{O}}";
		//}
		
		if (promo.toLowerCase().contains("ship")) {
			return "{{S}}";
		}
		
		return "{{P}}";
	}
	
}




