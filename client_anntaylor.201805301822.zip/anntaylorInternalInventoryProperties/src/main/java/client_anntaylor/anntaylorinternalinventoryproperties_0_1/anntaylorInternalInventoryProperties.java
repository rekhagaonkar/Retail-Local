
package client_anntaylor.anntaylorinternalinventoryproperties_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.Relational;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendString;
import routines.StringHandling;
import routines.TalendDate;
import routines.anntaylorUtils;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of EtlcCallbackDSMCollection_1_tJava_2
	//import java.util.List;

	//the import part of EtlcCallbackDSMCollection_1_tJava_3
	//import java.util.List;

	//the import part of EtlcCallbackDSMCollection_1_tJava_4
	//import java.util.List;

	//the import part of EtlcCallbackDSMCollection_1_tJava_1
	//import java.util.List;

	//the import part of DSMFileWriter_1_tLibraryLoad_1
	//import java.util.List;

	//the import part of DSMFileWriter_1_tLibraryLoad_2
	//import java.util.List;

	//the import part of DSMFileWriter_1_tLibraryLoad_3
	//import java.util.List;

	//the import part of DSMFileWriter_1_tLibraryLoad_4
	//import java.util.List;

	//the import part of DSMFileWriter_1_tLibraryLoad_5
	//import java.util.List;

	//the import part of DSMFileWriter_1_tLibraryLoad_6
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: anntaylorInternalInventoryProperties Purpose: Process Ann Taylor Inventory Properties files and produce fragInventorySaleLocation_core & more<br>
 * Description: Map Ann Taylor Inventory Properties Location daily zip files to fragInventorySaleLocation_core, fragInventoryFulfilment_core, fragInventoryStockLocation_core <br>
 * @author Cholakov, Lambrin
 * @version 6.2.1.20160704_1411
 * @status 
 */
public class anntaylorInternalInventoryProperties implements TalendJob {
	static {System.setProperty("TalendJob.log", "anntaylorInternalInventoryProperties.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(anntaylorInternalInventoryProperties.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(outputDirectory != null){
				
					this.setProperty("outputDirectory", outputDirectory.toString());
				
			}
			
			if(endDate != null){
				
					String pattern_endDate = "yyyy-MM-dd HH:mm:ss";
					String value_endDate = "";
					String[] parts_endDate = value_endDate.split(";");
					if(parts_endDate.length > 1){
						pattern_endDate = parts_endDate[0];
						this.setProperty("endDate", pattern_endDate + ";" + FormatterUtils.format_Date(endDate, pattern_endDate));
					}else{
						this.setProperty("endDate", FormatterUtils.format_Date(endDate, pattern_endDate));
					}
				
			}
			
			if(maxAllowedRejections != null){
				
					this.setProperty("maxAllowedRejections", maxAllowedRejections.toString());
				
			}
			
			if(controllerFileCallbackUri != null){
				
					this.setProperty("controllerFileCallbackUri", controllerFileCallbackUri.toString());
				
			}
			
			if(controllerDetailsCallbackUri != null){
				
					this.setProperty("controllerDetailsCallbackUri", controllerDetailsCallbackUri.toString());
				
			}
			
			if(useCallback != null){
				
					this.setProperty("useCallback", useCallback.toString());
				
			}
			
			if(useDsm != null){
				
					this.setProperty("useDsm", useDsm.toString());
				
			}
			
			if(dsmEndPoint != null){
				
					this.setProperty("dsmEndPoint", dsmEndPoint.toString());
				
			}
			
			if(clientId != null){
				
					this.setProperty("clientId", clientId.toString());
				
			}
			
			if(path != null){
				
					this.setProperty("path", path.toString());
				
			}
			
			if(file != null){
				
					this.setProperty("file", file.toString());
				
			}
			
			if(inputDirectory != null){
				
					this.setProperty("inputDirectory", inputDirectory.toString());
				
			}
			
		}

public String outputDirectory;
public String getOutputDirectory(){
	return this.outputDirectory;
}
public java.util.Date endDate;
public java.util.Date getEndDate(){
	return this.endDate;
}
public Integer maxAllowedRejections;
public Integer getMaxAllowedRejections(){
	return this.maxAllowedRejections;
}
public String controllerFileCallbackUri;
public String getControllerFileCallbackUri(){
	return this.controllerFileCallbackUri;
}
public String controllerDetailsCallbackUri;
public String getControllerDetailsCallbackUri(){
	return this.controllerDetailsCallbackUri;
}
public Boolean useCallback;
public Boolean getUseCallback(){
	return this.useCallback;
}
public Boolean useDsm;
public Boolean getUseDsm(){
	return this.useDsm;
}
public String dsmEndPoint;
public String getDsmEndPoint(){
	return this.dsmEndPoint;
}
public String clientId;
public String getClientId(){
	return this.clientId;
}
public String path;
public String getPath(){
	return this.path;
}
public String file;
public String getFile(){
	return this.file;
}
public String inputDirectory;
public String getInputDirectory(){
	return this.inputDirectory;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "anntaylorInternalInventoryProperties";
	private final String projectName = "CLIENT_ANNTAYLOR";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	


	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils EtlcCallbackDSMCollection_1_tLogCatcher_1 = new LogCatcherUtils();
	LogCatcherUtils EtlcCallbackDSMCollection_1_tLogCatcher_2 = new LogCatcherUtils();

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				anntaylorInternalInventoryProperties.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(anntaylorInternalInventoryProperties.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				EtlcCallbackDSMCollection_1_tLogCatcher_2.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				EtlcCallbackDSMCollection_1_tLogCatcher_2Process(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void DSMRetailerFileFetch_1_tFileExist_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMRetailerFileFetch_1_tFileExist_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tFileList_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tDSMFileManager_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tSleep_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tSleep_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tContextDump_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tLogRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tSetGlobalVar_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tSetGlobalVar_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tREST_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
						try {
							
							
								errorCode = null;
								EtlcCallbackDSMCollection_1_tWarn_1Process(globalMap);
								if (!"failure".equals(status)) {
									status = "end";
								}
								

						} catch (Exception e) {
							e.printStackTrace();
						}
						
					EtlcCallbackDSMCollection_1_tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tREST_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tREST_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
						try {
							
							
								errorCode = null;
								EtlcCallbackDSMCollection_1_tWarn_2Process(globalMap);
								if (!"failure".equals(status)) {
									status = "end";
								}
								

						} catch (Exception e) {
							e.printStackTrace();
						}
						
					EtlcCallbackDSMCollection_1_tREST_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tLogRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tREST_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tDie_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tDie_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSleep_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSleep_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileDelete_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileDelete_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMRetailerFileFetch_1_tFileExist_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMRetailerFileFetch_1_tFileExist_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMRetailerFileFetch_1_tFileFetch_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMRetailerFileFetch_1_tFileFetch_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMRetailerFileFetch_1_tDie_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMRetailerFileFetch_1_tDie_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tLibraryLoad_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMFileWriter_1_tLibraryLoad_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tLibraryLoad_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMFileWriter_1_tLibraryLoad_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tLibraryLoad_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMFileWriter_1_tLibraryLoad_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tLibraryLoad_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMFileWriter_1_tLibraryLoad_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tLibraryLoad_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMFileWriter_1_tLibraryLoad_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMFileWriter_1_tLibraryLoad_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					DSMFileWriter_1_tLibraryLoad_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tContextDump_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tFilterRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tREST_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
						try {
							
							
								errorCode = null;
								EtlcCallbackDSMCollection_1_tRowGenerator_1Process(globalMap);
								if (!"failure".equals(status)) {
									status = "end";
								}
								

						} catch (Exception e) {
							e.printStackTrace();
						}
						
					EtlcCallbackDSMCollection_1_tREST_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tRowGenerator_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tRowGenerator_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tDie_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tDie_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tContextDump_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tLogCatcher_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tLogCatcher_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_EtlcCallbackDSMCollection_1_row7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAdvancedHash_EtlcCallbackDSMCollection_1_row8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					EtlcCallbackDSMCollection_1_tContextDump_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void DSMRetailerFileFetch_1_tFileExist_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tSleep_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tContextDump_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tSetGlobalVar_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tREST_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tREST_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tDie_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSleep_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMRetailerFileFetch_1_tFileExist_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMRetailerFileFetch_1_tFileFetch_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMRetailerFileFetch_1_tDie_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMFileWriter_1_tLibraryLoad_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMFileWriter_1_tLibraryLoad_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMFileWriter_1_tLibraryLoad_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMFileWriter_1_tLibraryLoad_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMFileWriter_1_tLibraryLoad_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void DSMFileWriter_1_tLibraryLoad_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tContextDump_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tREST_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tRowGenerator_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tDie_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tContextDump_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void EtlcCallbackDSMCollection_1_tLogCatcher_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
		




	
public void DSMRetailerFileFetch_1_tFileExist_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMRetailerFileFetch_1_tFileExist_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_1 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMRetailerFileFetch_1_tFileExist_1", false);
		start_Hash.put("DSMRetailerFileFetch_1_tFileExist_1", System.currentTimeMillis());
		
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_1";

	
		int tos_count_DSMRetailerFileFetch_1_tFileExist_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileExist_1 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMRetailerFileFetch_1_tFileExist_1 = new StringBuilder();
            log4jParamters_DSMRetailerFileFetch_1_tFileExist_1.append("Parameters:");
                    log4jParamters_DSMRetailerFileFetch_1_tFileExist_1.append("FILE_NAME" + " = " + "context.inputDirectory");
                log4jParamters_DSMRetailerFileFetch_1_tFileExist_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileExist_1 - "  + log4jParamters_DSMRetailerFileFetch_1_tFileExist_1 );

 



/**
 * [DSMRetailerFileFetch_1_tFileExist_1 begin ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_1 main ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_1";

	


				final StringBuffer log4jSb_DSMRetailerFileFetch_1_tFileExist_1 = new StringBuffer();
			

java.io.File file_DSMRetailerFileFetch_1_tFileExist_1 = new java.io.File(context.inputDirectory);
if (!file_DSMRetailerFileFetch_1_tFileExist_1.exists()) {
    globalMap.put("DSMRetailerFileFetch_1_tFileExist_1_EXISTS",false);
    log.info("DSMRetailerFileFetch_1_tFileExist_1 - Directory or file : " + file_DSMRetailerFileFetch_1_tFileExist_1.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("DSMRetailerFileFetch_1_tFileExist_1_EXISTS",true);
    log.info("DSMRetailerFileFetch_1_tFileExist_1 - Directory or file : " + file_DSMRetailerFileFetch_1_tFileExist_1.getAbsolutePath() + " exists.");
}

globalMap.put("DSMRetailerFileFetch_1_tFileExist_1_FILENAME",context.inputDirectory);


 


	tos_count_DSMRetailerFileFetch_1_tFileExist_1++;

/**
 * [DSMRetailerFileFetch_1_tFileExist_1 main ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_1 end ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_1";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileExist_1 - "  + "Done." );

ok_Hash.put("DSMRetailerFileFetch_1_tFileExist_1", true);
end_Hash.put("DSMRetailerFileFetch_1_tFileExist_1", System.currentTimeMillis());

   			if (!((Boolean)globalMap.get("DSMRetailerFileFetch_1_tFileExist_1_EXISTS")) && context.useDsm) {
   				
    			DSMRetailerFileFetch_1_tFileExist_2Process(globalMap);
   			}

			
   			if (((Boolean)globalMap.get("DSMRetailerFileFetch_1_tFileExist_1_EXISTS")) && context.useDsm) {
   				
    			DSMRetailerFileFetch_1_tDie_1Process(globalMap);
   			}

			



/**
 * [DSMRetailerFileFetch_1_tFileExist_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:DSMRetailerFileFetch_1_tFileExist_1:OnSubjobOk (TRIGGER_OUTPUT_1)", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							tFileInputDelimited_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_1 finally ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_1";

	

 



/**
 * [DSMRetailerFileFetch_1_tFileExist_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMRetailerFileFetch_1_tFileExist_1_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String itemid;

				public String getItemid () {
					return this.itemid;
				}
				
			    public Integer attributeNumber;

				public Integer getAttributeNumber () {
					return this.attributeNumber;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.itemid = readString(dis);
					
						this.attributeNumber = readInteger(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemid,dos);
					
					// Integer
				
						writeInteger(this.attributeNumber,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemid="+itemid);
		sb.append(",attributeNumber="+String.valueOf(attributeNumber));
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemid);
            			}
            		
        			sb.append("|");
        		
        				if(attributeNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attributeNumber);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String itemid;

				public String getItemid () {
					return this.itemid;
				}
				
			    public Integer attributeNumber;

				public Integer getAttributeNumber () {
					return this.attributeNumber;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.itemid = readString(dis);
					
						this.attributeNumber = readInteger(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemid,dos);
					
					// Integer
				
						writeInteger(this.attributeNumber,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemid="+itemid);
		sb.append(",attributeNumber="+String.valueOf(attributeNumber));
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemid);
            			}
            		
        			sb.append("|");
        		
        				if(attributeNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attributeNumber);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}
				
			    public Integer attributeNumber;

				public Integer getAttributeNumber () {
					return this.attributeNumber;
				}
				
			    public Integer value;

				public Integer getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
						this.attributeNumber = readInteger(dis);
					
						this.value = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Integer
				
						writeInteger(this.attributeNumber,dos);
					
					// Integer
				
						writeInteger(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",attributeNumber="+String.valueOf(attributeNumber));
		sb.append(",value="+String.valueOf(value));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(attributeNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attributeNumber);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtAggregateRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}
				
			    public Integer attributeNumber;

				public Integer getAttributeNumber () {
					return this.attributeNumber;
				}
				
			    public Integer value;

				public Integer getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
						this.attributeNumber = readInteger(dis);
					
						this.value = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Integer
				
						writeInteger(this.attributeNumber,dos);
					
					// Integer
				
						writeInteger(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",attributeNumber="+String.valueOf(attributeNumber));
		sb.append(",value="+String.valueOf(value));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(attributeNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attributeNumber);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class fragInventorySaleLocationStruct implements routines.system.IPersistableRow<fragInventorySaleLocationStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date date;

				public java.util.Date getDate () {
					return this.date;
				}
				
			    public String channel;

				public String getChannel () {
					return this.channel;
				}
				
			    public String siteCat1;

				public String getSiteCat1 () {
					return this.siteCat1;
				}
				
			    public String productId;

				public String getProductId () {
					return this.productId;
				}
				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}
				
			    public String seller;

				public String getSeller () {
					return this.seller;
				}
				
			    public java.util.Date publishDate;

				public java.util.Date getPublishDate () {
					return this.publishDate;
				}
				
			    public String isMarkdown;

				public String getIsMarkdown () {
					return this.isMarkdown;
				}
				
			    public String isDiscontinued;

				public String getIsDiscontinued () {
					return this.isDiscontinued;
				}
				
			    public String isCore;

				public String getIsCore () {
					return this.isCore;
				}
				
			    public java.util.Date seasonStartDate;

				public java.util.Date getSeasonStartDate () {
					return this.seasonStartDate;
				}
				
			    public java.util.Date seasonStartEnd;

				public java.util.Date getSeasonStartEnd () {
					return this.seasonStartEnd;
				}
				
			    public String isSellable;

				public String getIsSellable () {
					return this.isSellable;
				}
				
			    public Boolean isPreorder;

				public Boolean getIsPreorder () {
					return this.isPreorder;
				}
				
			    public Boolean isBackover;

				public Boolean getIsBackover () {
					return this.isBackover;
				}
				
			    public Float currrentPrice;

				public Float getCurrrentPrice () {
					return this.currrentPrice;
				}
				
			    public Float currentPriceExTax;

				public Float getCurrentPriceExTax () {
					return this.currentPriceExTax;
				}
				
			    public Float fullPrice;

				public Float getFullPrice () {
					return this.fullPrice;
				}
				
			    public Float fullPriceExTax;

				public Float getFullPriceExTax () {
					return this.fullPriceExTax;
				}
				
			    public String currency;

				public String getCurrency () {
					return this.currency;
				}
				
			    public Integer preorderUnits;

				public Integer getPreorderUnits () {
					return this.preorderUnits;
				}
				
			    public Integer backorderUnits;

				public Integer getBackorderUnits () {
					return this.backorderUnits;
				}
				
			    public Integer waitlistUnits;

				public Integer getWaitlistUnits () {
					return this.waitlistUnits;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.date = readDate(dis);
					
					this.channel = readString(dis);
					
					this.siteCat1 = readString(dis);
					
					this.productId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.seller = readString(dis);
					
					this.publishDate = readDate(dis);
					
					this.isMarkdown = readString(dis);
					
					this.isDiscontinued = readString(dis);
					
					this.isCore = readString(dis);
					
					this.seasonStartDate = readDate(dis);
					
					this.seasonStartEnd = readDate(dis);
					
					this.isSellable = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.isPreorder = null;
           				} else {
           			    	this.isPreorder = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.isBackover = null;
           				} else {
           			    	this.isBackover = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.currrentPrice = null;
           				} else {
           			    	this.currrentPrice = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.currentPriceExTax = null;
           				} else {
           			    	this.currentPriceExTax = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.fullPrice = null;
           				} else {
           			    	this.fullPrice = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.fullPriceExTax = null;
           				} else {
           			    	this.fullPriceExTax = dis.readFloat();
           				}
					
					this.currency = readString(dis);
					
						this.preorderUnits = readInteger(dis);
					
						this.backorderUnits = readInteger(dis);
					
						this.waitlistUnits = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date,dos);
					
					// String
				
						writeString(this.channel,dos);
					
					// String
				
						writeString(this.siteCat1,dos);
					
					// String
				
						writeString(this.productId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.seller,dos);
					
					// java.util.Date
				
						writeDate(this.publishDate,dos);
					
					// String
				
						writeString(this.isMarkdown,dos);
					
					// String
				
						writeString(this.isDiscontinued,dos);
					
					// String
				
						writeString(this.isCore,dos);
					
					// java.util.Date
				
						writeDate(this.seasonStartDate,dos);
					
					// java.util.Date
				
						writeDate(this.seasonStartEnd,dos);
					
					// String
				
						writeString(this.isSellable,dos);
					
					// Boolean
				
						if(this.isPreorder == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.isPreorder);
		            	}
					
					// Boolean
				
						if(this.isBackover == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.isBackover);
		            	}
					
					// Float
				
						if(this.currrentPrice == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.currrentPrice);
		            	}
					
					// Float
				
						if(this.currentPriceExTax == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.currentPriceExTax);
		            	}
					
					// Float
				
						if(this.fullPrice == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.fullPrice);
		            	}
					
					// Float
				
						if(this.fullPriceExTax == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.fullPriceExTax);
		            	}
					
					// String
				
						writeString(this.currency,dos);
					
					// Integer
				
						writeInteger(this.preorderUnits,dos);
					
					// Integer
				
						writeInteger(this.backorderUnits,dos);
					
					// Integer
				
						writeInteger(this.waitlistUnits,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("date="+String.valueOf(date));
		sb.append(",channel="+channel);
		sb.append(",siteCat1="+siteCat1);
		sb.append(",productId="+productId);
		sb.append(",itemId="+itemId);
		sb.append(",seller="+seller);
		sb.append(",publishDate="+String.valueOf(publishDate));
		sb.append(",isMarkdown="+isMarkdown);
		sb.append(",isDiscontinued="+isDiscontinued);
		sb.append(",isCore="+isCore);
		sb.append(",seasonStartDate="+String.valueOf(seasonStartDate));
		sb.append(",seasonStartEnd="+String.valueOf(seasonStartEnd));
		sb.append(",isSellable="+isSellable);
		sb.append(",isPreorder="+String.valueOf(isPreorder));
		sb.append(",isBackover="+String.valueOf(isBackover));
		sb.append(",currrentPrice="+String.valueOf(currrentPrice));
		sb.append(",currentPriceExTax="+String.valueOf(currentPriceExTax));
		sb.append(",fullPrice="+String.valueOf(fullPrice));
		sb.append(",fullPriceExTax="+String.valueOf(fullPriceExTax));
		sb.append(",currency="+currency);
		sb.append(",preorderUnits="+String.valueOf(preorderUnits));
		sb.append(",backorderUnits="+String.valueOf(backorderUnits));
		sb.append(",waitlistUnits="+String.valueOf(waitlistUnits));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(date);
            			}
            		
        			sb.append("|");
        		
        				if(channel == null){
        					sb.append("<null>");
        				}else{
            				sb.append(channel);
            			}
            		
        			sb.append("|");
        		
        				if(siteCat1 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(siteCat1);
            			}
            		
        			sb.append("|");
        		
        				if(productId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(productId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(seller == null){
        					sb.append("<null>");
        				}else{
            				sb.append(seller);
            			}
            		
        			sb.append("|");
        		
        				if(publishDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(publishDate);
            			}
            		
        			sb.append("|");
        		
        				if(isMarkdown == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isMarkdown);
            			}
            		
        			sb.append("|");
        		
        				if(isDiscontinued == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isDiscontinued);
            			}
            		
        			sb.append("|");
        		
        				if(isCore == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isCore);
            			}
            		
        			sb.append("|");
        		
        				if(seasonStartDate == null){
        					sb.append("<null>");
        				}else{
            				sb.append(seasonStartDate);
            			}
            		
        			sb.append("|");
        		
        				if(seasonStartEnd == null){
        					sb.append("<null>");
        				}else{
            				sb.append(seasonStartEnd);
            			}
            		
        			sb.append("|");
        		
        				if(isSellable == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isSellable);
            			}
            		
        			sb.append("|");
        		
        				if(isPreorder == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isPreorder);
            			}
            		
        			sb.append("|");
        		
        				if(isBackover == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isBackover);
            			}
            		
        			sb.append("|");
        		
        				if(currrentPrice == null){
        					sb.append("<null>");
        				}else{
            				sb.append(currrentPrice);
            			}
            		
        			sb.append("|");
        		
        				if(currentPriceExTax == null){
        					sb.append("<null>");
        				}else{
            				sb.append(currentPriceExTax);
            			}
            		
        			sb.append("|");
        		
        				if(fullPrice == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fullPrice);
            			}
            		
        			sb.append("|");
        		
        				if(fullPriceExTax == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fullPriceExTax);
            			}
            		
        			sb.append("|");
        		
        				if(currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(currency);
            			}
            		
        			sb.append("|");
        		
        				if(preorderUnits == null){
        					sb.append("<null>");
        				}else{
            				sb.append(preorderUnits);
            			}
            		
        			sb.append("|");
        		
        				if(backorderUnits == null){
        					sb.append("<null>");
        				}else{
            				sb.append(backorderUnits);
            			}
            		
        			sb.append("|");
        		
        				if(waitlistUnits == null){
        					sb.append("<null>");
        				}else{
            				sb.append(waitlistUnits);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(fragInventorySaleLocationStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class fragInventoryFulfilmentStruct implements routines.system.IPersistableRow<fragInventoryFulfilmentStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date date;

				public java.util.Date getDate () {
					return this.date;
				}
				
			    public String channel;

				public String getChannel () {
					return this.channel;
				}
				
			    public String site;

				public String getSite () {
					return this.site;
				}
				
			    public String locationId;

				public String getLocationId () {
					return this.locationId;
				}
				
			    public String productId;

				public String getProductId () {
					return this.productId;
				}
				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}
				
			    public String seller;

				public String getSeller () {
					return this.seller;
				}
				
			    public Double unitCostUpLift;

				public Double getUnitCostUpLift () {
					return this.unitCostUpLift;
				}
				
			    public String currencyCode;

				public String getCurrencyCode () {
					return this.currencyCode;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.date = readDate(dis);
					
					this.channel = readString(dis);
					
					this.site = readString(dis);
					
					this.locationId = readString(dis);
					
					this.productId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.seller = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.unitCostUpLift = null;
           				} else {
           			    	this.unitCostUpLift = dis.readDouble();
           				}
					
					this.currencyCode = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date,dos);
					
					// String
				
						writeString(this.channel,dos);
					
					// String
				
						writeString(this.site,dos);
					
					// String
				
						writeString(this.locationId,dos);
					
					// String
				
						writeString(this.productId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.seller,dos);
					
					// Double
				
						if(this.unitCostUpLift == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.unitCostUpLift);
		            	}
					
					// String
				
						writeString(this.currencyCode,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("date="+String.valueOf(date));
		sb.append(",channel="+channel);
		sb.append(",site="+site);
		sb.append(",locationId="+locationId);
		sb.append(",productId="+productId);
		sb.append(",itemId="+itemId);
		sb.append(",seller="+seller);
		sb.append(",unitCostUpLift="+String.valueOf(unitCostUpLift));
		sb.append(",currencyCode="+currencyCode);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(date);
            			}
            		
        			sb.append("|");
        		
        				if(channel == null){
        					sb.append("<null>");
        				}else{
            				sb.append(channel);
            			}
            		
        			sb.append("|");
        		
        				if(site == null){
        					sb.append("<null>");
        				}else{
            				sb.append(site);
            			}
            		
        			sb.append("|");
        		
        				if(locationId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationId);
            			}
            		
        			sb.append("|");
        		
        				if(productId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(productId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(seller == null){
        					sb.append("<null>");
        				}else{
            				sb.append(seller);
            			}
            		
        			sb.append("|");
        		
        				if(unitCostUpLift == null){
        					sb.append("<null>");
        				}else{
            				sb.append(unitCostUpLift);
            			}
            		
        			sb.append("|");
        		
        				if(currencyCode == null){
        					sb.append("<null>");
        				}else{
            				sb.append(currencyCode);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(fragInventoryFulfilmentStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class fragInventoryStockLocationStruct implements routines.system.IPersistableRow<fragInventoryStockLocationStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date date;

				public java.util.Date getDate () {
					return this.date;
				}
				
			    public String locationId;

				public String getLocationId () {
					return this.locationId;
				}
				
			    public String productId;

				public String getProductId () {
					return this.productId;
				}
				
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}
				
			    public String seller;

				public String getSeller () {
					return this.seller;
				}
				
			    public Boolean isSupplierOwned;

				public Boolean getIsSupplierOwned () {
					return this.isSupplierOwned;
				}
				
			    public Boolean isNonStockable;

				public Boolean getIsNonStockable () {
					return this.isNonStockable;
				}
				
			    public Integer unitsInStock;

				public Integer getUnitsInStock () {
					return this.unitsInStock;
				}
				
			    public Integer leadTimeDays;

				public Integer getLeadTimeDays () {
					return this.leadTimeDays;
				}
				
			    public Float unitCost;

				public Float getUnitCost () {
					return this.unitCost;
				}
				
			    public String currency;

				public String getCurrency () {
					return this.currency;
				}
				
			    public Boolean isReorderable;

				public Boolean getIsReorderable () {
					return this.isReorderable;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.date = readDate(dis);
					
					this.locationId = readString(dis);
					
					this.productId = readString(dis);
					
					this.itemId = readString(dis);
					
					this.seller = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.isSupplierOwned = null;
           				} else {
           			    	this.isSupplierOwned = dis.readBoolean();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.isNonStockable = null;
           				} else {
           			    	this.isNonStockable = dis.readBoolean();
           				}
					
						this.unitsInStock = readInteger(dis);
					
						this.leadTimeDays = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.unitCost = null;
           				} else {
           			    	this.unitCost = dis.readFloat();
           				}
					
					this.currency = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.isReorderable = null;
           				} else {
           			    	this.isReorderable = dis.readBoolean();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.date,dos);
					
					// String
				
						writeString(this.locationId,dos);
					
					// String
				
						writeString(this.productId,dos);
					
					// String
				
						writeString(this.itemId,dos);
					
					// String
				
						writeString(this.seller,dos);
					
					// Boolean
				
						if(this.isSupplierOwned == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.isSupplierOwned);
		            	}
					
					// Boolean
				
						if(this.isNonStockable == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.isNonStockable);
		            	}
					
					// Integer
				
						writeInteger(this.unitsInStock,dos);
					
					// Integer
				
						writeInteger(this.leadTimeDays,dos);
					
					// Float
				
						if(this.unitCost == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.unitCost);
		            	}
					
					// String
				
						writeString(this.currency,dos);
					
					// Boolean
				
						if(this.isReorderable == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.isReorderable);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("date="+String.valueOf(date));
		sb.append(",locationId="+locationId);
		sb.append(",productId="+productId);
		sb.append(",itemId="+itemId);
		sb.append(",seller="+seller);
		sb.append(",isSupplierOwned="+String.valueOf(isSupplierOwned));
		sb.append(",isNonStockable="+String.valueOf(isNonStockable));
		sb.append(",unitsInStock="+String.valueOf(unitsInStock));
		sb.append(",leadTimeDays="+String.valueOf(leadTimeDays));
		sb.append(",unitCost="+String.valueOf(unitCost));
		sb.append(",currency="+currency);
		sb.append(",isReorderable="+String.valueOf(isReorderable));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(date);
            			}
            		
        			sb.append("|");
        		
        				if(locationId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(locationId);
            			}
            		
        			sb.append("|");
        		
        				if(productId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(productId);
            			}
            		
        			sb.append("|");
        		
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(seller == null){
        					sb.append("<null>");
        				}else{
            				sb.append(seller);
            			}
            		
        			sb.append("|");
        		
        				if(isSupplierOwned == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isSupplierOwned);
            			}
            		
        			sb.append("|");
        		
        				if(isNonStockable == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isNonStockable);
            			}
            		
        			sb.append("|");
        		
        				if(unitsInStock == null){
        					sb.append("<null>");
        				}else{
            				sb.append(unitsInStock);
            			}
            		
        			sb.append("|");
        		
        				if(leadTimeDays == null){
        					sb.append("<null>");
        				}else{
            				sb.append(leadTimeDays);
            			}
            		
        			sb.append("|");
        		
        				if(unitCost == null){
        					sb.append("<null>");
        				}else{
            				sb.append(unitCost);
            			}
            		
        			sb.append("|");
        		
        				if(currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(currency);
            			}
            		
        			sb.append("|");
        		
        				if(isReorderable == null){
        					sb.append("<null>");
        				}else{
            				sb.append(isReorderable);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(fragInventoryStockLocationStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class itemAttributesStruct implements routines.system.IPersistableRow<itemAttributesStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String itemId;

				public String getItemId () {
					return this.itemId;
				}
				
			    public Integer attributeNumber;

				public Integer getAttributeNumber () {
					return this.attributeNumber;
				}
				
			    public Integer value;

				public Integer getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.itemId = readString(dis);
					
						this.attributeNumber = readInteger(dis);
					
						this.value = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.itemId,dos);
					
					// Integer
				
						writeInteger(this.attributeNumber,dos);
					
					// Integer
				
						writeInteger(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("itemId="+itemId);
		sb.append(",attributeNumber="+String.valueOf(attributeNumber));
		sb.append(",value="+String.valueOf(value));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(itemId == null){
        					sb.append("<null>");
        				}else{
            				sb.append(itemId);
            			}
            		
        			sb.append("|");
        		
        				if(attributeNumber == null){
        					sb.append("<null>");
        				}else{
            				sb.append(attributeNumber);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(itemAttributesStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date DATE;

				public java.util.Date getDATE () {
					return this.DATE;
				}
				
			    public String CHANNEL;

				public String getCHANNEL () {
					return this.CHANNEL;
				}
				
			    public String SITE;

				public String getSITE () {
					return this.SITE;
				}
				
			    public String LOCATION_ID;

				public String getLOCATION_ID () {
					return this.LOCATION_ID;
				}
				
			    public String PRODUCT_ID;

				public String getPRODUCT_ID () {
					return this.PRODUCT_ID;
				}
				
			    public String SKU;

				public String getSKU () {
					return this.SKU;
				}
				
			    public String MARKDOWN;

				public String getMARKDOWN () {
					return this.MARKDOWN;
				}
				
			    public Float CURRENT_PRICE;

				public Float getCURRENT_PRICE () {
					return this.CURRENT_PRICE;
				}
				
			    public Float FULL_PRICE;

				public Float getFULL_PRICE () {
					return this.FULL_PRICE;
				}
				
			    public String CURRENCY;

				public String getCURRENCY () {
					return this.CURRENCY;
				}
				
			    public Float STOCK_UNITS;

				public Float getSTOCK_UNITS () {
					return this.STOCK_UNITS;
				}
				
			    public Float UNIT_COST;

				public Float getUNIT_COST () {
					return this.UNIT_COST;
				}
				
			    public String CURRENCY_UNIT_COST;

				public String getCURRENCY_UNIT_COST () {
					return this.CURRENCY_UNIT_COST;
				}
				
			    public Float ONLINE_PRICE;

				public Float getONLINE_PRICE () {
					return this.ONLINE_PRICE;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.DATE = readDate(dis);
					
					this.CHANNEL = readString(dis);
					
					this.SITE = readString(dis);
					
					this.LOCATION_ID = readString(dis);
					
					this.PRODUCT_ID = readString(dis);
					
					this.SKU = readString(dis);
					
					this.MARKDOWN = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.CURRENT_PRICE = null;
           				} else {
           			    	this.CURRENT_PRICE = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.FULL_PRICE = null;
           				} else {
           			    	this.FULL_PRICE = dis.readFloat();
           				}
					
					this.CURRENCY = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.STOCK_UNITS = null;
           				} else {
           			    	this.STOCK_UNITS = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.UNIT_COST = null;
           				} else {
           			    	this.UNIT_COST = dis.readFloat();
           				}
					
					this.CURRENCY_UNIT_COST = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ONLINE_PRICE = null;
           				} else {
           			    	this.ONLINE_PRICE = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.DATE,dos);
					
					// String
				
						writeString(this.CHANNEL,dos);
					
					// String
				
						writeString(this.SITE,dos);
					
					// String
				
						writeString(this.LOCATION_ID,dos);
					
					// String
				
						writeString(this.PRODUCT_ID,dos);
					
					// String
				
						writeString(this.SKU,dos);
					
					// String
				
						writeString(this.MARKDOWN,dos);
					
					// Float
				
						if(this.CURRENT_PRICE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.CURRENT_PRICE);
		            	}
					
					// Float
				
						if(this.FULL_PRICE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.FULL_PRICE);
		            	}
					
					// String
				
						writeString(this.CURRENCY,dos);
					
					// Float
				
						if(this.STOCK_UNITS == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.STOCK_UNITS);
		            	}
					
					// Float
				
						if(this.UNIT_COST == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.UNIT_COST);
		            	}
					
					// String
				
						writeString(this.CURRENCY_UNIT_COST,dos);
					
					// Float
				
						if(this.ONLINE_PRICE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.ONLINE_PRICE);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("DATE="+String.valueOf(DATE));
		sb.append(",CHANNEL="+CHANNEL);
		sb.append(",SITE="+SITE);
		sb.append(",LOCATION_ID="+LOCATION_ID);
		sb.append(",PRODUCT_ID="+PRODUCT_ID);
		sb.append(",SKU="+SKU);
		sb.append(",MARKDOWN="+MARKDOWN);
		sb.append(",CURRENT_PRICE="+String.valueOf(CURRENT_PRICE));
		sb.append(",FULL_PRICE="+String.valueOf(FULL_PRICE));
		sb.append(",CURRENCY="+CURRENCY);
		sb.append(",STOCK_UNITS="+String.valueOf(STOCK_UNITS));
		sb.append(",UNIT_COST="+String.valueOf(UNIT_COST));
		sb.append(",CURRENCY_UNIT_COST="+CURRENCY_UNIT_COST);
		sb.append(",ONLINE_PRICE="+String.valueOf(ONLINE_PRICE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(DATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DATE);
            			}
            		
        			sb.append("|");
        		
        				if(CHANNEL == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CHANNEL);
            			}
            		
        			sb.append("|");
        		
        				if(SITE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SITE);
            			}
            		
        			sb.append("|");
        		
        				if(LOCATION_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOCATION_ID);
            			}
            		
        			sb.append("|");
        		
        				if(PRODUCT_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PRODUCT_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SKU == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SKU);
            			}
            		
        			sb.append("|");
        		
        				if(MARKDOWN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MARKDOWN);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENT_PRICE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENT_PRICE);
            			}
            		
        			sb.append("|");
        		
        				if(FULL_PRICE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FULL_PRICE);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENCY);
            			}
            		
        			sb.append("|");
        		
        				if(STOCK_UNITS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(STOCK_UNITS);
            			}
            		
        			sb.append("|");
        		
        				if(UNIT_COST == null){
        					sb.append("<null>");
        				}else{
            				sb.append(UNIT_COST);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENCY_UNIT_COST == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENCY_UNIT_COST);
            			}
            		
        			sb.append("|");
        		
        				if(ONLINE_PRICE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ONLINE_PRICE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();
fragInventorySaleLocationStruct fragInventorySaleLocation = new fragInventorySaleLocationStruct();
fragInventoryFulfilmentStruct fragInventoryFulfilment = new fragInventoryFulfilmentStruct();
fragInventoryStockLocationStruct fragInventoryStockLocation = new fragInventoryStockLocationStruct();
itemAttributesStruct itemAttributes = new itemAttributesStruct();
row3Struct row3 = new row3Struct();
row4Struct row4 = new row4Struct();
row5Struct row5 = new row5Struct();





	
	/**
	 * [tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_1", false);
		start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_1";

	
		int tos_count_tFileOutputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileOutputDelimited_1 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_1.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_1.append("USESTREAM" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FILENAME" + " = " + "context.outputDirectory + \"/fragInventorySaleLocation_core_1_is35.\" + TalendDate.formatDate(\"yyyyMMdd\", context.endDate)");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FIELDSEPARATOR" + " = " + "\"\\t\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("APPEND" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("CREATE" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("SPLIT" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("DELETE_EMPTYFILE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + log4jParamters_tFileOutputDelimited_1 );

String fileName_tFileOutputDelimited_1 = "";
    fileName_tFileOutputDelimited_1 = (new java.io.File(context.outputDirectory + "/fragInventorySaleLocation_core_1_is35." + TalendDate.formatDate("yyyyMMdd", context.endDate))).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_1 = null;
    String extension_tFileOutputDelimited_1 = null;
    String directory_tFileOutputDelimited_1 = null;
    if((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        }
        directory_tFileOutputDelimited_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_1 = true;
    java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
    globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
            int nb_line_tFileOutputDelimited_1 = 0;
            int splitEvery_tFileOutputDelimited_1 = 1000;
            int splitedFileNo_tFileOutputDelimited_1 = 0;
            int currentRow_tFileOutputDelimited_1 = 0;

            final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */"\t"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
                        if(!dir_tFileOutputDelimited_1.exists()) {
                                log.info("tFileOutputDelimited_1 - Creating directory '" + dir_tFileOutputDelimited_1.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimited_1.mkdirs();
                                log.info("tFileOutputDelimited_1 - The directory '"+ dir_tFileOutputDelimited_1.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_1 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
                        if(fileToDelete_tFileOutputDelimited_1.exists()) {
                            fileToDelete_tFileOutputDelimited_1.delete();
                        }
                        outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false),"UTF-8"));
                                    if(filetFileOutputDelimited_1.length()==0){
                                        outtFileOutputDelimited_1.write("date");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("channel");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("siteCat1");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("productId");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("itemId");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("seller");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("publishDate");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("isMarkdown");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("isDiscontinued");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("isCore");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("seasonStartDate");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("seasonStartEnd");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("isSellable");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("isPreorder");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("isBackover");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("currrentPrice");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("currentPriceExTax");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("fullPrice");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("fullPriceExTax");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("currency");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("preorderUnits");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("backorderUnits");
                                            outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.write("waitlistUnits");
                                        outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
                                        outtFileOutputDelimited_1.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

 



/**
 * [tFileOutputDelimited_1 begin ] stop
 */




	
	/**
	 * [tFileOutputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_2", false);
		start_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_2";

	
		int tos_count_tFileOutputDelimited_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_2 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileOutputDelimited_2 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_2.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_2.append("USESTREAM" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("FILENAME" + " = " + "context.outputDirectory + \"/fragInventoryFulfilment_core_1.\" + TalendDate.formatDate(\"yyyyMMdd\", context.endDate)");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("FIELDSEPARATOR" + " = " + "\"\\t\"");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("APPEND" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("CREATE" + " = " + "true");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("SPLIT" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("DELETE_EMPTYFILE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_2 - "  + log4jParamters_tFileOutputDelimited_2 );

String fileName_tFileOutputDelimited_2 = "";
    fileName_tFileOutputDelimited_2 = (new java.io.File(context.outputDirectory + "/fragInventoryFulfilment_core_1." + TalendDate.formatDate("yyyyMMdd", context.endDate))).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_2 = null;
    String extension_tFileOutputDelimited_2 = null;
    String directory_tFileOutputDelimited_2 = null;
    if((fileName_tFileOutputDelimited_2.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_2.lastIndexOf(".") < fileName_tFileOutputDelimited_2.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
            extension_tFileOutputDelimited_2 = "";
        } else {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("."));
            extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_2.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(0, fileName_tFileOutputDelimited_2.lastIndexOf("."));
            extension_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2.substring(fileName_tFileOutputDelimited_2.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_2 = fileName_tFileOutputDelimited_2;
            extension_tFileOutputDelimited_2 = "";
        }
        directory_tFileOutputDelimited_2 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_2 = true;
    java.io.File filetFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
    globalMap.put("tFileOutputDelimited_2_FILE_NAME",fileName_tFileOutputDelimited_2);
            int nb_line_tFileOutputDelimited_2 = 0;
            int splitEvery_tFileOutputDelimited_2 = 1000;
            int splitedFileNo_tFileOutputDelimited_2 = 0;
            int currentRow_tFileOutputDelimited_2 = 0;

            final String OUT_DELIM_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:FIELDSEPARATOR */"\t"/** End field tFileOutputDelimited_2:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_2 = /** Start field tFileOutputDelimited_2:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_2:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_2 != null && directory_tFileOutputDelimited_2.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_2 = new java.io.File(directory_tFileOutputDelimited_2);
                        if(!dir_tFileOutputDelimited_2.exists()) {
                                log.info("tFileOutputDelimited_2 - Creating directory '" + dir_tFileOutputDelimited_2.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimited_2.mkdirs();
                                log.info("tFileOutputDelimited_2 - The directory '"+ dir_tFileOutputDelimited_2.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_2 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_2 = new java.io.File(fileName_tFileOutputDelimited_2);
                        if(fileToDelete_tFileOutputDelimited_2.exists()) {
                            fileToDelete_tFileOutputDelimited_2.delete();
                        }
                        outtFileOutputDelimited_2 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_2, false),"UTF-8"));
                                    if(filetFileOutputDelimited_2.length()==0){
                                        outtFileOutputDelimited_2.write("date");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("channel");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("site");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("locationId");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("productId");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("itemId");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("seller");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("unitCostUpLift");
                                            outtFileOutputDelimited_2.write(OUT_DELIM_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.write("currencyCode");
                                        outtFileOutputDelimited_2.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_2);
                                        outtFileOutputDelimited_2.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_2", outtFileOutputDelimited_2);
resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

 



/**
 * [tFileOutputDelimited_2 begin ] stop
 */




	
	/**
	 * [tFileOutputDelimited_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_3", false);
		start_Hash.put("tFileOutputDelimited_3", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_3";

	
		int tos_count_tFileOutputDelimited_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_3 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileOutputDelimited_3 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_3.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_3.append("USESTREAM" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("FILENAME" + " = " + "context.outputDirectory + \"/fragInventoryStockLocation_core_1.\" + TalendDate.formatDate(\"yyyyMMdd\", context.endDate)");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("FIELDSEPARATOR" + " = " + "\"\\t\"");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("APPEND" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("CREATE" + " = " + "true");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("SPLIT" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("DELETE_EMPTYFILE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_3 - "  + log4jParamters_tFileOutputDelimited_3 );

String fileName_tFileOutputDelimited_3 = "";
    fileName_tFileOutputDelimited_3 = (new java.io.File(context.outputDirectory + "/fragInventoryStockLocation_core_1." + TalendDate.formatDate("yyyyMMdd", context.endDate))).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_3 = null;
    String extension_tFileOutputDelimited_3 = null;
    String directory_tFileOutputDelimited_3 = null;
    if((fileName_tFileOutputDelimited_3.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_3.lastIndexOf(".") < fileName_tFileOutputDelimited_3.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3;
            extension_tFileOutputDelimited_3 = "";
        } else {
            fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(0, fileName_tFileOutputDelimited_3.lastIndexOf("."));
            extension_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(fileName_tFileOutputDelimited_3.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(0, fileName_tFileOutputDelimited_3.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_3.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(0, fileName_tFileOutputDelimited_3.lastIndexOf("."));
            extension_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3.substring(fileName_tFileOutputDelimited_3.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_3 = fileName_tFileOutputDelimited_3;
            extension_tFileOutputDelimited_3 = "";
        }
        directory_tFileOutputDelimited_3 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_3 = true;
    java.io.File filetFileOutputDelimited_3 = new java.io.File(fileName_tFileOutputDelimited_3);
    globalMap.put("tFileOutputDelimited_3_FILE_NAME",fileName_tFileOutputDelimited_3);
            int nb_line_tFileOutputDelimited_3 = 0;
            int splitEvery_tFileOutputDelimited_3 = 1000;
            int splitedFileNo_tFileOutputDelimited_3 = 0;
            int currentRow_tFileOutputDelimited_3 = 0;

            final String OUT_DELIM_tFileOutputDelimited_3 = /** Start field tFileOutputDelimited_3:FIELDSEPARATOR */"\t"/** End field tFileOutputDelimited_3:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_3 = /** Start field tFileOutputDelimited_3:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_3:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_3 != null && directory_tFileOutputDelimited_3.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_3 = new java.io.File(directory_tFileOutputDelimited_3);
                        if(!dir_tFileOutputDelimited_3.exists()) {
                                log.info("tFileOutputDelimited_3 - Creating directory '" + dir_tFileOutputDelimited_3.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimited_3.mkdirs();
                                log.info("tFileOutputDelimited_3 - The directory '"+ dir_tFileOutputDelimited_3.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_3 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_3 = new java.io.File(fileName_tFileOutputDelimited_3);
                        if(fileToDelete_tFileOutputDelimited_3.exists()) {
                            fileToDelete_tFileOutputDelimited_3.delete();
                        }
                        outtFileOutputDelimited_3 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_3, false),"UTF-8"));
                                    if(filetFileOutputDelimited_3.length()==0){
                                        outtFileOutputDelimited_3.write("date");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("locationId");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("productId");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("itemId");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("seller");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("isSupplierOwned");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("isNonStockable");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("unitsInStock");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("leadTimeDays");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("unitCost");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("currency");
                                            outtFileOutputDelimited_3.write(OUT_DELIM_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.write("isReorderable");
                                        outtFileOutputDelimited_3.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_3);
                                        outtFileOutputDelimited_3.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_3", outtFileOutputDelimited_3);
resourceMap.put("nb_line_tFileOutputDelimited_3", nb_line_tFileOutputDelimited_3);

 



/**
 * [tFileOutputDelimited_3 begin ] stop
 */




	
	/**
	 * [tAggregateRow_1_AGGOUT begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGOUT", false);
		start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	
		int tos_count_tAggregateRow_1_AGGOUT = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + "Start to work." );
            StringBuilder log4jParamters_tAggregateRow_1_AGGOUT = new StringBuilder();
            log4jParamters_tAggregateRow_1_AGGOUT.append("Parameters:");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("DESTINATION" + " = " + "tAggregateRow_1");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("itemId")+", INPUT_COLUMN="+("itemId")+"}, {OUTPUT_COLUMN="+("attributeNumber")+", INPUT_COLUMN="+("attributeNumber")+"}]");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="+("value")+", INPUT_COLUMN="+("value")+", IGNORE_NULL="+("true")+", FUNCTION="+("sum")+"}]");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("LIST_DELIMITER" + " = " + "\",\"");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("USE_FINANCIAL_PRECISION" + " = " + "true");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_ULP" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + log4jParamters_tAggregateRow_1_AGGOUT );

// ------------ Seems it is not used

java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap(); 

// ------------

	class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

		public double sd(Double[] data) {
	        final int n = data.length;
        	if (n < 2) {
	            return Double.NaN;
        	}
        	double d1 = 0d;
        	double d2 =0d;
	        
	        for (int i = 0; i < data.length; i++) {
            	d1 += (data[i]*data[i]);
            	d2 += data[i];
        	}
        
	        return Math.sqrt((n*d1 - d2*d2)/n/(n-1));
	    }
	    
		public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		    byte r = (byte) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'short/Short'", "'byte/Byte'"));
		    }
		}
		
		public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		    short r = (short) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'int/Integer'", "'short/Short'"));
		    }
		}
		
		public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		    int r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'long/Long'", "'int/Integer'"));
		    }
		}
		
		public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
		    long r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'long/Long'"));
		    }
		}
		
		public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    float minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
			    }
			}
			
		    if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE) || ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
		    }
		}
		
		public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
		    return "Type overflow when adding " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}
		
		private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
		    return "The double precision is unsufficient to add the value " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}

	} // G_OutBegin_AggR_144

	UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

	

	class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

		private static final int DEFAULT_HASHCODE = 1;
	    private static final int PRIME = 31;
	    private int hashCode = DEFAULT_HASHCODE;
	    public boolean hashCodeDirty = true;

    				String itemId;
    				Integer attributeNumber;
         			Integer value_sum;
        
	    @Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;
		
							result = prime * result + ((this.itemId == null) ? 0 : this.itemId.hashCode());
							
							result = prime * result + ((this.attributeNumber == null) ? 0 : this.attributeNumber.hashCode());
							
	    		this.hashCode = result;
	    		this.hashCodeDirty = false;		
			}
			return this.hashCode;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;
			
							if (this.itemId == null) {
								if (other.itemId != null) 
									return false;
							} else if (!this.itemId.equals(other.itemId)) 
								return false;
						
							if (this.attributeNumber == null) {
								if (other.attributeNumber != null) 
									return false;
							} else if (!this.attributeNumber.equals(other.attributeNumber)) 
								return false;
						
			
			return true;
		}
  
        
	} // G_OutBegin_AggR_100

	AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
	AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
	java.util.Map<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1>();
	

 



/**
 * [tAggregateRow_1_AGGOUT begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + "Start to work." );
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + log4jParamters_tMap_1 );




// ###############################
// # Lookup's keys initialization
		int count_row1_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_fragInventorySaleLocation_tMap_1 = 0;
				
fragInventorySaleLocationStruct fragInventorySaleLocation_tmp = new fragInventorySaleLocationStruct();
				int count_fragInventoryFulfilment_tMap_1 = 0;
				
fragInventoryFulfilmentStruct fragInventoryFulfilment_tmp = new fragInventoryFulfilmentStruct();
				int count_fragInventoryStockLocation_tMap_1 = 0;
				
fragInventoryStockLocationStruct fragInventoryStockLocation_tmp = new fragInventoryStockLocationStruct();
				int count_itemAttributes_tMap_1 = 0;
				
itemAttributesStruct itemAttributes_tmp = new itemAttributesStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
            log4jParamters_tFileInputDelimited_1.append("Parameters:");
                    log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = " + "context.inputDirectory + \"/\" + context.file");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CSV_OPTION" + " = " + "true");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CSVROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ESCAPE_CHAR" + " = " + "\"\"\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("TEXT_ENCLOSURE" + " = " + "\"\"\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("HEADER" + " = " + "1");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = " + "0");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW" + " = " + "true");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = " + "true");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CHECK_DATE" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + log4jParamters_tFileInputDelimited_1 );
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				int footer_tFileInputDelimited_1 = 0;
				int totalLinetFileInputDelimited_1 = 0;
				int limittFileInputDelimited_1 = -1;
				int lastLinetFileInputDelimited_1 = -1;	
				
				char fieldSeparator_tFileInputDelimited_1[] = null;
				
				//support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'. 
				if ( ((String)";").length() > 0 ){
					fieldSeparator_tFileInputDelimited_1 = ((String)";").toCharArray();
				}else {			
					throw new IllegalArgumentException("Field Separator must be assigned a char."); 
				}
			
				char rowSeparator_tFileInputDelimited_1[] = null;
			
				//support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'. 
				if ( ((String)"\n").length() > 0 ){
					rowSeparator_tFileInputDelimited_1 = ((String)"\n").toCharArray();
				}else {
					throw new IllegalArgumentException("Row Separator must be assigned a char."); 
				}
			
				Object filename_tFileInputDelimited_1 = /** Start field tFileInputDelimited_1:FILENAME */context.inputDirectory + "/" + context.file/** End field tFileInputDelimited_1:FILENAME */;		
				com.talend.csv.CSVReader csvReadertFileInputDelimited_1 = null;
	
				try{
					
						String[] rowtFileInputDelimited_1=null;
						int currentLinetFileInputDelimited_1 = 0;
	        			int outputLinetFileInputDelimited_1 = 0;
						try {//TD110 begin
							if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0;
			if(footer_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer shouldn't be bigger than 0.");
			}
		
								csvReadertFileInputDelimited_1=new com.talend.csv.CSVReader((java.io.InputStream)filename_tFileInputDelimited_1, fieldSeparator_tFileInputDelimited_1[0], "UTF-8");
							}else{
								csvReadertFileInputDelimited_1=new com.talend.csv.CSVReader(new java.io.BufferedReader(new java.io.InputStreamReader(
		                		new java.io.FileInputStream(String.valueOf(filename_tFileInputDelimited_1)),"UTF-8")), fieldSeparator_tFileInputDelimited_1[0]);
		        			}
					
					
					csvReadertFileInputDelimited_1.setTrimWhitespace(false);
					if ( (rowSeparator_tFileInputDelimited_1[0] != '\n') && (rowSeparator_tFileInputDelimited_1[0] != '\r') )
	        			csvReadertFileInputDelimited_1.setLineEnd(""+rowSeparator_tFileInputDelimited_1[0]);
						
	        				csvReadertFileInputDelimited_1.setQuoteChar('"');
						
	            				csvReadertFileInputDelimited_1.setEscapeChar(csvReadertFileInputDelimited_1.getQuoteChar());
							      
		
			
						if(footer_tFileInputDelimited_1 > 0){
						for(totalLinetFileInputDelimited_1=0;totalLinetFileInputDelimited_1 < 1; totalLinetFileInputDelimited_1++){
							csvReadertFileInputDelimited_1.readNext();
						}
						csvReadertFileInputDelimited_1.setSkipEmptyRecords(true);
			            while (csvReadertFileInputDelimited_1.readNext()) {
							
								rowtFileInputDelimited_1=csvReadertFileInputDelimited_1.getValues();
								if(!(rowtFileInputDelimited_1.length == 1 && ("\015").equals(rowtFileInputDelimited_1[0]))){//empty line when row separator is '\n'
							
	                
	                		totalLinetFileInputDelimited_1++;
	                
							
								}
							
	                
			            }
	            		int lastLineTemptFileInputDelimited_1 = totalLinetFileInputDelimited_1 - footer_tFileInputDelimited_1   < 0? 0 : totalLinetFileInputDelimited_1 - footer_tFileInputDelimited_1 ;
	            		if(lastLinetFileInputDelimited_1 > 0){
	                		lastLinetFileInputDelimited_1 = lastLinetFileInputDelimited_1 < lastLineTemptFileInputDelimited_1 ? lastLinetFileInputDelimited_1 : lastLineTemptFileInputDelimited_1; 
	            		}else {
	                		lastLinetFileInputDelimited_1 = lastLineTemptFileInputDelimited_1;
	            		}
	         
			          	csvReadertFileInputDelimited_1.close();
				        if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
				 			csvReadertFileInputDelimited_1=new com.talend.csv.CSVReader((java.io.InputStream)filename_tFileInputDelimited_1, fieldSeparator_tFileInputDelimited_1[0], "UTF-8");
		        		}else{
				 			csvReadertFileInputDelimited_1=new com.talend.csv.CSVReader(new java.io.BufferedReader(new java.io.InputStreamReader(
				          	new java.io.FileInputStream(String.valueOf(filename_tFileInputDelimited_1)),"UTF-8")), fieldSeparator_tFileInputDelimited_1[0]);
						}
						csvReadertFileInputDelimited_1.setTrimWhitespace(false);
						if ( (rowSeparator_tFileInputDelimited_1[0] != '\n') && (rowSeparator_tFileInputDelimited_1[0] != '\r') )	
	        				csvReadertFileInputDelimited_1.setLineEnd(""+rowSeparator_tFileInputDelimited_1[0]);
						
							csvReadertFileInputDelimited_1.setQuoteChar('"');
						
	        				csvReadertFileInputDelimited_1.setEscapeChar(csvReadertFileInputDelimited_1.getQuoteChar());
							  
	        		}
	        
			        if(limittFileInputDelimited_1 != 0){
			        	for(currentLinetFileInputDelimited_1=0;currentLinetFileInputDelimited_1 < 1;currentLinetFileInputDelimited_1++){
			        		csvReadertFileInputDelimited_1.readNext();
			        	}
			        }
			        csvReadertFileInputDelimited_1.setSkipEmptyRecords(true);
	        
	    		} catch(java.lang.Exception e) {
					
						throw e;
					
	    		}//TD110 end
	        
			    
			    	log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");
			    
	        	while ( limittFileInputDelimited_1 != 0 && csvReadertFileInputDelimited_1!=null && csvReadertFileInputDelimited_1.readNext() ) { 
	        		rowstate_tFileInputDelimited_1.reset();
	        
		        	rowtFileInputDelimited_1=csvReadertFileInputDelimited_1.getValues();
	        	
					
	        			if(rowtFileInputDelimited_1.length == 1 && ("\015").equals(rowtFileInputDelimited_1[0])){//empty line when row separator is '\n'
	        				continue;
	        			}
					
	        	
	        	
	        		currentLinetFileInputDelimited_1++;
	            
		            if(lastLinetFileInputDelimited_1 > -1 && currentLinetFileInputDelimited_1 > lastLinetFileInputDelimited_1) {
		                break;
	    	        }
	        	    outputLinetFileInputDelimited_1++;
	            	if (limittFileInputDelimited_1 > 0 && outputLinetFileInputDelimited_1 > limittFileInputDelimited_1) {
	                	break;
	            	}  
	                                                                      
					
	    							row1 = null;			
								
								boolean whetherReject_tFileInputDelimited_1 = false;
								row1 = new row1Struct();
								try {			
									
				char fieldSeparator_tFileInputDelimited_1_ListType[] = null;
				//support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'. 
				if ( ((String)";").length() > 0 ){
					fieldSeparator_tFileInputDelimited_1_ListType = ((String)";").toCharArray();
				}else {			
					throw new IllegalArgumentException("Field Separator must be assigned a char."); 
				}
				if(rowtFileInputDelimited_1.length == 1 && ("\015").equals(rowtFileInputDelimited_1[0])){//empty line when row separator is '\n'
					
							row1.DATE = null;
					
							row1.CHANNEL = null;
					
							row1.SITE = null;
					
							row1.LOCATION_ID = null;
					
							row1.PRODUCT_ID = null;
					
							row1.SKU = null;
					
							row1.MARKDOWN = null;
					
							row1.CURRENT_PRICE = null;
					
							row1.FULL_PRICE = null;
					
							row1.CURRENCY = null;
					
							row1.STOCK_UNITS = null;
					
							row1.UNIT_COST = null;
					
							row1.CURRENCY_UNIT_COST = null;
					
							row1.ONLINE_PRICE = null;
					
				}else{
					
					for(int i_tFileInputDelimited_1=0;i_tFileInputDelimited_1<rowtFileInputDelimited_1.length;i_tFileInputDelimited_1++){
						rowtFileInputDelimited_1[i_tFileInputDelimited_1]=rowtFileInputDelimited_1[i_tFileInputDelimited_1].trim();
					}
					
	                int columnIndexWithD_tFileInputDelimited_1 = 0; //Column Index 
	                
						columnIndexWithD_tFileInputDelimited_1 = 0;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
								
									if(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {
									
											row1.DATE = ParserUtils.parseTo_Date(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1], "yyyyMMdd");
										
									
										} catch(java.lang.Exception ex_tFileInputDelimited_1) {
											rowstate_tFileInputDelimited_1.setException(ex_tFileInputDelimited_1);
										}
    								}else{
    									
    										row1.DATE = null;
    									
    								}
									
									
							
						
						}else{
							row1.DATE = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 1;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.CHANNEL = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.CHANNEL = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 2;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.SITE = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.SITE = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 3;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.LOCATION_ID = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.LOCATION_ID = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 4;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.PRODUCT_ID = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.PRODUCT_ID = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 5;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.SKU = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.SKU = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 6;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.MARKDOWN = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.MARKDOWN = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 7;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
								
									if(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {
									
										row1.CURRENT_PRICE = ParserUtils.parseTo_Float(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);
									
									
										} catch(java.lang.Exception ex_tFileInputDelimited_1) {
											rowstate_tFileInputDelimited_1.setException(ex_tFileInputDelimited_1);
										}
    								}else{
    									
    										row1.CURRENT_PRICE = null;
    									
    								}
									
									
							
						
						}else{
							row1.CURRENT_PRICE = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 8;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
								
									if(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {
									
										row1.FULL_PRICE = ParserUtils.parseTo_Float(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);
									
									
										} catch(java.lang.Exception ex_tFileInputDelimited_1) {
											rowstate_tFileInputDelimited_1.setException(ex_tFileInputDelimited_1);
										}
    								}else{
    									
    										row1.FULL_PRICE = null;
    									
    								}
									
									
							
						
						}else{
							row1.FULL_PRICE = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 9;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.CURRENCY = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.CURRENCY = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 10;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
								
									if(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {
									
										row1.STOCK_UNITS = ParserUtils.parseTo_Float(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);
									
									
										} catch(java.lang.Exception ex_tFileInputDelimited_1) {
											rowstate_tFileInputDelimited_1.setException(ex_tFileInputDelimited_1);
										}
    								}else{
    									
    										row1.STOCK_UNITS = null;
    									
    								}
									
									
							
						
						}else{
							row1.STOCK_UNITS = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 11;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
								
									if(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {
									
										row1.UNIT_COST = ParserUtils.parseTo_Float(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);
									
									
										} catch(java.lang.Exception ex_tFileInputDelimited_1) {
											rowstate_tFileInputDelimited_1.setException(ex_tFileInputDelimited_1);
										}
    								}else{
    									
    										row1.UNIT_COST = null;
    									
    								}
									
									
							
						
						}else{
							row1.UNIT_COST = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 12;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
									row1.CURRENCY_UNIT_COST = rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1];
									
							
						
						}else{
							row1.CURRENCY_UNIT_COST = null;
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_1 = 13;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_1 < rowtFileInputDelimited_1.length){
						
						
							
								
									if(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1].length() > 0) {
										try {
									
										row1.ONLINE_PRICE = ParserUtils.parseTo_Float(rowtFileInputDelimited_1[columnIndexWithD_tFileInputDelimited_1]);
									
									
										} catch(java.lang.Exception ex_tFileInputDelimited_1) {
											rowstate_tFileInputDelimited_1.setException(ex_tFileInputDelimited_1);
										}
    								}else{
    									
    										row1.ONLINE_PRICE = null;
    									
    								}
									
									
							
						
						}else{
							row1.ONLINE_PRICE = null;
						}
						
						
					
				}
				
									
									if(rowstate_tFileInputDelimited_1.getException()!=null) {
										throw rowstate_tFileInputDelimited_1.getException();
									}
									
									
	    						} catch (java.lang.Exception e) {
							        whetherReject_tFileInputDelimited_1 = true;
        							
            							throw(e);
            						
	    						}
	
							
			log.debug("tFileInputDelimited_1 - Retrieving the record " + (nb_line_tFileInputDelimited_1+1) + ".");
		

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

fragInventorySaleLocation = null;
fragInventoryFulfilment = null;
fragInventoryStockLocation = null;
itemAttributes = null;


// # Output table : 'fragInventorySaleLocation'
count_fragInventorySaleLocation_tMap_1++;

fragInventorySaleLocation_tmp.date = context.endDate ;
fragInventorySaleLocation_tmp.channel = "WEB";
fragInventorySaleLocation_tmp.siteCat1 = "US";
fragInventorySaleLocation_tmp.productId = anntaylorUtils.getProductId(row1.PRODUCT_ID) ;
fragInventorySaleLocation_tmp.itemId = row1.SKU ;
fragInventorySaleLocation_tmp.seller = null;
fragInventorySaleLocation_tmp.publishDate = null;
fragInventorySaleLocation_tmp.isMarkdown = row1.MARKDOWN ;
fragInventorySaleLocation_tmp.isDiscontinued = null;
fragInventorySaleLocation_tmp.isCore = null;
fragInventorySaleLocation_tmp.seasonStartDate = null;
fragInventorySaleLocation_tmp.seasonStartEnd = null;
fragInventorySaleLocation_tmp.isSellable = "Y";
fragInventorySaleLocation_tmp.isPreorder = null;
fragInventorySaleLocation_tmp.isBackover = null;
fragInventorySaleLocation_tmp.currrentPrice = row1.ONLINE_PRICE!=null && row1.ONLINE_PRICE!=0? row1.ONLINE_PRICE : row1.CURRENT_PRICE ;
fragInventorySaleLocation_tmp.currentPriceExTax = null;
fragInventorySaleLocation_tmp.fullPrice = row1.FULL_PRICE ;
fragInventorySaleLocation_tmp.fullPriceExTax = null;
fragInventorySaleLocation_tmp.currency = "USD";
fragInventorySaleLocation_tmp.preorderUnits = null;
fragInventorySaleLocation_tmp.backorderUnits = null;
fragInventorySaleLocation_tmp.waitlistUnits = null;
fragInventorySaleLocation = fragInventorySaleLocation_tmp;
log.debug("tMap_1 - Outputting the record " + count_fragInventorySaleLocation_tMap_1 + " of the output table 'fragInventorySaleLocation'.");


// # Output table : 'fragInventoryFulfilment'
count_fragInventoryFulfilment_tMap_1++;

fragInventoryFulfilment_tmp.date = context.endDate ;
fragInventoryFulfilment_tmp.channel = "WEB";
fragInventoryFulfilment_tmp.site = "US";
fragInventoryFulfilment_tmp.locationId = row1.LOCATION_ID ;
fragInventoryFulfilment_tmp.productId = anntaylorUtils.getProductId(row1.PRODUCT_ID) ;
fragInventoryFulfilment_tmp.itemId = row1.SKU ;
fragInventoryFulfilment_tmp.seller = null;
fragInventoryFulfilment_tmp.unitCostUpLift = null;
fragInventoryFulfilment_tmp.currencyCode = "USD";
fragInventoryFulfilment = fragInventoryFulfilment_tmp;
log.debug("tMap_1 - Outputting the record " + count_fragInventoryFulfilment_tMap_1 + " of the output table 'fragInventoryFulfilment'.");


// # Output table : 'fragInventoryStockLocation'
count_fragInventoryStockLocation_tMap_1++;

fragInventoryStockLocation_tmp.date = context.endDate ;
fragInventoryStockLocation_tmp.locationId = row1.LOCATION_ID ;
fragInventoryStockLocation_tmp.productId = anntaylorUtils.getProductId(row1.PRODUCT_ID) ;
fragInventoryStockLocation_tmp.itemId = row1.SKU ;
fragInventoryStockLocation_tmp.seller = null;
fragInventoryStockLocation_tmp.isSupplierOwned = null;
fragInventoryStockLocation_tmp.isNonStockable = null;
fragInventoryStockLocation_tmp.unitsInStock = row1.STOCK_UNITS.intValue() ;
fragInventoryStockLocation_tmp.leadTimeDays = null;
fragInventoryStockLocation_tmp.unitCost = row1.UNIT_COST ;
fragInventoryStockLocation_tmp.currency = "USD";
fragInventoryStockLocation_tmp.isReorderable = null;
fragInventoryStockLocation = fragInventoryStockLocation_tmp;
log.debug("tMap_1 - Outputting the record " + count_fragInventoryStockLocation_tMap_1 + " of the output table 'fragInventoryStockLocation'.");


// # Output table : 'itemAttributes'
count_itemAttributes_tMap_1++;

itemAttributes_tmp.itemId = row1.SKU ;
itemAttributes_tmp.attributeNumber = row1.LOCATION_ID.isEmpty() || 
row1.LOCATION_ID == null ?
null :
row1.LOCATION_ID.equals("0619") ||
row1.LOCATION_ID.equals("9611") ||
row1.LOCATION_ID.equals("3058") ||
row1.LOCATION_ID.equals("0611") ? 1 : 2 ;
itemAttributes_tmp.value = row1.STOCK_UNITS<=0 || row1.STOCK_UNITS== null ? 0 :
row1.STOCK_UNITS.intValue() ;
itemAttributes = itemAttributes_tmp;
log.debug("tMap_1 - Outputting the record " + count_itemAttributes_tMap_1 + " of the output table 'itemAttributes'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
// Start of branch "fragInventorySaleLocation"
if(fragInventorySaleLocation != null) { 



	
	/**
	 * [tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("fragInventorySaleLocation - " + (fragInventorySaleLocation==null? "": fragInventorySaleLocation.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
                            if(fragInventorySaleLocation.date != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(fragInventorySaleLocation.date, "yyyy-MM-dd")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.channel != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.channel
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.siteCat1 != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.siteCat1
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.productId != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.productId
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.itemId != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.itemId
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.seller != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.seller
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.publishDate != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(fragInventorySaleLocation.publishDate, "yyyy-MM-dd")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.isMarkdown != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.isMarkdown
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.isDiscontinued != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.isDiscontinued
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.isCore != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.isCore
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.seasonStartDate != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(fragInventorySaleLocation.seasonStartDate, "yyyy-MM-dd")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.seasonStartEnd != null) {
                        sb_tFileOutputDelimited_1.append(
                            FormatterUtils.format_Date(fragInventorySaleLocation.seasonStartEnd, "yyyy-MM-dd")
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.isSellable != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.isSellable
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.isPreorder != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.isPreorder
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.isBackover != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.isBackover
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.currrentPrice != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.currrentPrice
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.currentPriceExTax != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.currentPriceExTax
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.fullPrice != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.fullPrice
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.fullPriceExTax != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.fullPriceExTax
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.currency != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.currency
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.preorderUnits != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.preorderUnits
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.backorderUnits != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.backorderUnits
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(fragInventorySaleLocation.waitlistUnits != null) {
                        sb_tFileOutputDelimited_1.append(
                            fragInventorySaleLocation.waitlistUnits
                        );
                            }
                    sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);


                    nb_line_tFileOutputDelimited_1++;
                    resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

                        outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());
                        log.debug("tFileOutputDelimited_1 - Writing the record " + nb_line_tFileOutputDelimited_1 + ".");




 


	tos_count_tFileOutputDelimited_1++;

/**
 * [tFileOutputDelimited_1 main ] stop
 */

} // End of branch "fragInventorySaleLocation"




// Start of branch "fragInventoryFulfilment"
if(fragInventoryFulfilment != null) { 



	
	/**
	 * [tFileOutputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	
    			if(log.isTraceEnabled()){
    				log.trace("fragInventoryFulfilment - " + (fragInventoryFulfilment==null? "": fragInventoryFulfilment.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimited_2 = new StringBuilder();
                            if(fragInventoryFulfilment.date != null) {
                        sb_tFileOutputDelimited_2.append(
                            FormatterUtils.format_Date(fragInventoryFulfilment.date, "yyyy-MM-dd")
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.channel != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.channel
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.site != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.site
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.locationId != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.locationId
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.productId != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.productId
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.itemId != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.itemId
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.seller != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.seller
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.unitCostUpLift != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.unitCostUpLift
                        );
                            }
                            sb_tFileOutputDelimited_2.append(OUT_DELIM_tFileOutputDelimited_2);
                            if(fragInventoryFulfilment.currencyCode != null) {
                        sb_tFileOutputDelimited_2.append(
                            fragInventoryFulfilment.currencyCode
                        );
                            }
                    sb_tFileOutputDelimited_2.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_2);


                    nb_line_tFileOutputDelimited_2++;
                    resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

                        outtFileOutputDelimited_2.write(sb_tFileOutputDelimited_2.toString());
                        log.debug("tFileOutputDelimited_2 - Writing the record " + nb_line_tFileOutputDelimited_2 + ".");




 


	tos_count_tFileOutputDelimited_2++;

/**
 * [tFileOutputDelimited_2 main ] stop
 */

} // End of branch "fragInventoryFulfilment"




// Start of branch "fragInventoryStockLocation"
if(fragInventoryStockLocation != null) { 



	
	/**
	 * [tFileOutputDelimited_3 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_3";

	
    			if(log.isTraceEnabled()){
    				log.trace("fragInventoryStockLocation - " + (fragInventoryStockLocation==null? "": fragInventoryStockLocation.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimited_3 = new StringBuilder();
                            if(fragInventoryStockLocation.date != null) {
                        sb_tFileOutputDelimited_3.append(
                            FormatterUtils.format_Date(fragInventoryStockLocation.date, "yyyy-MM-dd")
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.locationId != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.locationId
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.productId != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.productId
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.itemId != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.itemId
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.seller != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.seller
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.isSupplierOwned != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.isSupplierOwned
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.isNonStockable != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.isNonStockable
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.unitsInStock != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.unitsInStock
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.leadTimeDays != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.leadTimeDays
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.unitCost != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.unitCost
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.currency != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.currency
                        );
                            }
                            sb_tFileOutputDelimited_3.append(OUT_DELIM_tFileOutputDelimited_3);
                            if(fragInventoryStockLocation.isReorderable != null) {
                        sb_tFileOutputDelimited_3.append(
                            fragInventoryStockLocation.isReorderable
                        );
                            }
                    sb_tFileOutputDelimited_3.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_3);


                    nb_line_tFileOutputDelimited_3++;
                    resourceMap.put("nb_line_tFileOutputDelimited_3", nb_line_tFileOutputDelimited_3);

                        outtFileOutputDelimited_3.write(sb_tFileOutputDelimited_3.toString());
                        log.debug("tFileOutputDelimited_3 - Writing the record " + nb_line_tFileOutputDelimited_3 + ".");




 


	tos_count_tFileOutputDelimited_3++;

/**
 * [tFileOutputDelimited_3 main ] stop
 */

} // End of branch "fragInventoryStockLocation"




// Start of branch "itemAttributes"
if(itemAttributes != null) { 



	
	/**
	 * [tAggregateRow_1_AGGOUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	
    			if(log.isTraceEnabled()){
    				log.trace("itemAttributes - " + (itemAttributes==null? "": itemAttributes.toLogString()));
    			}
    		
	
operation_finder_tAggregateRow_1.itemId = itemAttributes.itemId;
			operation_finder_tAggregateRow_1.attributeNumber = itemAttributes.attributeNumber;
			

	operation_finder_tAggregateRow_1.hashCodeDirty = true;
	
	operation_result_tAggregateRow_1 = hash_tAggregateRow_1.get(operation_finder_tAggregateRow_1);

	

	if(operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

		operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

		operation_result_tAggregateRow_1.itemId = operation_finder_tAggregateRow_1.itemId;
				operation_result_tAggregateRow_1.attributeNumber = operation_finder_tAggregateRow_1.attributeNumber;
				
		
		

		hash_tAggregateRow_1.put(operation_result_tAggregateRow_1, operation_result_tAggregateRow_1);
	
	} // G_OutMain_AggR_001


	
				if(itemAttributes.value != null) { // G_OutMain_AggR_546
				
					if(operation_result_tAggregateRow_1.value_sum == null) {
						operation_result_tAggregateRow_1.value_sum = (int) 0;
					}
					
					if( itemAttributes.value != null)
						operation_result_tAggregateRow_1.value_sum += itemAttributes.value;
				} // G_OutMain_AggR_546
				


 


	tos_count_tAggregateRow_1_AGGOUT++;

/**
 * [tAggregateRow_1_AGGOUT main ] stop
 */

} // End of branch "itemAttributes"





} // End of branch "row1"




	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	


				nb_line_tFileInputDelimited_1++;
			}
			
			}finally{
    			if(!(filename_tFileInputDelimited_1 instanceof java.io.InputStream)){
    				if(csvReadertFileInputDelimited_1!=null){
    					csvReadertFileInputDelimited_1.close();
    				}
    			}
    			if(csvReadertFileInputDelimited_1!=null){
    				globalMap.put("tFileInputDelimited_1_NB_LINE",nb_line_tFileInputDelimited_1);
    			}
				
					log.info("tFileInputDelimited_1 - Retrieved records count: "+ nb_line_tFileInputDelimited_1 + ".");
				
			}
						  

 
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + "Done." );

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'fragInventorySaleLocation': " + count_fragInventorySaleLocation_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'fragInventoryFulfilment': " + count_fragInventoryFulfilment_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'fragInventoryStockLocation': " + count_fragInventoryStockLocation_tMap_1 + ".");
				log.debug("tMap_1 - Written records count in the table 'itemAttributes': " + count_itemAttributes_tMap_1 + ".");





 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + "Done." );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	



		
			
					if(outtFileOutputDelimited_1!=null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}
				
				globalMap.put("tFileOutputDelimited_1_NB_LINE",nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_1", true);
	
				log.debug("tFileOutputDelimited_1 - Written records count: " + nb_line_tFileOutputDelimited_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + "Done." );

ok_Hash.put("tFileOutputDelimited_1", true);
end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_1 end ] stop
 */




	
	/**
	 * [tFileOutputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	



		
			
					if(outtFileOutputDelimited_2!=null) {
						outtFileOutputDelimited_2.flush();
						outtFileOutputDelimited_2.close();
					}
				
				globalMap.put("tFileOutputDelimited_2_NB_LINE",nb_line_tFileOutputDelimited_2);
				globalMap.put("tFileOutputDelimited_2_FILE_NAME",fileName_tFileOutputDelimited_2);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_2", true);
	
				log.debug("tFileOutputDelimited_2 - Written records count: " + nb_line_tFileOutputDelimited_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_2 - "  + "Done." );

ok_Hash.put("tFileOutputDelimited_2", true);
end_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_2 end ] stop
 */




	
	/**
	 * [tFileOutputDelimited_3 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_3";

	



		
			
					if(outtFileOutputDelimited_3!=null) {
						outtFileOutputDelimited_3.flush();
						outtFileOutputDelimited_3.close();
					}
				
				globalMap.put("tFileOutputDelimited_3_NB_LINE",nb_line_tFileOutputDelimited_3);
				globalMap.put("tFileOutputDelimited_3_FILE_NAME",fileName_tFileOutputDelimited_3);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_3", true);
	
				log.debug("tFileOutputDelimited_3 - Written records count: " + nb_line_tFileOutputDelimited_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_3 - "  + "Done." );

ok_Hash.put("tFileOutputDelimited_3", true);
end_Hash.put("tFileOutputDelimited_3", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_3 end ] stop
 */




	
	/**
	 * [tAggregateRow_1_AGGOUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + "Done." );

ok_Hash.put("tAggregateRow_1_AGGOUT", true);
end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGOUT end ] stop
 */




	
	/**
	 * [tFileOutputDelimited_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_4", false);
		start_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_4";

	
		int tos_count_tFileOutputDelimited_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_4 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileOutputDelimited_4 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_4.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_4.append("USESTREAM" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("FILENAME" + " = " + "context.outputDirectory + \"/fragItemAttributes_core_1.\" + TalendDate.formatDate(\"yyyyMMdd\", context.endDate)");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("FIELDSEPARATOR" + " = " + "\"\\t\"");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("APPEND" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("CREATE" + " = " + "true");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("SPLIT" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("DELETE_EMPTYFILE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_4 - "  + log4jParamters_tFileOutputDelimited_4 );

String fileName_tFileOutputDelimited_4 = "";
    fileName_tFileOutputDelimited_4 = (new java.io.File(context.outputDirectory + "/fragItemAttributes_core_1." + TalendDate.formatDate("yyyyMMdd", context.endDate))).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_4 = null;
    String extension_tFileOutputDelimited_4 = null;
    String directory_tFileOutputDelimited_4 = null;
    if((fileName_tFileOutputDelimited_4.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_4.lastIndexOf(".") < fileName_tFileOutputDelimited_4.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4;
            extension_tFileOutputDelimited_4 = "";
        } else {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("."));
            extension_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(fileName_tFileOutputDelimited_4.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_4.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(0, fileName_tFileOutputDelimited_4.lastIndexOf("."));
            extension_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4.substring(fileName_tFileOutputDelimited_4.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_4 = fileName_tFileOutputDelimited_4;
            extension_tFileOutputDelimited_4 = "";
        }
        directory_tFileOutputDelimited_4 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_4 = true;
    java.io.File filetFileOutputDelimited_4 = new java.io.File(fileName_tFileOutputDelimited_4);
    globalMap.put("tFileOutputDelimited_4_FILE_NAME",fileName_tFileOutputDelimited_4);
            int nb_line_tFileOutputDelimited_4 = 0;
            int splitEvery_tFileOutputDelimited_4 = 1000;
            int splitedFileNo_tFileOutputDelimited_4 = 0;
            int currentRow_tFileOutputDelimited_4 = 0;

            final String OUT_DELIM_tFileOutputDelimited_4 = /** Start field tFileOutputDelimited_4:FIELDSEPARATOR */"\t"/** End field tFileOutputDelimited_4:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_4 = /** Start field tFileOutputDelimited_4:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_4:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_4 != null && directory_tFileOutputDelimited_4.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_4 = new java.io.File(directory_tFileOutputDelimited_4);
                        if(!dir_tFileOutputDelimited_4.exists()) {
                                log.info("tFileOutputDelimited_4 - Creating directory '" + dir_tFileOutputDelimited_4.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimited_4.mkdirs();
                                log.info("tFileOutputDelimited_4 - The directory '"+ dir_tFileOutputDelimited_4.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_4 = null;

                        java.io.File fileToDelete_tFileOutputDelimited_4 = new java.io.File(fileName_tFileOutputDelimited_4);
                        if(fileToDelete_tFileOutputDelimited_4.exists()) {
                            fileToDelete_tFileOutputDelimited_4.delete();
                        }
                        outtFileOutputDelimited_4 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_4, false),"UTF-8"));
                                    if(filetFileOutputDelimited_4.length()==0){
                                        outtFileOutputDelimited_4.write("itemid");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("attributeNumber");
                                            outtFileOutputDelimited_4.write(OUT_DELIM_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.write("value");
                                        outtFileOutputDelimited_4.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_4);
                                        outtFileOutputDelimited_4.flush();
                                    }


        resourceMap.put("out_tFileOutputDelimited_4", outtFileOutputDelimited_4);
resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

 



/**
 * [tFileOutputDelimited_4 begin ] stop
 */



	
	/**
	 * [tFilterRow_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_8", false);
		start_Hash.put("tFilterRow_8", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_8";

	
		int tos_count_tFilterRow_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_8 - "  + "Start to work." );
            StringBuilder log4jParamters_tFilterRow_8 = new StringBuilder();
            log4jParamters_tFilterRow_8.append("Parameters:");
                    log4jParamters_tFilterRow_8.append("LOGICAL_OP" + " = " + "&&");
                log4jParamters_tFilterRow_8.append(" | ");
                    log4jParamters_tFilterRow_8.append("CONDITIONS" + " = " + "[]");
                log4jParamters_tFilterRow_8.append(" | ");
                    log4jParamters_tFilterRow_8.append("USE_ADVANCED" + " = " + "true");
                log4jParamters_tFilterRow_8.append(" | ");
                    log4jParamters_tFilterRow_8.append("ADVANCED_COND" + " = " + "// code sample : use input_row to define the condition. // input_row.columnName1.equals(\"foo\") ||!(input_row.columnName2.equals(\"bar\")) // replace the following expression by your own filter condition  row4.itemid!=null && !row4.itemid.isEmpty() && row4.attributeNumber!=null && row4.value!=null && !row4.value.isEmpty()		");
                log4jParamters_tFilterRow_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_8 - "  + log4jParamters_tFilterRow_8 );
    int nb_line_tFilterRow_8 = 0;
    int nb_line_ok_tFilterRow_8 = 0;
    int nb_line_reject_tFilterRow_8 = 0;

    class Operator_tFilterRow_8 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_8(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_8 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + "Start to work." );
            StringBuilder log4jParamters_tMap_2 = new StringBuilder();
            log4jParamters_tMap_2.append("Parameters:");
                    log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + log4jParamters_tMap_2 );




// ###############################
// # Lookup's keys initialization
		int count_row3_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_row4_tMap_2 = 0;
				
row4Struct row4_tmp = new row4Struct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tAggregateRow_1_AGGIN begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGIN", false);
		start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	
		int tos_count_tAggregateRow_1_AGGIN = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + "Start to work." );
            StringBuilder log4jParamters_tAggregateRow_1_AGGIN = new StringBuilder();
            log4jParamters_tAggregateRow_1_AGGIN.append("Parameters:");
                    log4jParamters_tAggregateRow_1_AGGIN.append("ORIGIN" + " = " + "tAggregateRow_1");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("itemId")+", INPUT_COLUMN="+("itemId")+"}, {OUTPUT_COLUMN="+("attributeNumber")+", INPUT_COLUMN="+("attributeNumber")+"}]");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="+("value")+", INPUT_COLUMN="+("value")+", IGNORE_NULL="+("true")+", FUNCTION="+("sum")+"}]");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("LIST_DELIMITER" + " = " + "\",\"");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("USE_FINANCIAL_PRECISION" + " = " + "true");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_ULP" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + log4jParamters_tAggregateRow_1_AGGIN );

java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1.values();

globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

                if(log.isInfoEnabled())
            log.info("tAggregateRow_1_AGGIN - "  + "Retrieving the aggregation results." );
for(AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600



 



/**
 * [tAggregateRow_1_AGGIN begin ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGIN main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

            				    row3.itemId = aggregated_row_tAggregateRow_1.itemId;
            				    
            				    row3.attributeNumber = aggregated_row_tAggregateRow_1.attributeNumber;
            				    row3.value = aggregated_row_tAggregateRow_1.value_sum;
                                	
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + "Operation function: 'sum' on the column 'value'." );

 


	tos_count_tAggregateRow_1_AGGIN++;

/**
 * [tAggregateRow_1_AGGIN main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

row4 = null;


// # Output table : 'row4'
count_row4_tMap_2++;

row4_tmp.itemid = row3.itemId ;
row4_tmp.attributeNumber = row3.attributeNumber ;
row4_tmp.value = row3.value.toString();
row4 = row4_tmp;
log.debug("tMap_2 - Outputting the record " + count_row4_tMap_2 + " of the output table 'row4'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "row4"
if(row4 != null) { 



	
	/**
	 * [tFilterRow_8 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_8";

	
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

          row5 = null;
    Operator_tFilterRow_8 ope_tFilterRow_8 = new Operator_tFilterRow_8("&&");
      ope_tFilterRow_8.matches((// code sample : use row4 to define the condition.
// row4.columnName1.equals("foo") ||!(row4.columnName2.equals("bar"))
// replace the following expression by your own filter condition 
row4.itemid!=null && !row4.itemid.isEmpty() &&
row4.attributeNumber!=null &&
row4.value!=null && !row4.value.isEmpty()		), "advanced condition failed");
    
    if (ope_tFilterRow_8.getMatchFlag()) {
              if(row5 == null){ 
                row5 = new row5Struct();
              }
               row5.itemid = row4.itemid;
               row5.attributeNumber = row4.attributeNumber;
               row5.value = row4.value;
					log.debug("tFilterRow_8 - Process the record " + (nb_line_tFilterRow_8+1) + ".");
					    
      nb_line_ok_tFilterRow_8++;
    } else {
      nb_line_reject_tFilterRow_8++;
    }

nb_line_tFilterRow_8++;

 


	tos_count_tFilterRow_8++;

/**
 * [tFilterRow_8 main ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tFileOutputDelimited_4 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimited_4 = new StringBuilder();
                            if(row5.itemid != null) {
                        sb_tFileOutputDelimited_4.append(
                            row5.itemid
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row5.attributeNumber != null) {
                        sb_tFileOutputDelimited_4.append(
                            row5.attributeNumber
                        );
                            }
                            sb_tFileOutputDelimited_4.append(OUT_DELIM_tFileOutputDelimited_4);
                            if(row5.value != null) {
                        sb_tFileOutputDelimited_4.append(
                            row5.value
                        );
                            }
                    sb_tFileOutputDelimited_4.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_4);


                    nb_line_tFileOutputDelimited_4++;
                    resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

                        outtFileOutputDelimited_4.write(sb_tFileOutputDelimited_4.toString());
                        log.debug("tFileOutputDelimited_4 - Writing the record " + nb_line_tFileOutputDelimited_4 + ".");




 


	tos_count_tFileOutputDelimited_4++;

/**
 * [tFileOutputDelimited_4 main ] stop
 */

} // End of branch "row5"





} // End of branch "row4"







	
	/**
	 * [tAggregateRow_1_AGGIN end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

} // G_AggR_600

 
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + "Done." );

ok_Hash.put("tAggregateRow_1_AGGIN", true);
end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGIN end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'row4': " + count_row4_tMap_2 + ".");





 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + "Done." );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tFilterRow_8 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_8";

	
    globalMap.put("tFilterRow_8_NB_LINE", nb_line_tFilterRow_8);
    globalMap.put("tFilterRow_8_NB_LINE_OK", nb_line_ok_tFilterRow_8);
    globalMap.put("tFilterRow_8_NB_LINE_REJECT", nb_line_reject_tFilterRow_8);
    
    	log.info("tFilterRow_8 - Processed records count:" + nb_line_tFilterRow_8 + ". Matched records count:" + nb_line_ok_tFilterRow_8 + ". Rejected records count:" + nb_line_reject_tFilterRow_8 + ".");

 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_8 - "  + "Done." );

ok_Hash.put("tFilterRow_8", true);
end_Hash.put("tFilterRow_8", System.currentTimeMillis());




/**
 * [tFilterRow_8 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	



		
			
					if(outtFileOutputDelimited_4!=null) {
						outtFileOutputDelimited_4.flush();
						outtFileOutputDelimited_4.close();
					}
				
				globalMap.put("tFileOutputDelimited_4_NB_LINE",nb_line_tFileOutputDelimited_4);
				globalMap.put("tFileOutputDelimited_4_FILE_NAME",fileName_tFileOutputDelimited_4);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_4", true);
	
				log.debug("tFileOutputDelimited_4 - Written records count: " + nb_line_tFileOutputDelimited_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_4 - "  + "Done." );

ok_Hash.put("tFileOutputDelimited_4", true);
end_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_4 end ] stop
 */


















				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							tFixedFlowInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
							//free memory for "tAggregateRow_1_AGGIN"
							globalMap.remove("tAggregateRow_1");
						
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_tFileOutputDelimited_1") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_1");
						if(outtFileOutputDelimited_1!=null) {
							outtFileOutputDelimited_1.flush();
							outtFileOutputDelimited_1.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_1 finally ] stop
 */




	
	/**
	 * [tFileOutputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	


		if(resourceMap.get("finish_tFileOutputDelimited_2") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_2 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_2");
						if(outtFileOutputDelimited_2!=null) {
							outtFileOutputDelimited_2.flush();
							outtFileOutputDelimited_2.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_2 finally ] stop
 */




	
	/**
	 * [tFileOutputDelimited_3 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_3";

	


		if(resourceMap.get("finish_tFileOutputDelimited_3") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_3 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_3");
						if(outtFileOutputDelimited_3!=null) {
							outtFileOutputDelimited_3.flush();
							outtFileOutputDelimited_3.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_3 finally ] stop
 */




	
	/**
	 * [tAggregateRow_1_AGGOUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 



/**
 * [tAggregateRow_1_AGGOUT finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGIN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

 



/**
 * [tAggregateRow_1_AGGIN finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tFilterRow_8 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_8";

	

 



/**
 * [tFilterRow_8 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	


		if(resourceMap.get("finish_tFileOutputDelimited_4") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_4 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_4");
						if(outtFileOutputDelimited_4!=null) {
							outtFileOutputDelimited_4.flush();
							outtFileOutputDelimited_4.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_4 finally ] stop
 */


















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String fileIdentifier;

				public String getFileIdentifier () {
					return this.fileIdentifier;
				}
				
			    public String fileType;

				public String getFileType () {
					return this.fileType;
				}
				
			    public boolean isDated;

				public boolean getIsDated () {
					return this.isDated;
				}
				
			    public String filenameBase;

				public String getFilenameBase () {
					return this.filenameBase;
				}
				
			    public String feedSchemaVersion;

				public String getFeedSchemaVersion () {
					return this.feedSchemaVersion;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.fileIdentifier = readString(dis);
					
					this.fileType = readString(dis);
					
			        this.isDated = dis.readBoolean();
					
					this.filenameBase = readString(dis);
					
					this.feedSchemaVersion = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.fileIdentifier,dos);
					
					// String
				
						writeString(this.fileType,dos);
					
					// boolean
				
		            	dos.writeBoolean(this.isDated);
					
					// String
				
						writeString(this.filenameBase,dos);
					
					// String
				
						writeString(this.feedSchemaVersion,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("fileIdentifier="+fileIdentifier);
		sb.append(",fileType="+fileType);
		sb.append(",isDated="+String.valueOf(isDated));
		sb.append(",filenameBase="+filenameBase);
		sb.append(",feedSchemaVersion="+feedSchemaVersion);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(fileIdentifier == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fileIdentifier);
            			}
            		
        			sb.append("|");
        		
        				if(fileType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fileType);
            			}
            		
        			sb.append("|");
        		
        				sb.append(isDated);
        			
        			sb.append("|");
        		
        				if(filenameBase == null){
        					sb.append("<null>");
        				}else{
            				sb.append(filenameBase);
            			}
            		
        			sb.append("|");
        		
        				if(feedSchemaVersion == null){
        					sb.append("<null>");
        				}else{
            				sb.append(feedSchemaVersion);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [DSMFileWriter_1_tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_DSMFileWriter_1_tFileList_1 = 0; //for statistics
			

	
		
		ok_Hash.put("DSMFileWriter_1_tFlowToIterate_1", false);
		start_Hash.put("DSMFileWriter_1_tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tFlowToIterate_1";

	
		int tos_count_DSMFileWriter_1_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFlowToIterate_1 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_DSMFileWriter_1_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFlowToIterate_1 - "  + log4jParamters_DSMFileWriter_1_tFlowToIterate_1 );

int nb_line_DSMFileWriter_1_tFlowToIterate_1 = 0;
int counter_DSMFileWriter_1_tFlowToIterate_1 = 0;

 



/**
 * [DSMFileWriter_1_tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_1", false);
		start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_1";

	
		int tos_count_tFixedFlowInput_1 = 0;
		

	int nb_line_tFixedFlowInput_1 = 0;
	List<row2Struct> cacheList_tFixedFlowInput_1 = new java.util.ArrayList<row2Struct>();
	row2 = new row2Struct();        	            	
	row2.fileIdentifier = "fragInventorySaleLocation_core";        	            	
	row2.fileType = "FRAGMENT";        	            	
	row2.isDated = true;        	            	
	row2.filenameBase = "fragInventorySaleLocation_core";        	            	
	row2.feedSchemaVersion = "4";
	cacheList_tFixedFlowInput_1.add(row2);
	row2 = new row2Struct();        	            	
	row2.fileIdentifier = "fragInventoryFulfilment_core";        	            	
	row2.fileType = "FRAGMENT";        	            	
	row2.isDated = true;        	            	
	row2.filenameBase = "fragInventoryFulfilment_core";        	            	
	row2.feedSchemaVersion = "4";
	cacheList_tFixedFlowInput_1.add(row2);
	row2 = new row2Struct();        	            	
	row2.fileIdentifier = "fragInventoryStockLocation_core";        	            	
	row2.fileType = "FRAGMENT";        	            	
	row2.isDated = true;        	            	
	row2.filenameBase = "fragInventoryStockLocation_core";        	            	
	row2.feedSchemaVersion = "4";
	cacheList_tFixedFlowInput_1.add(row2);
	row2 = new row2Struct();        	            	
	row2.fileIdentifier = "fragItemAttributes_core";        	            	
	row2.fileType = "FRAGMENT";        	            	
	row2.isDated = true;        	            	
	row2.filenameBase = "fragItemAttributes_core";        	            	
	row2.feedSchemaVersion = "4";
	cacheList_tFixedFlowInput_1.add(row2);
	for (int i_tFixedFlowInput_1 = 0 ; i_tFixedFlowInput_1 < 1 ; i_tFixedFlowInput_1++) {	
		for(row2Struct tmpRow_tFixedFlowInput_1 : cacheList_tFixedFlowInput_1){
			nb_line_tFixedFlowInput_1 ++;		
			row2 = tmpRow_tFixedFlowInput_1;
 



/**
 * [tFixedFlowInput_1 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 


	tos_count_tFixedFlowInput_1++;

/**
 * [tFixedFlowInput_1 main ] stop
 */

	
	/**
	 * [DSMFileWriter_1_tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tFlowToIterate_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("DSMFileWriter_1_tFlowToIterate_1 - "  + "Set global var, key=row2.fileIdentifier, value="  + row2.fileIdentifier  + "." );            
            globalMap.put("row2.fileIdentifier", row2.fileIdentifier);
            nb_line_DSMFileWriter_1_tFlowToIterate_1++;  
    	
                if(log.isTraceEnabled())
            log.trace("DSMFileWriter_1_tFlowToIterate_1 - "  + "Set global var, key=row2.fileType, value="  + row2.fileType  + "." );            
            globalMap.put("row2.fileType", row2.fileType);
            nb_line_DSMFileWriter_1_tFlowToIterate_1++;  
    	
                if(log.isTraceEnabled())
            log.trace("DSMFileWriter_1_tFlowToIterate_1 - "  + "Set global var, key=row2.isDated, value="  + row2.isDated  + "." );            
            globalMap.put("row2.isDated", row2.isDated);
            nb_line_DSMFileWriter_1_tFlowToIterate_1++;  
    	
                if(log.isTraceEnabled())
            log.trace("DSMFileWriter_1_tFlowToIterate_1 - "  + "Set global var, key=row2.filenameBase, value="  + row2.filenameBase  + "." );            
            globalMap.put("row2.filenameBase", row2.filenameBase);
            nb_line_DSMFileWriter_1_tFlowToIterate_1++;  
    	
                if(log.isTraceEnabled())
            log.trace("DSMFileWriter_1_tFlowToIterate_1 - "  + "Set global var, key=row2.feedSchemaVersion, value="  + row2.feedSchemaVersion  + "." );            
            globalMap.put("row2.feedSchemaVersion", row2.feedSchemaVersion);
            nb_line_DSMFileWriter_1_tFlowToIterate_1++;  
    	
 
       counter_DSMFileWriter_1_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFlowToIterate_1 - "  + "Current iteration is: "  + counter_DSMFileWriter_1_tFlowToIterate_1  + "." );
       globalMap.put("DSMFileWriter_1_tFlowToIterate_1_CURRENT_ITERATION", counter_DSMFileWriter_1_tFlowToIterate_1);
 


	tos_count_DSMFileWriter_1_tFlowToIterate_1++;

/**
 * [DSMFileWriter_1_tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_DSMFileWriter_1_tFileList_1++;
	
	

	
	/**
	 * [DSMFileWriter_1_tFileList_1 begin ] start
	 */

				
			int NB_ITERATE_DSMFileWriter_1_tDSMFileManager_2 = 0; //for statistics
			

	
		
		ok_Hash.put("DSMFileWriter_1_tFileList_1", false);
		start_Hash.put("DSMFileWriter_1_tFileList_1", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tFileList_1";

	
		int tos_count_DSMFileWriter_1_tFileList_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFileList_1 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tFileList_1 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tFileList_1.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("DIRECTORY" + " = " + "context.outputDirectory");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("LIST_MODE" + " = " + "FILES");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("INCLUDSUBDIR" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("CASE_SENSITIVE" + " = " + "YES");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ERROR" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("GLOBEXPRESSIONS" + " = " + "true");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("FILES" + " = " + "[{FILEMASK="+("((String)globalMap.get(\"row2.filenameBase\"))+\"_*.nodate\"")+"}, {FILEMASK="+("((String)globalMap.get(\"row2.filenameBase\"))+\"_*.????????\"")+"}, {FILEMASK="+("((String)globalMap.get(\"row2.filenameBase\"))+\"_*.da\"")+"}]");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ORDER_BY_NOTHING" + " = " + "true");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ORDER_BY_FILENAME" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ORDER_BY_FILESIZE" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ORDER_BY_MODIFIEDDATE" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ORDER_ACTION_ASC" + " = " + "true");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("ORDER_ACTION_DESC" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("IFEXCLUDE" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tFileList_1.append("FORMAT_FILEPATH_TO_SLASH" + " = " + "false");
                log4jParamters_DSMFileWriter_1_tFileList_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFileList_1 - "  + log4jParamters_DSMFileWriter_1_tFileList_1 );
	
 
  
				final StringBuffer log4jSb_DSMFileWriter_1_tFileList_1 = new StringBuffer();
			   
    
  String directory_DSMFileWriter_1_tFileList_1 = context.outputDirectory;
  final java.util.List<String> maskList_DSMFileWriter_1_tFileList_1 = new java.util.ArrayList<String>();
  final java.util.List<java.util.regex.Pattern> patternList_DSMFileWriter_1_tFileList_1 = new java.util.ArrayList<java.util.regex.Pattern>(); 
    maskList_DSMFileWriter_1_tFileList_1.add(((String)globalMap.get("row2.filenameBase"))+"_*.nodate"); 
    maskList_DSMFileWriter_1_tFileList_1.add(((String)globalMap.get("row2.filenameBase"))+"_*.????????"); 
    maskList_DSMFileWriter_1_tFileList_1.add(((String)globalMap.get("row2.filenameBase"))+"_*.da");  
  for (final String filemask_DSMFileWriter_1_tFileList_1 : maskList_DSMFileWriter_1_tFileList_1) {
	String filemask_compile_DSMFileWriter_1_tFileList_1 = filemask_DSMFileWriter_1_tFileList_1;
	
		filemask_compile_DSMFileWriter_1_tFileList_1 = org.apache.oro.text.GlobCompiler.globToPerl5(filemask_DSMFileWriter_1_tFileList_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
	
		java.util.regex.Pattern fileNamePattern_DSMFileWriter_1_tFileList_1 = java.util.regex.Pattern.compile(filemask_compile_DSMFileWriter_1_tFileList_1);
	patternList_DSMFileWriter_1_tFileList_1.add(fileNamePattern_DSMFileWriter_1_tFileList_1);
  }
  int NB_FILEDSMFileWriter_1_tFileList_1 = 0;

  final boolean case_sensitive_DSMFileWriter_1_tFileList_1 = true;
    final java.util.List<java.io.File> list_DSMFileWriter_1_tFileList_1 = new java.util.ArrayList<java.io.File>();
    final java.util.Set<String> filePath_DSMFileWriter_1_tFileList_1 = new java.util.HashSet<String>();
	java.io.File file_DSMFileWriter_1_tFileList_1 = new java.io.File(directory_DSMFileWriter_1_tFileList_1);
     
		file_DSMFileWriter_1_tFileList_1.listFiles(new java.io.FilenameFilter() {
			public boolean accept(java.io.File dir, String name) {
				java.io.File file = new java.io.File(dir, name);
                if (!file.isDirectory()) {
                	
    	String fileName_DSMFileWriter_1_tFileList_1 = file.getName();
		for (final java.util.regex.Pattern fileNamePattern_DSMFileWriter_1_tFileList_1 : patternList_DSMFileWriter_1_tFileList_1) {
          	if (fileNamePattern_DSMFileWriter_1_tFileList_1.matcher(fileName_DSMFileWriter_1_tFileList_1).matches()){
					if(!filePath_DSMFileWriter_1_tFileList_1.contains(file.getAbsolutePath())) {
			          list_DSMFileWriter_1_tFileList_1.add(file);
			          filePath_DSMFileWriter_1_tFileList_1.add(file.getAbsolutePath());
			        }
			}
		}
                }
              return true;
            }
          }
      ); 
      java.util.Collections.sort(list_DSMFileWriter_1_tFileList_1);
    
		log.info("DSMFileWriter_1_tFileList_1 - Start to list files");
	
    for (int i_DSMFileWriter_1_tFileList_1 = 0; i_DSMFileWriter_1_tFileList_1 < list_DSMFileWriter_1_tFileList_1.size(); i_DSMFileWriter_1_tFileList_1++){
      java.io.File files_DSMFileWriter_1_tFileList_1 = list_DSMFileWriter_1_tFileList_1.get(i_DSMFileWriter_1_tFileList_1);
      String fileName_DSMFileWriter_1_tFileList_1 = files_DSMFileWriter_1_tFileList_1.getName();
      
      String currentFileName_DSMFileWriter_1_tFileList_1 = files_DSMFileWriter_1_tFileList_1.getName(); 
      String currentFilePath_DSMFileWriter_1_tFileList_1 = files_DSMFileWriter_1_tFileList_1.getAbsolutePath();
      String currentFileDirectory_DSMFileWriter_1_tFileList_1 = files_DSMFileWriter_1_tFileList_1.getParent();
      String currentFileExtension_DSMFileWriter_1_tFileList_1 = null;
      
      if (files_DSMFileWriter_1_tFileList_1.getName().contains(".") && files_DSMFileWriter_1_tFileList_1.isFile()){
        currentFileExtension_DSMFileWriter_1_tFileList_1 = files_DSMFileWriter_1_tFileList_1.getName().substring(files_DSMFileWriter_1_tFileList_1.getName().lastIndexOf(".") + 1);
      } else{
        currentFileExtension_DSMFileWriter_1_tFileList_1 = "";
      }
      
      NB_FILEDSMFileWriter_1_tFileList_1 ++;
      globalMap.put("DSMFileWriter_1_tFileList_1_CURRENT_FILE", currentFileName_DSMFileWriter_1_tFileList_1);
      globalMap.put("DSMFileWriter_1_tFileList_1_CURRENT_FILEPATH", currentFilePath_DSMFileWriter_1_tFileList_1);
      globalMap.put("DSMFileWriter_1_tFileList_1_CURRENT_FILEDIRECTORY", currentFileDirectory_DSMFileWriter_1_tFileList_1);
      globalMap.put("DSMFileWriter_1_tFileList_1_CURRENT_FILEEXTENSION", currentFileExtension_DSMFileWriter_1_tFileList_1);
      globalMap.put("DSMFileWriter_1_tFileList_1_NB_FILE", NB_FILEDSMFileWriter_1_tFileList_1);
      
		log.info("DSMFileWriter_1_tFileList_1 - Current file or directory path : " + currentFilePath_DSMFileWriter_1_tFileList_1);
	  
 



/**
 * [DSMFileWriter_1_tFileList_1 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tFileList_1 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tFileList_1";

	

 


	tos_count_DSMFileWriter_1_tFileList_1++;

/**
 * [DSMFileWriter_1_tFileList_1 main ] stop
 */
	NB_ITERATE_DSMFileWriter_1_tDSMFileManager_2++;
	
	

	
	/**
	 * [DSMFileWriter_1_tDSMFileManager_2 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tDSMFileManager_2", false);
		start_Hash.put("DSMFileWriter_1_tDSMFileManager_2", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tDSMFileManager_2";

	
		int tos_count_DSMFileWriter_1_tDSMFileManager_2 = 0;
		
 


boolean isDated_DSMFileWriter_1_tDSMFileManager_2 = ("true").equals((((Boolean)globalMap.get("row2.isDated")).toString()));
Boolean writeDSM_DSMFileWriter_1_tDSMFileManager_2 = new Boolean(context.useDsm);

String fileDate_DSMFileWriter_1_tDSMFileManager_2 = null;

if ( isDated_DSMFileWriter_1_tDSMFileManager_2 ){

	// pull the extension off the input file and confirm that it's 8 digits
	
	fileDate_DSMFileWriter_1_tDSMFileManager_2 =  (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))).substring((context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))).lastIndexOf(".") + 1);
	
	if ( ! fileDate_DSMFileWriter_1_tDSMFileManager_2.matches("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]") ) {
		throw new RuntimeException ( "Invalid date stamp on dated file: " + fileDate_DSMFileWriter_1_tDSMFileManager_2 );
	}
}

String fileName_DSMFileWriter_1_tDSMFileManager_2 = null;

if ( (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))).indexOf("/") != -1 ) {
	fileName_DSMFileWriter_1_tDSMFileManager_2 = (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))).substring( (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))).lastIndexOf("/") +1 );
} 
else { 
	fileName_DSMFileWriter_1_tDSMFileManager_2 = (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE")));
}

if ( fileName_DSMFileWriter_1_tDSMFileManager_2.indexOf("\\") != -1 ) {
	fileName_DSMFileWriter_1_tDSMFileManager_2 = fileName_DSMFileWriter_1_tDSMFileManager_2.substring( (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))).lastIndexOf("\\") +1 );
} 

if ( ((String)globalMap.get("row2.fileType")).equals("FRAGMENT") || ((String)globalMap.get("row2.fileType")).equals("FEED") || ((String)globalMap.get("row2.fileType")).equals("VERIFICATION") ) {
	fileName_DSMFileWriter_1_tDSMFileManager_2 = fileName_DSMFileWriter_1_tDSMFileManager_2.substring(0,fileName_DSMFileWriter_1_tDSMFileManager_2.lastIndexOf("."));
}

String destinationPath_DSMFileWriter_1_tDSMFileManager_2 = null;

// determine the destination path for this file

if ( ((String)globalMap.get("row2.fileType")).equals("FRAGMENT") ) {

	java.text.SimpleDateFormat sdf_DSMFileWriter_1_tDSMFileManager_2 = new java.text.SimpleDateFormat( "yyyyMMddHHmmssSSS" );	
	
	// for dated fragments the path will be / [account] / fragments / [date] / [fileName]
	
	if ( isDated_DSMFileWriter_1_tDSMFileManager_2 ) {

		destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/fragments/" + fileDate_DSMFileWriter_1_tDSMFileManager_2 + "/" + fileName_DSMFileWriter_1_tDSMFileManager_2.replaceAll("[ ]", "_" );
	}

	// for undated fragments the path will be / [account] / fragments / nodate / [fileName]

	else { 

		destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/fragments/nodate/" + fileName_DSMFileWriter_1_tDSMFileManager_2.replaceAll("[ ]", "_" );
	}
}
else { 
	if ( ((String)globalMap.get("row2.fileType")).equals("FEED") ) {

		// for dated feeds, the path is / [account] / feeds / [date] / [fileName]
		// replace any existing, but retain the version

		if ( isDated_DSMFileWriter_1_tDSMFileManager_2 ) {

			destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/feeds/" + fileDate_DSMFileWriter_1_tDSMFileManager_2 + "/" + fileName_DSMFileWriter_1_tDSMFileManager_2;
		}
	
		// for undated feeds, the path is / [account] / feeds / nodate / [fileName]
		// replace any existing, but retain the version

		else { 
	
			destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/feeds/nodate/" + fileName_DSMFileWriter_1_tDSMFileManager_2;
		}
	}
	else {
		if ( ((String)globalMap.get("row2.fileType")).equals("VERIFICATION") ) {

			// for dated verifications, the path is / [account] / verifications / [date] / [fileName]
			// replace any existing, but retain the version

			if ( isDated_DSMFileWriter_1_tDSMFileManager_2 ) {

				destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/verifications/" + fileDate_DSMFileWriter_1_tDSMFileManager_2 + "/" + fileName_DSMFileWriter_1_tDSMFileManager_2;
			}
	
			// for undated verifications, the path is / [account] / verifications / nodate / [fileName]
			// replace any existing, but retain the version

			else { 
	
				destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/verifications/nodate/" + fileName_DSMFileWriter_1_tDSMFileManager_2;
			}
		}
		else {  
	
			if ( ((String)globalMap.get("row2.fileType")).equals("DATA_ACQUISITION") ) {
		
				// for data acquisitions, the path is / [account] / collected / [fileIdentifier] / [current date] / [fileName].[epoch]
			
				java.text.DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		
				destinationPath_DSMFileWriter_1_tDSMFileManager_2 = context.clientId + "/collected/" + ((String)globalMap.get("row2.fileIdentifier")).replaceAll("[^\\w]", "_" ) + "/" + 
					dateFormat.format(new java.util.Date()) + "/" + java.net.URLEncoder.encode(fileName_DSMFileWriter_1_tDSMFileManager_2,"UTF-8").replaceAll("\\+","%20") + "." + System.currentTimeMillis(); 
			}
			else { 
				throw new RuntimeException ( "Unrecognized file type: " + ((String)globalMap.get("row2.fileType")) );	
			}
		}
	}
}

if ( writeDSM_DSMFileWriter_1_tDSMFileManager_2 ) {

	com.ecommera.itrader.dsm.client.DsmClientConfiguration dsmClientConfig_DSMFileWriter_1_tDSMFileManager_2 = new 
		com.ecommera.itrader.dsm.client.DsmClientConfiguration ( context.dsmEndPoint );
	
	com.ecommera.itrader.dsm.client.DsmClient dsmClient_DSMFileWriter_1_tDSMFileManager_2 = null;
	java.io.InputStream is_DSMFileWriter_1_tDSMFileManager_2 = null;

	try { 

		dsmClient_DSMFileWriter_1_tDSMFileManager_2 = new 
			com.ecommera.itrader.dsm.client.DsmClient ( dsmClientConfig_DSMFileWriter_1_tDSMFileManager_2 );

		is_DSMFileWriter_1_tDSMFileManager_2 = new java.io.FileInputStream((context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))));

		com.ecommera.itrader.dsm.client.FileMetadata fm_DSMFileWriter_1_tDSMFileManager_2 = 
			dsmClient_DSMFileWriter_1_tDSMFileManager_2.writeFileGetMeta( destinationPath_DSMFileWriter_1_tDSMFileManager_2, is_DSMFileWriter_1_tDSMFileManager_2 );
			
		String latestSourceVersion_DSMFileWriter_1_tDSMFileManager_2 = com.ecommera.itrader.dsm.client.VersionInfo.findLatestVersion ( fm_DSMFileWriter_1_tDSMFileManager_2 );

		java.util.List<com.ecommera.itrader.etl.requests.callback.FileCallbackDetails> collection_DSMFileWriter_1_tDSMFileManager_2 = 
			(java.util.List<com.ecommera.itrader.etl.requests.callback.FileCallbackDetails>)
			globalMap.get( "DSM_FILE_CALLBACK_DETAILS" );

		if ( collection_DSMFileWriter_1_tDSMFileManager_2 == null ) {

			collection_DSMFileWriter_1_tDSMFileManager_2 = new java.util.ArrayList<com.ecommera.itrader.etl.requests.callback.FileCallbackDetails>();
			globalMap.put ("DSM_FILE_CALLBACK_DETAILS", collection_DSMFileWriter_1_tDSMFileManager_2 ); 
		}

		com.ecommera.itrader.etl.requests.callback.FileCallbackDetails fc_DSMFileWriter_1_tDSMFileManager_2 = new
			com.ecommera.itrader.etl.requests.callback.FileCallbackDetails(); 
	
		fc_DSMFileWriter_1_tDSMFileManager_2.setFile(destinationPath_DSMFileWriter_1_tDSMFileManager_2 + "?version=" + latestSourceVersion_DSMFileWriter_1_tDSMFileManager_2);
		
		if ( ((String)globalMap.get("row2.fileType")).equals("DATA_ACQUISITION") ) {
			fc_DSMFileWriter_1_tDSMFileManager_2.setCollection("DA_RESULT_FILE_LIST"); 
		}
		else { 
			fc_DSMFileWriter_1_tDSMFileManager_2.setCollection(((String)globalMap.get("row2.fileIdentifier")));
		}
	
		if ( isDated_DSMFileWriter_1_tDSMFileManager_2 ) {
			fc_DSMFileWriter_1_tDSMFileManager_2.setDate (fileDate_DSMFileWriter_1_tDSMFileManager_2);
		}
	
		collection_DSMFileWriter_1_tDSMFileManager_2.add(fc_DSMFileWriter_1_tDSMFileManager_2);
		
		java.util.Map<String, String> etlMetaMap_DSMFileWriter_1_tDSMFileManager_2 = new java.util.HashMap<String, String>();
		etlMetaMap_DSMFileWriter_1_tDSMFileManager_2.put ( "etl.projectName", projectName );
		etlMetaMap_DSMFileWriter_1_tDSMFileManager_2.put ( "etl.jobName", jobName );
		etlMetaMap_DSMFileWriter_1_tDSMFileManager_2.put ( "etl.jobVersion", jobVersion );
		for ( String s_DSMFileWriter_1_tDSMFileManager_2 : context.stringPropertyNames() ) {
			etlMetaMap_DSMFileWriter_1_tDSMFileManager_2.put ( "etl.context." + s_DSMFileWriter_1_tDSMFileManager_2, context.getProperty(s_DSMFileWriter_1_tDSMFileManager_2) );
		}
		
		if ( ((String)globalMap.get("row2.feedSchemaVersion")) != null ) {
			etlMetaMap_DSMFileWriter_1_tDSMFileManager_2.put ( "etl.feed_schema_version", ((String)globalMap.get("row2.feedSchemaVersion")) );
		}
		
		dsmClient_DSMFileWriter_1_tDSMFileManager_2.putMeta( destinationPath_DSMFileWriter_1_tDSMFileManager_2 + "?version=" + latestSourceVersion_DSMFileWriter_1_tDSMFileManager_2, 
			etlMetaMap_DSMFileWriter_1_tDSMFileManager_2 );

		System.out.println( (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))) + " written to dsm as " + destinationPath_DSMFileWriter_1_tDSMFileManager_2 + "?version=" + latestSourceVersion_DSMFileWriter_1_tDSMFileManager_2 );
	}
	finally { 

		if ( is_DSMFileWriter_1_tDSMFileManager_2 != null ) {
			try { is_DSMFileWriter_1_tDSMFileManager_2.close(); } catch (Exception e) {System.err.println("Error closing inputstream");}
		}	
	
		if ( dsmClient_DSMFileWriter_1_tDSMFileManager_2 != null ) {
			try { dsmClient_DSMFileWriter_1_tDSMFileManager_2.shutdown(); } catch (Exception e) {System.err.println("Error shutting down dsm client");}
		}
	}
}
else { 
	System.out.println( "Not writing " + (context.outputDirectory + "/" + ((String)globalMap.get("DSMFileWriter_1_tFileList_1_CURRENT_FILE"))) + " to dsm." );
}

 



/**
 * [DSMFileWriter_1_tDSMFileManager_2 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tDSMFileManager_2 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tDSMFileManager_2";

	

 


	tos_count_DSMFileWriter_1_tDSMFileManager_2++;

/**
 * [DSMFileWriter_1_tDSMFileManager_2 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tDSMFileManager_2 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tDSMFileManager_2";

	

 

ok_Hash.put("DSMFileWriter_1_tDSMFileManager_2", true);
end_Hash.put("DSMFileWriter_1_tDSMFileManager_2", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tDSMFileManager_2 end ] stop
 */




	
	/**
	 * [DSMFileWriter_1_tFileList_1 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tFileList_1";

	

  
    }
  globalMap.put("DSMFileWriter_1_tFileList_1_NB_FILE", NB_FILEDSMFileWriter_1_tFileList_1);
  
    log.info("DSMFileWriter_1_tFileList_1 - File or directory count : " + NB_FILEDSMFileWriter_1_tFileList_1);

  
 

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFileList_1 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tFileList_1", true);
end_Hash.put("DSMFileWriter_1_tFileList_1", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tFileList_1 end ] stop
 */







	
	/**
	 * [tFixedFlowInput_1 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

		}
	}
	cacheList_tFixedFlowInput_1.clear();
	globalMap.put("tFixedFlowInput_1_NB_LINE", nb_line_tFixedFlowInput_1);

 

ok_Hash.put("tFixedFlowInput_1", true);
end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());




/**
 * [tFixedFlowInput_1 end ] stop
 */

	
	/**
	 * [DSMFileWriter_1_tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tFlowToIterate_1";

	

globalMap.put("DSMFileWriter_1_tFlowToIterate_1_NB_LINE",nb_line_DSMFileWriter_1_tFlowToIterate_1);
 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tFlowToIterate_1 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tFlowToIterate_1", true);
end_Hash.put("DSMFileWriter_1_tFlowToIterate_1", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tFlowToIterate_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_1:OnSubjobOk1", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							EtlcCallbackDSMCollection_1_tSleep_1Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_1:OnSubjobOk2", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							tSleep_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_1 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 



/**
 * [tFixedFlowInput_1 finally ] stop
 */

	
	/**
	 * [DSMFileWriter_1_tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tFlowToIterate_1";

	

 



/**
 * [DSMFileWriter_1_tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [DSMFileWriter_1_tFileList_1 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tFileList_1";

	

 



/**
 * [DSMFileWriter_1_tFileList_1 finally ] stop
 */

	
	/**
	 * [DSMFileWriter_1_tDSMFileManager_2 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tDSMFileManager_2";

	

 



/**
 * [DSMFileWriter_1_tDSMFileManager_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tSleep_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tSleep_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tSleep_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tSleep_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tSleep_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tSleep_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tSleep_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSleep_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tSleep_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tSleep_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tSleep_1.append("PAUSE" + " = " + "0");
                log4jParamters_EtlcCallbackDSMCollection_1_tSleep_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSleep_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tSleep_1 );

 



/**
 * [EtlcCallbackDSMCollection_1_tSleep_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tSleep_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSleep_1";

	

    Thread.sleep((0)*1000);

 


	tos_count_EtlcCallbackDSMCollection_1_tSleep_1++;

/**
 * [EtlcCallbackDSMCollection_1_tSleep_1 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tSleep_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSleep_1";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSleep_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tSleep_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tSleep_1", System.currentTimeMillis());

   			if (globalMap.get("jobInfoWritten") == null) {
   				
    			EtlcCallbackDSMCollection_1_tJava_2Process(globalMap);
   			}

			



/**
 * [EtlcCallbackDSMCollection_1_tSleep_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:EtlcCallbackDSMCollection_1_tSleep_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							EtlcCallbackDSMCollection_1_tJava_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tSleep_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSleep_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tSleep_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tSleep_1_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tJava_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tJava_2 = 0;
		


System.out.println("==============================");
String headerLine = "jobName: " + jobName + " (" + jobVersion + ")";

if ( context.getProperty("clientId") != null ) {
	headerLine += " clientId: " + context.getProperty("clientId");
}

if ( context.getProperty("startDate") != null ) {
	if ( context.getProperty("startDate").indexOf(";") != -1 ) {
		headerLine += " context.startDate: " + context.getProperty("startDate").split(";")[1];
	}
}

if ( context.getProperty("endDate") != null ) {
	if ( context.getProperty("endDate").indexOf(";") != -1 ) {
		headerLine += " context.endDate: " + context.getProperty("endDate").split(";")[1];
	}
}

System.out.println(headerLine);
 



/**
 * [EtlcCallbackDSMCollection_1_tJava_2 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_2";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tJava_2++;

/**
 * [EtlcCallbackDSMCollection_1_tJava_2 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_2";

	

 

ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tJava_2", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:EtlcCallbackDSMCollection_1_tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							EtlcCallbackDSMCollection_1_tContextDump_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tJava_2_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_row11Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row11Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tContextDump_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		EtlcCallbackDSMCollection_1_row11Struct EtlcCallbackDSMCollection_1_row11 = new EtlcCallbackDSMCollection_1_row11Struct();




	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_4", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_4", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_4";

	
		int tos_count_EtlcCallbackDSMCollection_1_tLogRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_4 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("BASIC_MODE" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("VERTICAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("FIELDSEPARATOR" + " = " + "\": \"");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_4 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_4 );

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_EtlcCallbackDSMCollection_1_tLogRow_4 = ": ";
		java.io.PrintStream consoleOut_EtlcCallbackDSMCollection_1_tLogRow_4 = null;	

 		StringBuilder strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4 = null;
		int nb_line_EtlcCallbackDSMCollection_1_tLogRow_4 = 0;
///////////////////////    			



 



/**
 * [EtlcCallbackDSMCollection_1_tLogRow_4 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_3 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_3", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_3", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_3";

	
		int tos_count_EtlcCallbackDSMCollection_1_tContextDump_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_3 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_3 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_3.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_3.append("HIDE_PASSWORD" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_3 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_3 );
        int nb_line_EtlcCallbackDSMCollection_1_tContextDump_3 = 0;
        java.util.List<String> assignList_EtlcCallbackDSMCollection_1_tContextDump_3 = new java.util.ArrayList<String>();
        	log.info("EtlcCallbackDSMCollection_1_tContextDump_3 - Dumping context.");
        for( java.util.Enumeration<?> en_EtlcCallbackDSMCollection_1_tContextDump_3 = context.propertyNames() ; en_EtlcCallbackDSMCollection_1_tContextDump_3.hasMoreElements() ; ) {        
            nb_line_EtlcCallbackDSMCollection_1_tContextDump_3++;
            Object key_EtlcCallbackDSMCollection_1_tContextDump_3 = en_EtlcCallbackDSMCollection_1_tContextDump_3.nextElement();
            Object value_EtlcCallbackDSMCollection_1_tContextDump_3 = context.getProperty(key_EtlcCallbackDSMCollection_1_tContextDump_3.toString());
                    EtlcCallbackDSMCollection_1_row11.key = key_EtlcCallbackDSMCollection_1_tContextDump_3.toString();
                    EtlcCallbackDSMCollection_1_row11.value = value_EtlcCallbackDSMCollection_1_tContextDump_3.toString();
					
							if(("endDate").equals(key_EtlcCallbackDSMCollection_1_tContextDump_3.toString())){
								if(value_EtlcCallbackDSMCollection_1_tContextDump_3.toString().indexOf(";")>-1){
			                    	EtlcCallbackDSMCollection_1_row11.value = value_EtlcCallbackDSMCollection_1_tContextDump_3.toString().substring(value_EtlcCallbackDSMCollection_1_tContextDump_3.toString().indexOf(";")+1);
			                    }
			                }
						
					
					
					
					
					
					
					
					
					
					
					

 



/**
 * [EtlcCallbackDSMCollection_1_tContextDump_3 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_3 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_3";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tContextDump_3++;

/**
 * [EtlcCallbackDSMCollection_1_tContextDump_3 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_4 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_4";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row11 - " + (EtlcCallbackDSMCollection_1_row11==null? "": EtlcCallbackDSMCollection_1_row11.toLogString()));
    			}
    		
///////////////////////		
						



				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4 = new StringBuilder();




   				
	    		if(EtlcCallbackDSMCollection_1_row11.key != null) { //              
                    							
       
				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4.append(
				                String.valueOf(EtlcCallbackDSMCollection_1_row11.key)							
				);


							
	    		} //  			

    			strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4.append(": ");
    			


   				
	    		if(EtlcCallbackDSMCollection_1_row11.value != null) { //              
                    							
       
				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4.append(
				                String.valueOf(EtlcCallbackDSMCollection_1_row11.value)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_EtlcCallbackDSMCollection_1_tLogRow_4 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_EtlcCallbackDSMCollection_1_tLogRow_4 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_EtlcCallbackDSMCollection_1_tLogRow_4);
                    }
                    	log.info("EtlcCallbackDSMCollection_1_tLogRow_4 - Content of row "+(nb_line_EtlcCallbackDSMCollection_1_tLogRow_4+1)+": " + strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4.toString());
                    consoleOut_EtlcCallbackDSMCollection_1_tLogRow_4.println(strBuffer_EtlcCallbackDSMCollection_1_tLogRow_4.toString());
                    consoleOut_EtlcCallbackDSMCollection_1_tLogRow_4.flush();
                    nb_line_EtlcCallbackDSMCollection_1_tLogRow_4++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_EtlcCallbackDSMCollection_1_tLogRow_4++;

/**
 * [EtlcCallbackDSMCollection_1_tLogRow_4 main ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_3 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_3";

	

        }
        globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_3_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tContextDump_3);
        	log.info("EtlcCallbackDSMCollection_1_tContextDump_3 - Dumped contexts count: " + nb_line_EtlcCallbackDSMCollection_1_tContextDump_3 + ".");
 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_3 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_3", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_3", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tContextDump_3 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_4 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_4";

	


//////
//////
globalMap.put("EtlcCallbackDSMCollection_1_tLogRow_4_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tLogRow_4);
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tLogRow_4 - "  + "Printed row count: "  + nb_line_EtlcCallbackDSMCollection_1_tLogRow_4  + "." );

///////////////////////    			

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_4 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_4", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_4", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tLogRow_4 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:EtlcCallbackDSMCollection_1_tContextDump_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							EtlcCallbackDSMCollection_1_tJava_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_3 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_3";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tContextDump_3 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_4 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_4";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tLogRow_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_3_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_3", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tJava_3", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_3";

	
		int tos_count_EtlcCallbackDSMCollection_1_tJava_3 = 0;
		


System.out.println("==============================");
 



/**
 * [EtlcCallbackDSMCollection_1_tJava_3 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_3 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_3";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tJava_3++;

/**
 * [EtlcCallbackDSMCollection_1_tJava_3 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_3 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_3";

	

 

ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_3", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tJava_3", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tJava_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:EtlcCallbackDSMCollection_1_tJava_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							EtlcCallbackDSMCollection_1_tSetGlobalVar_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_3 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_3";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tSetGlobalVar_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_5", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_5", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_5";

	
		int tos_count_EtlcCallbackDSMCollection_1_tSetGlobalVar_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_5 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_5 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_5.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_5.append("VARIABLES" + " = " + "[{VALUE="+("\"true\"")+", KEY="+("\"jobInfoWritten\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_5 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_5 );

 



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_5";

	

globalMap.put("jobInfoWritten", "true");

 


	tos_count_EtlcCallbackDSMCollection_1_tSetGlobalVar_5++;

/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_5";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_5 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_5", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_5", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_5";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_5_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_4", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tJava_4", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_4";

	
		int tos_count_EtlcCallbackDSMCollection_1_tJava_4 = 0;
		


java.util.concurrent.atomic.AtomicInteger atRejections = (java.util.concurrent.atomic.AtomicInteger) globalMap.get("ETL_rejections");

Integer etlRejections = 0;

if ( atRejections != null ) {
	etlRejections = atRejections.get();
}

Integer recordsRead = 0;

for ( String s : globalMap.keySet() ) {
	
	if ( ( s.startsWith("tFileInputDelimited") || s.startsWith("tFileInputExcel") || s.startsWith("tFileInputXML") )  && s.endsWith("_NB_LINE") ) { 
		recordsRead += (Integer)globalMap.get(s);
	}
}

System.out.println ("Input records read: " + recordsRead + " rejections: " + etlRejections );

if ( context.getProperty("maxAllowedRejections") != null && 	!context.getProperty("maxAllowedRejections").equals("") ) {

	Integer maxAllowedRejections = Integer.valueOf(context.getProperty("maxAllowedRejections"));
	
	if ( etlRejections > maxAllowedRejections ) {
		System.out.println ( "maxAllowedRejections: " + maxAllowedRejections + " - failing." );
		globalMap.put("rejectionFailure", true);
	}
}
else { 

	if ( etlRejections > 0 ) {

		if ( etlRejections == recordsRead ) {
			globalMap.put("rejectionFailure", true);
		}
	
		if ( etlRejections > recordsRead / 100 ) {
			globalMap.put("rejectionFailure", true);
		}
	}
}
 



/**
 * [EtlcCallbackDSMCollection_1_tJava_4 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_4 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_4";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tJava_4++;

/**
 * [EtlcCallbackDSMCollection_1_tJava_4 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_4 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_4";

	

 

ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_4", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tJava_4", System.currentTimeMillis());

   			if (globalMap.get("rejectionFailure") != null && ((Boolean)globalMap.get("rejectionFailure"))) {
   				
    			EtlcCallbackDSMCollection_1_tDie_2Process(globalMap);
   			}

			



/**
 * [EtlcCallbackDSMCollection_1_tJava_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:EtlcCallbackDSMCollection_1_tJava_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							EtlcCallbackDSMCollection_1_tJava_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_4 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_4";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tJava_4_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tJava_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tJava_1 = 0;
		


java.util.List<com.ecommera.itrader.etl.requests.callback.FileCallbackDetails> 	collection = 
		(java.util.List<com.ecommera.itrader.etl.requests.callback.FileCallbackDetails>)
	globalMap.get( "DSM_FILE_CALLBACK_DETAILS" );

java.lang.StringBuilder sb = new java.lang.StringBuilder("{ \"files\": [");

boolean first = true;

if ( collection != null ) {

	for ( com.ecommera.itrader.etl.requests.callback.FileCallbackDetails fc : collection ) {
		if ( !first ) {
			sb.append ( "," );
		}
		first = false;
		sb.append ( new JSONObject ( fc ) );
	}
}

sb.append ( "] }" );

if ( !first ) {
	globalMap.put ( "fileRestResponse", sb.toString() );
}

System.out.println ( sb );

 



/**
 * [EtlcCallbackDSMCollection_1_tJava_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_1";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tJava_1++;

/**
 * [EtlcCallbackDSMCollection_1_tJava_1 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_1";

	

 

ok_Hash.put("EtlcCallbackDSMCollection_1_tJava_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tJava_1", System.currentTimeMillis());

   			if (context.useCallback && (globalMap.get("fileRestResponse") != null)) {
   				
    			EtlcCallbackDSMCollection_1_tREST_1Process(globalMap);
   			}

			



/**
 * [EtlcCallbackDSMCollection_1_tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tJava_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tJava_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tJava_1_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_successOutStruct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_successOutStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.message = readString(dis);
					
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.message,dos);
					
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("message="+message);
		sb.append(",context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_successOutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_row1Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row1Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Body);
            			}
            		
        			sb.append("|");
        		
        				if(ERROR_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ERROR_CODE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_row6Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row6Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Body);
            			}
            		
        			sb.append("|");
        		
        				if(ERROR_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ERROR_CODE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_EtlcCallbackDSMCollection_1_tREST_1Struct implements routines.system.IPersistableRow<after_EtlcCallbackDSMCollection_1_tREST_1Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Body);
            			}
            		
        			sb.append("|");
        		
        				if(ERROR_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ERROR_CODE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_EtlcCallbackDSMCollection_1_tREST_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tREST_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tREST_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;


		EtlcCallbackDSMCollection_1_tContextDump_1Process(globalMap);

		EtlcCallbackDSMCollection_1_row6Struct EtlcCallbackDSMCollection_1_row6 = new EtlcCallbackDSMCollection_1_row6Struct();
EtlcCallbackDSMCollection_1_row6Struct EtlcCallbackDSMCollection_1_row1 = EtlcCallbackDSMCollection_1_row6;
EtlcCallbackDSMCollection_1_successOutStruct EtlcCallbackDSMCollection_1_successOut = new EtlcCallbackDSMCollection_1_successOutStruct();






	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_3", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_3";

	
		int tos_count_EtlcCallbackDSMCollection_1_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_3 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("\"{\\\"details\\\":{\\\"time\\\":\\\"\"+TalendDate.formatDate(\"yyyy-MM-dd HH:mm:ss\",TalendDate.getCurrentDate())+\"\\\",\\\"result\\\":\\\"success\\\"\"+EtlcCallbackDSMCollection_1_successOut.message+EtlcCallbackDSMCollection_1_successOut.context+\"}}\"")+", KEY="+("\"successResponse\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_3 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_3 );

 



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tMap_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_2 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tMap_2 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_2 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tMap_2 );




// ###############################
// # Lookup's keys initialization
		int count_EtlcCallbackDSMCollection_1_row1_EtlcCallbackDSMCollection_1_tMap_2 = 0;
		
		int count_EtlcCallbackDSMCollection_1_row7_EtlcCallbackDSMCollection_1_tMap_2 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row7Struct> tHash_Lookup_EtlcCallbackDSMCollection_1_row7 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row7Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row7Struct>) 
					globalMap.get( "tHash_Lookup_EtlcCallbackDSMCollection_1_row7" ))
					;					
					
	
		tHash_Lookup_EtlcCallbackDSMCollection_1_row7.initGet();
	

EtlcCallbackDSMCollection_1_row7Struct EtlcCallbackDSMCollection_1_row7HashKey = new EtlcCallbackDSMCollection_1_row7Struct();
EtlcCallbackDSMCollection_1_row7Struct EtlcCallbackDSMCollection_1_row7Default = new EtlcCallbackDSMCollection_1_row7Struct();
// ###############################        

// ###############################
// # Vars initialization
// ###############################

// ###############################
// # Outputs initialization
				int count_EtlcCallbackDSMCollection_1_successOut_EtlcCallbackDSMCollection_1_tMap_2 = 0;
				
EtlcCallbackDSMCollection_1_successOutStruct EtlcCallbackDSMCollection_1_successOut_tmp = new EtlcCallbackDSMCollection_1_successOutStruct();
// ###############################

        
        



        









 



/**
 * [EtlcCallbackDSMCollection_1_tMap_2 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tLogRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("BASIC_MODE" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("VERTICAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_1 );

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_EtlcCallbackDSMCollection_1_tLogRow_1 = "|";
		java.io.PrintStream consoleOut_EtlcCallbackDSMCollection_1_tLogRow_1 = null;	

 		StringBuilder strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1 = null;
		int nb_line_EtlcCallbackDSMCollection_1_tLogRow_1 = 0;
///////////////////////    			



 



/**
 * [EtlcCallbackDSMCollection_1_tLogRow_1 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tREST_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tREST_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tREST_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tREST_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append("URL" + " = " + "context.controllerFileCallbackUri");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append("METHOD" + " = " + "PUT");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append("HEADERS" + " = " + "[{VALUE="+("\"application/json\"")+", NAME="+("\"Content-Type\"")+"}, {VALUE="+("((String)globalMap.get(\"fileRestResponse\")).length()")+", NAME="+("\"Content-Length\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append("BODY" + " = " + "((String)globalMap.get(\"fileRestResponse\"))  ");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tREST_1 );
	

	
	String endpoint_EtlcCallbackDSMCollection_1_tREST_1 = context.controllerFileCallbackUri;
	
	String trustStoreFile_EtlcCallbackDSMCollection_1_tREST_1 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_EtlcCallbackDSMCollection_1_tREST_1 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_EtlcCallbackDSMCollection_1_tREST_1 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_EtlcCallbackDSMCollection_1_tREST_1 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_EtlcCallbackDSMCollection_1_tREST_1 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_EtlcCallbackDSMCollection_1_tREST_1 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_EtlcCallbackDSMCollection_1_tREST_1 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	javax.net.ssl.SSLContext ctx_EtlcCallbackDSMCollection_1_tREST_1 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_EtlcCallbackDSMCollection_1_tREST_1 = null;
	if(trustStoreFile_EtlcCallbackDSMCollection_1_tREST_1!=null && trustStoreType_EtlcCallbackDSMCollection_1_tREST_1!=null){
		char[] password_EtlcCallbackDSMCollection_1_tREST_1 = null;
		if(trustStorePWD_EtlcCallbackDSMCollection_1_tREST_1!=null)
			password_EtlcCallbackDSMCollection_1_tREST_1 = trustStorePWD_EtlcCallbackDSMCollection_1_tREST_1.toCharArray();
		java.security.KeyStore trustStore_EtlcCallbackDSMCollection_1_tREST_1 = java.security.KeyStore.getInstance(trustStoreType_EtlcCallbackDSMCollection_1_tREST_1);
		trustStore_EtlcCallbackDSMCollection_1_tREST_1.load(new java.io.FileInputStream(trustStoreFile_EtlcCallbackDSMCollection_1_tREST_1), password_EtlcCallbackDSMCollection_1_tREST_1);
		
		javax.net.ssl.TrustManagerFactory tmf_EtlcCallbackDSMCollection_1_tREST_1 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_EtlcCallbackDSMCollection_1_tREST_1.init(trustStore_EtlcCallbackDSMCollection_1_tREST_1);
        tms_EtlcCallbackDSMCollection_1_tREST_1 = tmf_EtlcCallbackDSMCollection_1_tREST_1.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_EtlcCallbackDSMCollection_1_tREST_1 = null;
	if(keyStoreFile_EtlcCallbackDSMCollection_1_tREST_1!=null && keyStoreType_EtlcCallbackDSMCollection_1_tREST_1!=null){
		char[] password_EtlcCallbackDSMCollection_1_tREST_1 = null;
		if(keyStorePWD_EtlcCallbackDSMCollection_1_tREST_1!=null)
			password_EtlcCallbackDSMCollection_1_tREST_1 = keyStorePWD_EtlcCallbackDSMCollection_1_tREST_1.toCharArray();
		java.security.KeyStore keyStore_EtlcCallbackDSMCollection_1_tREST_1 = java.security.KeyStore.getInstance(keyStoreType_EtlcCallbackDSMCollection_1_tREST_1);
		keyStore_EtlcCallbackDSMCollection_1_tREST_1.load(new java.io.FileInputStream(keyStoreFile_EtlcCallbackDSMCollection_1_tREST_1), password_EtlcCallbackDSMCollection_1_tREST_1);
		
		javax.net.ssl.KeyManagerFactory kmf_EtlcCallbackDSMCollection_1_tREST_1 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_EtlcCallbackDSMCollection_1_tREST_1.init(keyStore_EtlcCallbackDSMCollection_1_tREST_1,password_EtlcCallbackDSMCollection_1_tREST_1);
        kms_EtlcCallbackDSMCollection_1_tREST_1 = kmf_EtlcCallbackDSMCollection_1_tREST_1.getKeyManagers();
	}
	
    ctx_EtlcCallbackDSMCollection_1_tREST_1.init(kms_EtlcCallbackDSMCollection_1_tREST_1, tms_EtlcCallbackDSMCollection_1_tREST_1 , null);
    config_EtlcCallbackDSMCollection_1_tREST_1.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_EtlcCallbackDSMCollection_1_tREST_1));

	com.sun.jersey.api.client.Client restClient_EtlcCallbackDSMCollection_1_tREST_1 = com.sun.jersey.api.client.Client.create(config_EtlcCallbackDSMCollection_1_tREST_1);
	com.sun.jersey.api.client.WebResource restResource_EtlcCallbackDSMCollection_1_tREST_1;
	if(endpoint_EtlcCallbackDSMCollection_1_tREST_1!=null && !("").equals(endpoint_EtlcCallbackDSMCollection_1_tREST_1)){
		restResource_EtlcCallbackDSMCollection_1_tREST_1 = restClient_EtlcCallbackDSMCollection_1_tREST_1.resource(endpoint_EtlcCallbackDSMCollection_1_tREST_1);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_EtlcCallbackDSMCollection_1_tREST_1 = null;
	String restResponse_EtlcCallbackDSMCollection_1_tREST_1 = "";
	try{
		
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tREST_1 - "  + "Prepare to send request to rest server." );
		restResponse_EtlcCallbackDSMCollection_1_tREST_1 = restResource_EtlcCallbackDSMCollection_1_tREST_1
		
        	.header("Content-Type","application/json")
		
        	.header("Content-Length",((String)globalMap.get("fileRestResponse")).length())
		  
		
			.put(String.class,((String)globalMap.get("fileRestResponse"))  );
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
        errorResponse_EtlcCallbackDSMCollection_1_tREST_1 = ue.getResponse();
    }
	
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tREST_1 - "  + "Has sent request to rest server." );
	// for output
			
				EtlcCallbackDSMCollection_1_row6 = new EtlcCallbackDSMCollection_1_row6Struct();
				if(errorResponse_EtlcCallbackDSMCollection_1_tREST_1!=null){
					EtlcCallbackDSMCollection_1_row6.Body = errorResponse_EtlcCallbackDSMCollection_1_tREST_1.getEntity(String.class);
					EtlcCallbackDSMCollection_1_row6.ERROR_CODE = errorResponse_EtlcCallbackDSMCollection_1_tREST_1.getStatus();
				}else{
					EtlcCallbackDSMCollection_1_row6.Body = restResponse_EtlcCallbackDSMCollection_1_tREST_1;
				}
			

 



/**
 * [EtlcCallbackDSMCollection_1_tREST_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_1";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tREST_1++;

/**
 * [EtlcCallbackDSMCollection_1_tREST_1 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row6 - " + (EtlcCallbackDSMCollection_1_row6==null? "": EtlcCallbackDSMCollection_1_row6.toLogString()));
    			}
    		
///////////////////////		
						



				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1 = new StringBuilder();




   				
	    		if(EtlcCallbackDSMCollection_1_row6.Body != null) { //              
                    							
       
				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1.append(
				                String.valueOf(EtlcCallbackDSMCollection_1_row6.Body)							
				);


							
	    		} //  			

    			strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1.append("|");
    			


   				
	    		if(EtlcCallbackDSMCollection_1_row6.ERROR_CODE != null) { //              
                    							
       
				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1.append(
				                String.valueOf(EtlcCallbackDSMCollection_1_row6.ERROR_CODE)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_EtlcCallbackDSMCollection_1_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_EtlcCallbackDSMCollection_1_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_EtlcCallbackDSMCollection_1_tLogRow_1);
                    }
                    	log.info("EtlcCallbackDSMCollection_1_tLogRow_1 - Content of row "+(nb_line_EtlcCallbackDSMCollection_1_tLogRow_1+1)+": " + strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1.toString());
                    consoleOut_EtlcCallbackDSMCollection_1_tLogRow_1.println(strBuffer_EtlcCallbackDSMCollection_1_tLogRow_1.toString());
                    consoleOut_EtlcCallbackDSMCollection_1_tLogRow_1.flush();
                    nb_line_EtlcCallbackDSMCollection_1_tLogRow_1++;
//////

//////                    
                    
///////////////////////    			

 
     EtlcCallbackDSMCollection_1_row1 = EtlcCallbackDSMCollection_1_row6;


	tos_count_EtlcCallbackDSMCollection_1_tLogRow_1++;

/**
 * [EtlcCallbackDSMCollection_1_tLogRow_1 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_2";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row1 - " + (EtlcCallbackDSMCollection_1_row1==null? "": EtlcCallbackDSMCollection_1_row1.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_EtlcCallbackDSMCollection_1_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_2 = false;
		  boolean mainRowRejected_EtlcCallbackDSMCollection_1_tMap_2 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "EtlcCallbackDSMCollection_1_row7" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLoopEtlcCallbackDSMCollection_1_row7 = false;
       		  	    	
       		  	    	
 							EtlcCallbackDSMCollection_1_row7Struct EtlcCallbackDSMCollection_1_row7ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_2) { // G_TM_M_020

								

								
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_EtlcCallbackDSMCollection_1_row7.lookup( EtlcCallbackDSMCollection_1_row7HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_EtlcCallbackDSMCollection_1_row7.hasNext()) { // G_TM_M_090

  								
		  				
	  								
						
									
	
		  								forceLoopEtlcCallbackDSMCollection_1_row7 = true;
	  					
  									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
								
								else { // G 20 - G 21
   									forceLoopEtlcCallbackDSMCollection_1_row7 = true;
			           		  	} // G 21
                    		  	
                    		

							EtlcCallbackDSMCollection_1_row7Struct EtlcCallbackDSMCollection_1_row7 = null;
                    		  	 
							

								while ((tHash_Lookup_EtlcCallbackDSMCollection_1_row7 != null && tHash_Lookup_EtlcCallbackDSMCollection_1_row7.hasNext()) || forceLoopEtlcCallbackDSMCollection_1_row7) { // G_TM_M_043

								
									 // CALL close loop of lookup 'EtlcCallbackDSMCollection_1_row7'
									
                    		  	 
							   
                    		  	 
	       		  	    	EtlcCallbackDSMCollection_1_row7Struct fromLookup_EtlcCallbackDSMCollection_1_row7 = null;
							EtlcCallbackDSMCollection_1_row7 = EtlcCallbackDSMCollection_1_row7Default;
										 
							
								
								if(!forceLoopEtlcCallbackDSMCollection_1_row7) { // G 46
								
							
								 
							
								
								fromLookup_EtlcCallbackDSMCollection_1_row7 = tHash_Lookup_EtlcCallbackDSMCollection_1_row7.next();

							

							if(fromLookup_EtlcCallbackDSMCollection_1_row7 != null) {
								EtlcCallbackDSMCollection_1_row7 = fromLookup_EtlcCallbackDSMCollection_1_row7;
							}
							
							
							
			  							
								
	                    		  	
		                    
	                    	
	                    		} // G 46
	                    		  	
								forceLoopEtlcCallbackDSMCollection_1_row7 = false;
									 	
							
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        // ###############################
        // ###############################
        // # Output tables

EtlcCallbackDSMCollection_1_successOut = null;


// # Output table : 'EtlcCallbackDSMCollection_1_successOut'
count_EtlcCallbackDSMCollection_1_successOut_EtlcCallbackDSMCollection_1_tMap_2++;

EtlcCallbackDSMCollection_1_successOut_tmp.message = ",\"message\":{\"body\":\"" +  EtlcCallbackDSMCollection_1_row6.Body.replace("\\","/").replace("\"","") + "\",\"error_code\":\"" + EtlcCallbackDSMCollection_1_row6.ERROR_CODE + "\"}"   ;
EtlcCallbackDSMCollection_1_successOut_tmp.context = ",\"context\":{\"" + EtlcCallbackDSMCollection_1_row7.context + "\"}" ;
EtlcCallbackDSMCollection_1_successOut = EtlcCallbackDSMCollection_1_successOut_tmp;
log.debug("EtlcCallbackDSMCollection_1_tMap_2 - Outputting the record " + count_EtlcCallbackDSMCollection_1_successOut_EtlcCallbackDSMCollection_1_tMap_2 + " of the output table 'EtlcCallbackDSMCollection_1_successOut'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_2 = false;










 


	tos_count_EtlcCallbackDSMCollection_1_tMap_2++;

/**
 * [EtlcCallbackDSMCollection_1_tMap_2 main ] stop
 */
// Start of branch "EtlcCallbackDSMCollection_1_successOut"
if(EtlcCallbackDSMCollection_1_successOut != null) { 



	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_3";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_successOut - " + (EtlcCallbackDSMCollection_1_successOut==null? "": EtlcCallbackDSMCollection_1_successOut.toLogString()));
    			}
    		

globalMap.put("successResponse", "{\"details\":{\"time\":\""+TalendDate.formatDate("yyyy-MM-dd HH:mm:ss",TalendDate.getCurrentDate())+"\",\"result\":\"success\""+EtlcCallbackDSMCollection_1_successOut.message+EtlcCallbackDSMCollection_1_successOut.context+"}}");

 


	tos_count_EtlcCallbackDSMCollection_1_tSetGlobalVar_3++;

/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 main ] stop
 */

} // End of branch "EtlcCallbackDSMCollection_1_successOut"



	
		} // close loop of lookup 'EtlcCallbackDSMCollection_1_row7' // G_TM_M_043
	






	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_1";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tREST_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tREST_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tREST_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_1";

	


//////
//////
globalMap.put("EtlcCallbackDSMCollection_1_tLogRow_1_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tLogRow_1);
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tLogRow_1 - "  + "Printed row count: "  + nb_line_EtlcCallbackDSMCollection_1_tLogRow_1  + "." );

///////////////////////    			

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tLogRow_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_2";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_EtlcCallbackDSMCollection_1_row7 != null) {
						tHash_Lookup_EtlcCallbackDSMCollection_1_row7.endGet();
					}
					globalMap.remove( "tHash_Lookup_EtlcCallbackDSMCollection_1_row7" );

					
					
				
// ###############################      
				log.debug("EtlcCallbackDSMCollection_1_tMap_2 - Written records count in the table 'EtlcCallbackDSMCollection_1_successOut': " + count_EtlcCallbackDSMCollection_1_successOut_EtlcCallbackDSMCollection_1_tMap_2 + ".");





 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_2 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tMap_2", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tMap_2 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_3";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_3 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_3", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_3", System.currentTimeMillis());

				EtlcCallbackDSMCollection_1_tREST_2Process(globalMap);



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
					     			//free memory for "EtlcCallbackDSMCollection_1_tMap_2"
					     			globalMap.remove("tHash_Lookup_EtlcCallbackDSMCollection_1_row7"); 
				     			
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tREST_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tLogRow_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tMap_2 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_3";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_3 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tREST_1_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_row10Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row10Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String Body;

				public String getBody () {
					return this.Body;
				}
				
			    public Integer ERROR_CODE;

				public Integer getERROR_CODE () {
					return this.ERROR_CODE;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.Body = readString(dis);
					
						this.ERROR_CODE = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Body,dos);
					
					// Integer
				
						writeInteger(this.ERROR_CODE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Body="+Body);
		sb.append(",ERROR_CODE="+String.valueOf(ERROR_CODE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Body == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Body);
            			}
            		
        			sb.append("|");
        		
        				if(ERROR_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ERROR_CODE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tREST_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tREST_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		EtlcCallbackDSMCollection_1_row10Struct EtlcCallbackDSMCollection_1_row10 = new EtlcCallbackDSMCollection_1_row10Struct();




	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_3", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_3", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_3";

	
		int tos_count_EtlcCallbackDSMCollection_1_tLogRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_3 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("BASIC_MODE" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("VERTICAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_3 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tLogRow_3 );

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_EtlcCallbackDSMCollection_1_tLogRow_3 = "|";
		java.io.PrintStream consoleOut_EtlcCallbackDSMCollection_1_tLogRow_3 = null;	

 		StringBuilder strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3 = null;
		int nb_line_EtlcCallbackDSMCollection_1_tLogRow_3 = 0;
///////////////////////    			



 



/**
 * [EtlcCallbackDSMCollection_1_tLogRow_3 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tREST_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tREST_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tREST_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_2 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tREST_2 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append("URL" + " = " + "context.controllerDetailsCallbackUri");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append("METHOD" + " = " + "PUT");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append("HEADERS" + " = " + "[{VALUE="+("\"application/json\"")+", NAME="+("\"Content-Type\"")+"}, {VALUE="+("((String)globalMap.get(\"successResponse\")).length()")+", NAME="+("\"Content-Length\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append("BODY" + " = " + "((String)globalMap.get(\"successResponse\"))");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_2 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tREST_2 );
	

	
	String endpoint_EtlcCallbackDSMCollection_1_tREST_2 = context.controllerDetailsCallbackUri;
	
	String trustStoreFile_EtlcCallbackDSMCollection_1_tREST_2 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_EtlcCallbackDSMCollection_1_tREST_2 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_EtlcCallbackDSMCollection_1_tREST_2 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_EtlcCallbackDSMCollection_1_tREST_2 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_EtlcCallbackDSMCollection_1_tREST_2 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_EtlcCallbackDSMCollection_1_tREST_2 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_EtlcCallbackDSMCollection_1_tREST_2 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	javax.net.ssl.SSLContext ctx_EtlcCallbackDSMCollection_1_tREST_2 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_EtlcCallbackDSMCollection_1_tREST_2 = null;
	if(trustStoreFile_EtlcCallbackDSMCollection_1_tREST_2!=null && trustStoreType_EtlcCallbackDSMCollection_1_tREST_2!=null){
		char[] password_EtlcCallbackDSMCollection_1_tREST_2 = null;
		if(trustStorePWD_EtlcCallbackDSMCollection_1_tREST_2!=null)
			password_EtlcCallbackDSMCollection_1_tREST_2 = trustStorePWD_EtlcCallbackDSMCollection_1_tREST_2.toCharArray();
		java.security.KeyStore trustStore_EtlcCallbackDSMCollection_1_tREST_2 = java.security.KeyStore.getInstance(trustStoreType_EtlcCallbackDSMCollection_1_tREST_2);
		trustStore_EtlcCallbackDSMCollection_1_tREST_2.load(new java.io.FileInputStream(trustStoreFile_EtlcCallbackDSMCollection_1_tREST_2), password_EtlcCallbackDSMCollection_1_tREST_2);
		
		javax.net.ssl.TrustManagerFactory tmf_EtlcCallbackDSMCollection_1_tREST_2 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_EtlcCallbackDSMCollection_1_tREST_2.init(trustStore_EtlcCallbackDSMCollection_1_tREST_2);
        tms_EtlcCallbackDSMCollection_1_tREST_2 = tmf_EtlcCallbackDSMCollection_1_tREST_2.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_EtlcCallbackDSMCollection_1_tREST_2 = null;
	if(keyStoreFile_EtlcCallbackDSMCollection_1_tREST_2!=null && keyStoreType_EtlcCallbackDSMCollection_1_tREST_2!=null){
		char[] password_EtlcCallbackDSMCollection_1_tREST_2 = null;
		if(keyStorePWD_EtlcCallbackDSMCollection_1_tREST_2!=null)
			password_EtlcCallbackDSMCollection_1_tREST_2 = keyStorePWD_EtlcCallbackDSMCollection_1_tREST_2.toCharArray();
		java.security.KeyStore keyStore_EtlcCallbackDSMCollection_1_tREST_2 = java.security.KeyStore.getInstance(keyStoreType_EtlcCallbackDSMCollection_1_tREST_2);
		keyStore_EtlcCallbackDSMCollection_1_tREST_2.load(new java.io.FileInputStream(keyStoreFile_EtlcCallbackDSMCollection_1_tREST_2), password_EtlcCallbackDSMCollection_1_tREST_2);
		
		javax.net.ssl.KeyManagerFactory kmf_EtlcCallbackDSMCollection_1_tREST_2 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_EtlcCallbackDSMCollection_1_tREST_2.init(keyStore_EtlcCallbackDSMCollection_1_tREST_2,password_EtlcCallbackDSMCollection_1_tREST_2);
        kms_EtlcCallbackDSMCollection_1_tREST_2 = kmf_EtlcCallbackDSMCollection_1_tREST_2.getKeyManagers();
	}
	
    ctx_EtlcCallbackDSMCollection_1_tREST_2.init(kms_EtlcCallbackDSMCollection_1_tREST_2, tms_EtlcCallbackDSMCollection_1_tREST_2 , null);
    config_EtlcCallbackDSMCollection_1_tREST_2.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_EtlcCallbackDSMCollection_1_tREST_2));

	com.sun.jersey.api.client.Client restClient_EtlcCallbackDSMCollection_1_tREST_2 = com.sun.jersey.api.client.Client.create(config_EtlcCallbackDSMCollection_1_tREST_2);
	com.sun.jersey.api.client.WebResource restResource_EtlcCallbackDSMCollection_1_tREST_2;
	if(endpoint_EtlcCallbackDSMCollection_1_tREST_2!=null && !("").equals(endpoint_EtlcCallbackDSMCollection_1_tREST_2)){
		restResource_EtlcCallbackDSMCollection_1_tREST_2 = restClient_EtlcCallbackDSMCollection_1_tREST_2.resource(endpoint_EtlcCallbackDSMCollection_1_tREST_2);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_EtlcCallbackDSMCollection_1_tREST_2 = null;
	String restResponse_EtlcCallbackDSMCollection_1_tREST_2 = "";
	try{
		
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tREST_2 - "  + "Prepare to send request to rest server." );
		restResponse_EtlcCallbackDSMCollection_1_tREST_2 = restResource_EtlcCallbackDSMCollection_1_tREST_2
		
        	.header("Content-Type","application/json")
		
        	.header("Content-Length",((String)globalMap.get("successResponse")).length())
		  
		
			.put(String.class,((String)globalMap.get("successResponse")));
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
        errorResponse_EtlcCallbackDSMCollection_1_tREST_2 = ue.getResponse();
    }
	
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tREST_2 - "  + "Has sent request to rest server." );
	// for output
			
				EtlcCallbackDSMCollection_1_row10 = new EtlcCallbackDSMCollection_1_row10Struct();
				if(errorResponse_EtlcCallbackDSMCollection_1_tREST_2!=null){
					EtlcCallbackDSMCollection_1_row10.Body = errorResponse_EtlcCallbackDSMCollection_1_tREST_2.getEntity(String.class);
					EtlcCallbackDSMCollection_1_row10.ERROR_CODE = errorResponse_EtlcCallbackDSMCollection_1_tREST_2.getStatus();
				}else{
					EtlcCallbackDSMCollection_1_row10.Body = restResponse_EtlcCallbackDSMCollection_1_tREST_2;
				}
			

 



/**
 * [EtlcCallbackDSMCollection_1_tREST_2 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_2";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tREST_2++;

/**
 * [EtlcCallbackDSMCollection_1_tREST_2 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_3 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_3";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row10 - " + (EtlcCallbackDSMCollection_1_row10==null? "": EtlcCallbackDSMCollection_1_row10.toLogString()));
    			}
    		
///////////////////////		
						



				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3 = new StringBuilder();




   				
	    		if(EtlcCallbackDSMCollection_1_row10.Body != null) { //              
                    							
       
				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3.append(
				                String.valueOf(EtlcCallbackDSMCollection_1_row10.Body)							
				);


							
	    		} //  			

    			strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3.append("|");
    			


   				
	    		if(EtlcCallbackDSMCollection_1_row10.ERROR_CODE != null) { //              
                    							
       
				strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3.append(
				                String.valueOf(EtlcCallbackDSMCollection_1_row10.ERROR_CODE)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_EtlcCallbackDSMCollection_1_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_EtlcCallbackDSMCollection_1_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_EtlcCallbackDSMCollection_1_tLogRow_3);
                    }
                    	log.info("EtlcCallbackDSMCollection_1_tLogRow_3 - Content of row "+(nb_line_EtlcCallbackDSMCollection_1_tLogRow_3+1)+": " + strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3.toString());
                    consoleOut_EtlcCallbackDSMCollection_1_tLogRow_3.println(strBuffer_EtlcCallbackDSMCollection_1_tLogRow_3.toString());
                    consoleOut_EtlcCallbackDSMCollection_1_tLogRow_3.flush();
                    nb_line_EtlcCallbackDSMCollection_1_tLogRow_3++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_EtlcCallbackDSMCollection_1_tLogRow_3++;

/**
 * [EtlcCallbackDSMCollection_1_tLogRow_3 main ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_2";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_2 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tREST_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tREST_2", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tREST_2 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_3 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_3";

	


//////
//////
globalMap.put("EtlcCallbackDSMCollection_1_tLogRow_3_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tLogRow_3);
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tLogRow_3 - "  + "Printed row count: "  + nb_line_EtlcCallbackDSMCollection_1_tLogRow_3  + "." );

///////////////////////    			

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogRow_3 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_3", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tLogRow_3", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tLogRow_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tREST_2 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogRow_3 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogRow_3";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tLogRow_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tREST_2_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tWarn_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_2 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append("MESSAGE" + " = " + "\"Unable to send file response\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append("CODE" + " = " + "42");
                log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append("PRIORITY" + " = " + "4");
                log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_2 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tWarn_2 );

 



/**
 * [EtlcCallbackDSMCollection_1_tWarn_2 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_2";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:EtlcCallbackDSMCollection_1_tWarn_2", "", Thread.currentThread().getId() + "", "WARN","","Unable to send file response","", "");
            log.warn("EtlcCallbackDSMCollection_1_tWarn_2 - "  + "Message: "  + "Unable to send file response"  + ". Code: "  + 42 );
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_2 - "  + "Sending message to EtlcCallbackDSMCollection_1_tLogCatcher_1." );
	EtlcCallbackDSMCollection_1_tLogCatcher_1.addMessage("tWarn", "EtlcCallbackDSMCollection_1_tWarn_2", 4, "Unable to send file response", 42);
	EtlcCallbackDSMCollection_1_tLogCatcher_1Process(globalMap);
globalMap.put("EtlcCallbackDSMCollection_1_tWarn_2_WARN_MESSAGES", "Unable to send file response"); 
globalMap.put("EtlcCallbackDSMCollection_1_tWarn_2_WARN_PRIORITY", 4);
globalMap.put("EtlcCallbackDSMCollection_1_tWarn_2_WARN_CODE", 42);


 


	tos_count_EtlcCallbackDSMCollection_1_tWarn_2++;

/**
 * [EtlcCallbackDSMCollection_1_tWarn_2 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_2";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_2 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tWarn_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tWarn_2", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tWarn_2_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tWarn_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append("MESSAGE" + " = " + "\"Unable to send file response\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append("CODE" + " = " + "42");
                log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append("PRIORITY" + " = " + "4");
                log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tWarn_1 );

 



/**
 * [EtlcCallbackDSMCollection_1_tWarn_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_1";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:EtlcCallbackDSMCollection_1_tWarn_1", "", Thread.currentThread().getId() + "", "WARN","","Unable to send file response","", "");
            log.warn("EtlcCallbackDSMCollection_1_tWarn_1 - "  + "Message: "  + "Unable to send file response"  + ". Code: "  + 42 );
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_1 - "  + "Sending message to EtlcCallbackDSMCollection_1_tLogCatcher_1." );
	EtlcCallbackDSMCollection_1_tLogCatcher_1.addMessage("tWarn", "EtlcCallbackDSMCollection_1_tWarn_1", 4, "Unable to send file response", 42);
	EtlcCallbackDSMCollection_1_tLogCatcher_1Process(globalMap);
globalMap.put("EtlcCallbackDSMCollection_1_tWarn_1_WARN_MESSAGES", "Unable to send file response"); 
globalMap.put("EtlcCallbackDSMCollection_1_tWarn_1_WARN_PRIORITY", 4);
globalMap.put("EtlcCallbackDSMCollection_1_tWarn_1_WARN_CODE", 42);


 


	tos_count_EtlcCallbackDSMCollection_1_tWarn_1++;

/**
 * [EtlcCallbackDSMCollection_1_tWarn_1 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_1";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tWarn_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tWarn_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tWarn_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tWarn_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tWarn_1_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tDie_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tDie_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tDie_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tDie_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDie_2 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tDie_2 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append("MESSAGE" + " = " + "\"FAILURE - rejected records exceeded threshold\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append("CODE" + " = " + "4");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append("PRIORITY" + " = " + "5");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append("EXIT_JVM" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDie_2 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tDie_2 );

 



/**
 * [EtlcCallbackDSMCollection_1_tDie_2 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_2";

	


				EtlcCallbackDSMCollection_1_tLogCatcher_2.addMessage("tDie", "EtlcCallbackDSMCollection_1_tDie_2", 5, "FAILURE - rejected records exceeded threshold", 4);
				EtlcCallbackDSMCollection_1_tLogCatcher_2Process(globalMap);
				
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_2_DIE_PRIORITY", 5);
	System.err.println("FAILURE - rejected records exceeded threshold");
	
		log.error("EtlcCallbackDSMCollection_1_tDie_2 - The die message: "+"FAILURE - rejected records exceeded threshold");
	
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_2_DIE_MESSAGE", "FAILURE - rejected records exceeded threshold");
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_2_DIE_MESSAGES", "FAILURE - rejected records exceeded threshold");
	currentComponent = "EtlcCallbackDSMCollection_1_tDie_2";
	status = "failure";
        errorCode = new Integer(4);
        globalMap.put("EtlcCallbackDSMCollection_1_tDie_2_DIE_CODE", errorCode);        
    
	if(true){	
	    throw new TDieException();
	}

 


	tos_count_EtlcCallbackDSMCollection_1_tDie_2++;

/**
 * [EtlcCallbackDSMCollection_1_tDie_2 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_2";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDie_2 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tDie_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tDie_2", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tDie_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tDie_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tDie_2_SUBPROCESS_STATE", 1);
	}
	

public void tSleep_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSleep_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSleep_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSleep_1", false);
		start_Hash.put("tSleep_1", System.currentTimeMillis());
		
	
	currentComponent="tSleep_1";

	
		int tos_count_tSleep_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + "Start to work." );
            StringBuilder log4jParamters_tSleep_1 = new StringBuilder();
            log4jParamters_tSleep_1.append("Parameters:");
                    log4jParamters_tSleep_1.append("PAUSE" + " = " + "0");
                log4jParamters_tSleep_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + log4jParamters_tSleep_1 );

 



/**
 * [tSleep_1 begin ] stop
 */
	
	/**
	 * [tSleep_1 main ] start
	 */

	

	
	
	currentComponent="tSleep_1";

	

    Thread.sleep((0)*1000);

 


	tos_count_tSleep_1++;

/**
 * [tSleep_1 main ] stop
 */
	
	/**
	 * [tSleep_1 end ] start
	 */

	

	
	
	currentComponent="tSleep_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + "Done." );

ok_Hash.put("tSleep_1", true);
end_Hash.put("tSleep_1", System.currentTimeMillis());

   			if (context.useDsm) {
   				
    			tFileDelete_1Process(globalMap);
   			}

			



/**
 * [tSleep_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSleep_1 finally ] start
	 */

	

	
	
	currentComponent="tSleep_1";

	

 



/**
 * [tSleep_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSleep_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileDelete_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileDelete_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_1", false);
		start_Hash.put("tFileDelete_1", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_1";

	
		int tos_count_tFileDelete_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileDelete_1 = new StringBuilder();
            log4jParamters_tFileDelete_1.append("Parameters:");
                    log4jParamters_tFileDelete_1.append("PATH" + " = " + "context.inputDirectory");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FAILON" + " = " + "true");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER_FILE" + " = " + "true");
                log4jParamters_tFileDelete_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + log4jParamters_tFileDelete_1 );

 



/**
 * [tFileDelete_1 begin ] stop
 */
	
	/**
	 * [tFileDelete_1 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 

				final StringBuffer log4jSb_tFileDelete_1 = new StringBuffer();
			
class DeleteFoldertFileDelete_1{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
	java.io.File path_tFileDelete_1=new java.io.File(context.inputDirectory);
	if(path_tFileDelete_1.exists()){
		if(path_tFileDelete_1.isFile()){
	    	if(path_tFileDelete_1.delete()){
	    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "File deleted.");
				log.info("tFileDelete_1 - File : "+ path_tFileDelete_1.getAbsolutePath() + " is deleted.");
	    	}else{
	    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "No file deleted.");
				log.info("tFileDelete_1 - Fail to delete file : "+ path_tFileDelete_1.getAbsolutePath());
	    	}
		}else if(path_tFileDelete_1.isDirectory()){ 
	    	DeleteFoldertFileDelete_1 dftFileDelete_1 = new DeleteFoldertFileDelete_1();
	    	if(dftFileDelete_1.delete(path_tFileDelete_1)){
	    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "Path deleted.");
				log.info("tFileDelete_1 - Directory : "+ path_tFileDelete_1.getAbsolutePath() + " is deleted.");
	    	}else{
	    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "No path deleted.");
				log.info("tFileDelete_1 - Fail to delete directory : "+ path_tFileDelete_1.getAbsolutePath());
	    	}
		}
    }else{
		globalMap.put("tFileDelete_1_CURRENT_STATUS", "File or path does not exist or is invalid.");
    		throw new RuntimeException("File or path does not exist or is invalid.");
    }
    globalMap.put("tFileDelete_1_DELETE_PATH",context.inputDirectory);
    
     
 

 


	tos_count_tFileDelete_1++;

/**
 * [tFileDelete_1 main ] stop
 */
	
	/**
	 * [tFileDelete_1 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + "Done." );

ok_Hash.put("tFileDelete_1", true);
end_Hash.put("tFileDelete_1", System.currentTimeMillis());

				tFileDelete_2Process(globalMap);



/**
 * [tFileDelete_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_1 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 



/**
 * [tFileDelete_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileDelete_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFileDelete_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_2", false);
		start_Hash.put("tFileDelete_2", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_2";

	
		int tos_count_tFileDelete_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + "Start to work." );
            StringBuilder log4jParamters_tFileDelete_2 = new StringBuilder();
            log4jParamters_tFileDelete_2.append("Parameters:");
                    log4jParamters_tFileDelete_2.append("PATH" + " = " + "context.outputDirectory");
                log4jParamters_tFileDelete_2.append(" | ");
                    log4jParamters_tFileDelete_2.append("FAILON" + " = " + "true");
                log4jParamters_tFileDelete_2.append(" | ");
                    log4jParamters_tFileDelete_2.append("FOLDER_FILE" + " = " + "true");
                log4jParamters_tFileDelete_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + log4jParamters_tFileDelete_2 );

 



/**
 * [tFileDelete_2 begin ] stop
 */
	
	/**
	 * [tFileDelete_2 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";

	

 

				final StringBuffer log4jSb_tFileDelete_2 = new StringBuffer();
			
class DeleteFoldertFileDelete_2{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
	java.io.File path_tFileDelete_2=new java.io.File(context.outputDirectory);
	if(path_tFileDelete_2.exists()){
		if(path_tFileDelete_2.isFile()){
	    	if(path_tFileDelete_2.delete()){
	    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "File deleted.");
				log.info("tFileDelete_2 - File : "+ path_tFileDelete_2.getAbsolutePath() + " is deleted.");
	    	}else{
	    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "No file deleted.");
				log.info("tFileDelete_2 - Fail to delete file : "+ path_tFileDelete_2.getAbsolutePath());
	    	}
		}else if(path_tFileDelete_2.isDirectory()){ 
	    	DeleteFoldertFileDelete_2 dftFileDelete_2 = new DeleteFoldertFileDelete_2();
	    	if(dftFileDelete_2.delete(path_tFileDelete_2)){
	    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "Path deleted.");
				log.info("tFileDelete_2 - Directory : "+ path_tFileDelete_2.getAbsolutePath() + " is deleted.");
	    	}else{
	    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "No path deleted.");
				log.info("tFileDelete_2 - Fail to delete directory : "+ path_tFileDelete_2.getAbsolutePath());
	    	}
		}
    }else{
		globalMap.put("tFileDelete_2_CURRENT_STATUS", "File or path does not exist or is invalid.");
    		throw new RuntimeException("File or path does not exist or is invalid.");
    }
    globalMap.put("tFileDelete_2_DELETE_PATH",context.outputDirectory);
    
     
 

 


	tos_count_tFileDelete_2++;

/**
 * [tFileDelete_2 main ] stop
 */
	
	/**
	 * [tFileDelete_2 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + "Done." );

ok_Hash.put("tFileDelete_2", true);
end_Hash.put("tFileDelete_2", System.currentTimeMillis());




/**
 * [tFileDelete_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_2 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";

	

 



/**
 * [tFileDelete_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_2_SUBPROCESS_STATE", 1);
	}
	

public void DSMRetailerFileFetch_1_tFileExist_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMRetailerFileFetch_1_tFileExist_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_2 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMRetailerFileFetch_1_tFileExist_2", false);
		start_Hash.put("DSMRetailerFileFetch_1_tFileExist_2", System.currentTimeMillis());
		
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_2";

	
		int tos_count_DSMRetailerFileFetch_1_tFileExist_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileExist_2 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMRetailerFileFetch_1_tFileExist_2 = new StringBuilder();
            log4jParamters_DSMRetailerFileFetch_1_tFileExist_2.append("Parameters:");
                    log4jParamters_DSMRetailerFileFetch_1_tFileExist_2.append("FILE_NAME" + " = " + "context.outputDirectory");
                log4jParamters_DSMRetailerFileFetch_1_tFileExist_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileExist_2 - "  + log4jParamters_DSMRetailerFileFetch_1_tFileExist_2 );

 



/**
 * [DSMRetailerFileFetch_1_tFileExist_2 begin ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_2 main ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_2";

	


				final StringBuffer log4jSb_DSMRetailerFileFetch_1_tFileExist_2 = new StringBuffer();
			

java.io.File file_DSMRetailerFileFetch_1_tFileExist_2 = new java.io.File(context.outputDirectory);
if (!file_DSMRetailerFileFetch_1_tFileExist_2.exists()) {
    globalMap.put("DSMRetailerFileFetch_1_tFileExist_2_EXISTS",false);
    log.info("DSMRetailerFileFetch_1_tFileExist_2 - Directory or file : " + file_DSMRetailerFileFetch_1_tFileExist_2.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("DSMRetailerFileFetch_1_tFileExist_2_EXISTS",true);
    log.info("DSMRetailerFileFetch_1_tFileExist_2 - Directory or file : " + file_DSMRetailerFileFetch_1_tFileExist_2.getAbsolutePath() + " exists.");
}

globalMap.put("DSMRetailerFileFetch_1_tFileExist_2_FILENAME",context.outputDirectory);


 


	tos_count_DSMRetailerFileFetch_1_tFileExist_2++;

/**
 * [DSMRetailerFileFetch_1_tFileExist_2 main ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_2 end ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_2";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileExist_2 - "  + "Done." );

ok_Hash.put("DSMRetailerFileFetch_1_tFileExist_2", true);
end_Hash.put("DSMRetailerFileFetch_1_tFileExist_2", System.currentTimeMillis());

   			if (!((Boolean)globalMap.get("DSMRetailerFileFetch_1_tFileExist_2_EXISTS"))) {
   				
    			DSMRetailerFileFetch_1_tFileFetch_1Process(globalMap);
   			}

			
   			if (((Boolean)globalMap.get("DSMRetailerFileFetch_1_tFileExist_2_EXISTS"))) {
   				
    			DSMRetailerFileFetch_1_tDie_1Process(globalMap);
   			}

			



/**
 * [DSMRetailerFileFetch_1_tFileExist_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMRetailerFileFetch_1_tFileExist_2 finally ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileExist_2";

	

 



/**
 * [DSMRetailerFileFetch_1_tFileExist_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMRetailerFileFetch_1_tFileExist_2_SUBPROCESS_STATE", 1);
	}
	

public void DSMRetailerFileFetch_1_tFileFetch_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMRetailerFileFetch_1_tFileFetch_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [DSMRetailerFileFetch_1_tFileFetch_1 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMRetailerFileFetch_1_tFileFetch_1", false);
		start_Hash.put("DSMRetailerFileFetch_1_tFileFetch_1", System.currentTimeMillis());
		
	
	currentComponent="DSMRetailerFileFetch_1_tFileFetch_1";

	
		int tos_count_DSMRetailerFileFetch_1_tFileFetch_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileFetch_1 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1 = new StringBuilder();
            log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("Parameters:");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("PROTO" + " = " + "http");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("POST" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("URI" + " = " + "context.dsmEndPoint + \"/file/\" + context.path");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("USE_CACHE" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("DIRECTORY" + " = " + "context.inputDirectory");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("MAKEDIRS" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("FILENAME" + " = " + "context.file");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("ADD_HEADER" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("READ_COOKIE" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("SAVE_COOKIE" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("PRINT" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("TIMEOUT" + " = " + "1000");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("USE_PROXY" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("PROXY_NTLM" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("NEED_AUTH" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append("REDIRECT" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileFetch_1 - "  + log4jParamters_DSMRetailerFileFetch_1_tFileFetch_1 );

 



/**
 * [DSMRetailerFileFetch_1_tFileFetch_1 begin ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tFileFetch_1 main ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileFetch_1";

	

java.io.InputStream retIS_DSMRetailerFileFetch_1_tFileFetch_1 = null;

	org.apache.commons.httpclient.HttpClient client_DSMRetailerFileFetch_1_tFileFetch_1 = new org.apache.commons.httpclient.HttpClient();
	
		log.info("DSMRetailerFileFetch_1_tFileFetch_1 - Connection attempt to '" + context.dsmEndPoint + "/file/" + context.path);
	
	client_DSMRetailerFileFetch_1_tFileFetch_1.getHttpConnectionManager().getParams().setConnectionTimeout(1000);
	
		log.info("DSMRetailerFileFetch_1_tFileFetch_1 - Connection to '" +  context.dsmEndPoint + "/file/" + context.path + "' has succeeded.");
	
	client_DSMRetailerFileFetch_1_tFileFetch_1.getParams().setCookiePolicy(org.apache.commons.httpclient.cookie.CookiePolicy.DEFAULT);
	
	
		org.apache.commons.httpclient.methods.GetMethod method_DSMRetailerFileFetch_1_tFileFetch_1 = new org.apache.commons.httpclient.methods.GetMethod(context.dsmEndPoint + "/file/" + context.path);
	
	boolean isContinue_DSMRetailerFileFetch_1_tFileFetch_1 = true;
	int status_DSMRetailerFileFetch_1_tFileFetch_1;
	String finalURL_DSMRetailerFileFetch_1_tFileFetch_1 = context.dsmEndPoint + "/file/" + context.path;

	try { // B_01
		
			status_DSMRetailerFileFetch_1_tFileFetch_1  = client_DSMRetailerFileFetch_1_tFileFetch_1.executeMethod(method_DSMRetailerFileFetch_1_tFileFetch_1);
		
			if (status_DSMRetailerFileFetch_1_tFileFetch_1 != org.apache.commons.httpclient.HttpStatus.SC_OK) {      
				throw new java.lang.Exception("Method failed: " + method_DSMRetailerFileFetch_1_tFileFetch_1.getStatusLine());
			}
		
	} catch(java.lang.Exception e) {
		
			throw(e);
		
	}

	if (isContinue_DSMRetailerFileFetch_1_tFileFetch_1) {    
		
			java.io.InputStream in_DSMRetailerFileFetch_1_tFileFetch_1 = method_DSMRetailerFileFetch_1_tFileFetch_1.getResponseBodyAsStream();
			String sDir_DSMRetailerFileFetch_1_tFileFetch_1 = (context.inputDirectory).trim();
			String fileName_DSMRetailerFileFetch_1_tFileFetch_1 = (context.file).trim();    
			//open directory
			java.net.URL url_DSMRetailerFileFetch_1_tFileFetch_1 = new java.net.URL(finalURL_DSMRetailerFileFetch_1_tFileFetch_1);
			String sURIPath_DSMRetailerFileFetch_1_tFileFetch_1 = "";
			int iLastSlashIndex_DSMRetailerFileFetch_1_tFileFetch_1 = 0;
			sURIPath_DSMRetailerFileFetch_1_tFileFetch_1 = url_DSMRetailerFileFetch_1_tFileFetch_1.getFile();
			iLastSlashIndex_DSMRetailerFileFetch_1_tFileFetch_1 = sURIPath_DSMRetailerFileFetch_1_tFileFetch_1.lastIndexOf("/");

			

			// if not input file name, get the name from URI
			if ("".equals(fileName_DSMRetailerFileFetch_1_tFileFetch_1)) {      
				if (iLastSlashIndex_DSMRetailerFileFetch_1_tFileFetch_1 > 0 && (!sURIPath_DSMRetailerFileFetch_1_tFileFetch_1.endsWith("/"))) {
					fileName_DSMRetailerFileFetch_1_tFileFetch_1 = sURIPath_DSMRetailerFileFetch_1_tFileFetch_1.substring(iLastSlashIndex_DSMRetailerFileFetch_1_tFileFetch_1 + 1);
				} else {
					fileName_DSMRetailerFileFetch_1_tFileFetch_1 = "defaultfilename.txt";
				}
			}
			java.io.File dir_DSMRetailerFileFetch_1_tFileFetch_1 = new java.io.File(sDir_DSMRetailerFileFetch_1_tFileFetch_1);

			// pretreatment
			try {
				java.io.File test_file_DSMRetailerFileFetch_1_tFileFetch_1 = new java.io.File(dir_DSMRetailerFileFetch_1_tFileFetch_1, fileName_DSMRetailerFileFetch_1_tFileFetch_1);
				test_file_DSMRetailerFileFetch_1_tFileFetch_1.getParentFile().mkdirs();

				if (test_file_DSMRetailerFileFetch_1_tFileFetch_1.createNewFile()) {
					test_file_DSMRetailerFileFetch_1_tFileFetch_1.delete();
				}
			} catch(java.lang.Exception e) {
				
					log.warn("DSMRetailerFileFetch_1_tFileFetch_1 - " + e.getMessage());
				
				fileName_DSMRetailerFileFetch_1_tFileFetch_1 = "defaultfilename.txt";
			}
			java.io.File file_DSMRetailerFileFetch_1_tFileFetch_1 = new java.io.File(dir_DSMRetailerFileFetch_1_tFileFetch_1, fileName_DSMRetailerFileFetch_1_tFileFetch_1);
			file_DSMRetailerFileFetch_1_tFileFetch_1.getParentFile().mkdirs();    
			java.io.FileOutputStream out_DSMRetailerFileFetch_1_tFileFetch_1 = new java.io.FileOutputStream(file_DSMRetailerFileFetch_1_tFileFetch_1);
			byte[] buffer_DSMRetailerFileFetch_1_tFileFetch_1 = new byte[1024];
			int count_DSMRetailerFileFetch_1_tFileFetch_1 = 0;

			while ((count_DSMRetailerFileFetch_1_tFileFetch_1 = in_DSMRetailerFileFetch_1_tFileFetch_1.read(buffer_DSMRetailerFileFetch_1_tFileFetch_1)) > 0) {
				out_DSMRetailerFileFetch_1_tFileFetch_1.write(buffer_DSMRetailerFileFetch_1_tFileFetch_1, 0, count_DSMRetailerFileFetch_1_tFileFetch_1);
			}
			// close opened object
			in_DSMRetailerFileFetch_1_tFileFetch_1.close();   
			out_DSMRetailerFileFetch_1_tFileFetch_1.close(); 
			
				log.info("DSMRetailerFileFetch_1_tFileFetch_1 - Closing the connection to the server.");
			
			method_DSMRetailerFileFetch_1_tFileFetch_1.releaseConnection();
			
				log.info("DSMRetailerFileFetch_1_tFileFetch_1 - Connection to the server closed.");
			   
		    
	} // B_01
globalMap.put("DSMRetailerFileFetch_1_tFileFetch_1_INPUT_STREAM", retIS_DSMRetailerFileFetch_1_tFileFetch_1);

 


	tos_count_DSMRetailerFileFetch_1_tFileFetch_1++;

/**
 * [DSMRetailerFileFetch_1_tFileFetch_1 main ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tFileFetch_1 end ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileFetch_1";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tFileFetch_1 - "  + "Done." );

ok_Hash.put("DSMRetailerFileFetch_1_tFileFetch_1", true);
end_Hash.put("DSMRetailerFileFetch_1_tFileFetch_1", System.currentTimeMillis());




/**
 * [DSMRetailerFileFetch_1_tFileFetch_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMRetailerFileFetch_1_tFileFetch_1 finally ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tFileFetch_1";

	

 



/**
 * [DSMRetailerFileFetch_1_tFileFetch_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMRetailerFileFetch_1_tFileFetch_1_SUBPROCESS_STATE", 1);
	}
	

public void DSMRetailerFileFetch_1_tDie_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMRetailerFileFetch_1_tDie_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [DSMRetailerFileFetch_1_tDie_1 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMRetailerFileFetch_1_tDie_1", false);
		start_Hash.put("DSMRetailerFileFetch_1_tDie_1", System.currentTimeMillis());
		
	
	currentComponent="DSMRetailerFileFetch_1_tDie_1";

	
		int tos_count_DSMRetailerFileFetch_1_tDie_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tDie_1 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMRetailerFileFetch_1_tDie_1 = new StringBuilder();
            log4jParamters_DSMRetailerFileFetch_1_tDie_1.append("Parameters:");
                    log4jParamters_DSMRetailerFileFetch_1_tDie_1.append("MESSAGE" + " = " + "\"Error either input directory \" + context.inputDirectory + \" or output directory \" + context.outputDirectory + \" already exist.\"");
                log4jParamters_DSMRetailerFileFetch_1_tDie_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tDie_1.append("CODE" + " = " + "4");
                log4jParamters_DSMRetailerFileFetch_1_tDie_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tDie_1.append("PRIORITY" + " = " + "5");
                log4jParamters_DSMRetailerFileFetch_1_tDie_1.append(" | ");
                    log4jParamters_DSMRetailerFileFetch_1_tDie_1.append("EXIT_JVM" + " = " + "false");
                log4jParamters_DSMRetailerFileFetch_1_tDie_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tDie_1 - "  + log4jParamters_DSMRetailerFileFetch_1_tDie_1 );

 



/**
 * [DSMRetailerFileFetch_1_tDie_1 begin ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tDie_1 main ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tDie_1";

	


				EtlcCallbackDSMCollection_1_tLogCatcher_2.addMessage("tDie", "DSMRetailerFileFetch_1_tDie_1", 5, "Error either input directory " + context.inputDirectory + " or output directory " + context.outputDirectory + " already exist.", 4);
				EtlcCallbackDSMCollection_1_tLogCatcher_2Process(globalMap);
				
	globalMap.put("DSMRetailerFileFetch_1_tDie_1_DIE_PRIORITY", 5);
	System.err.println("Error either input directory " + context.inputDirectory + " or output directory " + context.outputDirectory + " already exist.");
	
		log.error("DSMRetailerFileFetch_1_tDie_1 - The die message: "+"Error either input directory " + context.inputDirectory + " or output directory " + context.outputDirectory + " already exist.");
	
	globalMap.put("DSMRetailerFileFetch_1_tDie_1_DIE_MESSAGE", "Error either input directory " + context.inputDirectory + " or output directory " + context.outputDirectory + " already exist.");
	globalMap.put("DSMRetailerFileFetch_1_tDie_1_DIE_MESSAGES", "Error either input directory " + context.inputDirectory + " or output directory " + context.outputDirectory + " already exist.");
	currentComponent = "DSMRetailerFileFetch_1_tDie_1";
	status = "failure";
        errorCode = new Integer(4);
        globalMap.put("DSMRetailerFileFetch_1_tDie_1_DIE_CODE", errorCode);        
    
	if(true){	
	    throw new TDieException();
	}

 


	tos_count_DSMRetailerFileFetch_1_tDie_1++;

/**
 * [DSMRetailerFileFetch_1_tDie_1 main ] stop
 */
	
	/**
	 * [DSMRetailerFileFetch_1_tDie_1 end ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tDie_1";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMRetailerFileFetch_1_tDie_1 - "  + "Done." );

ok_Hash.put("DSMRetailerFileFetch_1_tDie_1", true);
end_Hash.put("DSMRetailerFileFetch_1_tDie_1", System.currentTimeMillis());




/**
 * [DSMRetailerFileFetch_1_tDie_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMRetailerFileFetch_1_tDie_1 finally ] start
	 */

	

	
	
	currentComponent="DSMRetailerFileFetch_1_tDie_1";

	

 



/**
 * [DSMRetailerFileFetch_1_tDie_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMRetailerFileFetch_1_tDie_1_SUBPROCESS_STATE", 1);
	}
	

public void DSMFileWriter_1_tLibraryLoad_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMFileWriter_1_tLibraryLoad_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_1 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tLibraryLoad_1", false);
		start_Hash.put("DSMFileWriter_1_tLibraryLoad_1", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_1";

	
		int tos_count_DSMFileWriter_1_tLibraryLoad_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_1 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tLibraryLoad_1 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append("LIBRARY" + " = " + "\"jackson-core-asl-1.9.11.jar\"");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append("HOTLIBS" + " = " + "[]");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_1 - "  + log4jParamters_DSMFileWriter_1_tLibraryLoad_1 );



 



/**
 * [DSMFileWriter_1_tLibraryLoad_1 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_1 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_1";

	

 


	tos_count_DSMFileWriter_1_tLibraryLoad_1++;

/**
 * [DSMFileWriter_1_tLibraryLoad_1 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_1 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_1";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_1 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tLibraryLoad_1", true);
end_Hash.put("DSMFileWriter_1_tLibraryLoad_1", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tLibraryLoad_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_1 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_1";

	

 



/**
 * [DSMFileWriter_1_tLibraryLoad_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMFileWriter_1_tLibraryLoad_1_SUBPROCESS_STATE", 1);
	}
	

public void DSMFileWriter_1_tLibraryLoad_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMFileWriter_1_tLibraryLoad_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_2 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tLibraryLoad_2", false);
		start_Hash.put("DSMFileWriter_1_tLibraryLoad_2", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_2";

	
		int tos_count_DSMFileWriter_1_tLibraryLoad_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_2 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tLibraryLoad_2 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append("LIBRARY" + " = " + "\"itrader-dps-shared-0.0.1-SNAPSHOT.jar\"");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append("HOTLIBS" + " = " + "[]");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_2 - "  + log4jParamters_DSMFileWriter_1_tLibraryLoad_2 );



 



/**
 * [DSMFileWriter_1_tLibraryLoad_2 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_2 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_2";

	

 


	tos_count_DSMFileWriter_1_tLibraryLoad_2++;

/**
 * [DSMFileWriter_1_tLibraryLoad_2 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_2 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_2";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_2 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tLibraryLoad_2", true);
end_Hash.put("DSMFileWriter_1_tLibraryLoad_2", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tLibraryLoad_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:DSMFileWriter_1_tLibraryLoad_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							DSMFileWriter_1_tLibraryLoad_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_2 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_2";

	

 



/**
 * [DSMFileWriter_1_tLibraryLoad_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMFileWriter_1_tLibraryLoad_2_SUBPROCESS_STATE", 1);
	}
	

public void DSMFileWriter_1_tLibraryLoad_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMFileWriter_1_tLibraryLoad_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_3 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tLibraryLoad_3", false);
		start_Hash.put("DSMFileWriter_1_tLibraryLoad_3", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_3";

	
		int tos_count_DSMFileWriter_1_tLibraryLoad_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_3 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tLibraryLoad_3 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append("LIBRARY" + " = " + "\"guava-15.0.jar\"");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append("HOTLIBS" + " = " + "[]");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_3 - "  + log4jParamters_DSMFileWriter_1_tLibraryLoad_3 );



 



/**
 * [DSMFileWriter_1_tLibraryLoad_3 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_3 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_3";

	

 


	tos_count_DSMFileWriter_1_tLibraryLoad_3++;

/**
 * [DSMFileWriter_1_tLibraryLoad_3 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_3 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_3";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_3 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tLibraryLoad_3", true);
end_Hash.put("DSMFileWriter_1_tLibraryLoad_3", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tLibraryLoad_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:DSMFileWriter_1_tLibraryLoad_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							DSMFileWriter_1_tLibraryLoad_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_3 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_3";

	

 



/**
 * [DSMFileWriter_1_tLibraryLoad_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMFileWriter_1_tLibraryLoad_3_SUBPROCESS_STATE", 1);
	}
	

public void DSMFileWriter_1_tLibraryLoad_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMFileWriter_1_tLibraryLoad_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_4 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tLibraryLoad_4", false);
		start_Hash.put("DSMFileWriter_1_tLibraryLoad_4", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_4";

	
		int tos_count_DSMFileWriter_1_tLibraryLoad_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_4 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tLibraryLoad_4 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append("LIBRARY" + " = " + "\"google-http-client-jackson-1.17.0-rc.jar\"");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append("HOTLIBS" + " = " + "[]");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_4 - "  + log4jParamters_DSMFileWriter_1_tLibraryLoad_4 );



 



/**
 * [DSMFileWriter_1_tLibraryLoad_4 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_4 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_4";

	

 


	tos_count_DSMFileWriter_1_tLibraryLoad_4++;

/**
 * [DSMFileWriter_1_tLibraryLoad_4 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_4 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_4";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_4 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tLibraryLoad_4", true);
end_Hash.put("DSMFileWriter_1_tLibraryLoad_4", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tLibraryLoad_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:DSMFileWriter_1_tLibraryLoad_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							DSMFileWriter_1_tLibraryLoad_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_4 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_4";

	

 



/**
 * [DSMFileWriter_1_tLibraryLoad_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMFileWriter_1_tLibraryLoad_4_SUBPROCESS_STATE", 1);
	}
	

public void DSMFileWriter_1_tLibraryLoad_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMFileWriter_1_tLibraryLoad_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_5 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tLibraryLoad_5", false);
		start_Hash.put("DSMFileWriter_1_tLibraryLoad_5", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_5";

	
		int tos_count_DSMFileWriter_1_tLibraryLoad_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_5 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tLibraryLoad_5 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append("LIBRARY" + " = " + "\"google-http-client-1.17.0-rc.jar\"");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append("HOTLIBS" + " = " + "[]");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_5 - "  + log4jParamters_DSMFileWriter_1_tLibraryLoad_5 );



 



/**
 * [DSMFileWriter_1_tLibraryLoad_5 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_5 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_5";

	

 


	tos_count_DSMFileWriter_1_tLibraryLoad_5++;

/**
 * [DSMFileWriter_1_tLibraryLoad_5 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_5 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_5";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_5 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tLibraryLoad_5", true);
end_Hash.put("DSMFileWriter_1_tLibraryLoad_5", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tLibraryLoad_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:DSMFileWriter_1_tLibraryLoad_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							DSMFileWriter_1_tLibraryLoad_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_5 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_5";

	

 



/**
 * [DSMFileWriter_1_tLibraryLoad_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMFileWriter_1_tLibraryLoad_5_SUBPROCESS_STATE", 1);
	}
	

public void DSMFileWriter_1_tLibraryLoad_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("DSMFileWriter_1_tLibraryLoad_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_6 begin ] start
	 */

	

	
		
		ok_Hash.put("DSMFileWriter_1_tLibraryLoad_6", false);
		start_Hash.put("DSMFileWriter_1_tLibraryLoad_6", System.currentTimeMillis());
		
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_6";

	
		int tos_count_DSMFileWriter_1_tLibraryLoad_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_6 - "  + "Start to work." );
            StringBuilder log4jParamters_DSMFileWriter_1_tLibraryLoad_6 = new StringBuilder();
            log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append("Parameters:");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append("LIBRARY" + " = " + "\"dsm-client-2.0.0-SNAPSHOT.jar\"");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append("HOTLIBS" + " = " + "[]");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append(" | ");
                    log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_DSMFileWriter_1_tLibraryLoad_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_6 - "  + log4jParamters_DSMFileWriter_1_tLibraryLoad_6 );



 



/**
 * [DSMFileWriter_1_tLibraryLoad_6 begin ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_6 main ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_6";

	

 


	tos_count_DSMFileWriter_1_tLibraryLoad_6++;

/**
 * [DSMFileWriter_1_tLibraryLoad_6 main ] stop
 */
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_6 end ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_6";

	

 
                if(log.isDebugEnabled())
            log.debug("DSMFileWriter_1_tLibraryLoad_6 - "  + "Done." );

ok_Hash.put("DSMFileWriter_1_tLibraryLoad_6", true);
end_Hash.put("DSMFileWriter_1_tLibraryLoad_6", System.currentTimeMillis());




/**
 * [DSMFileWriter_1_tLibraryLoad_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:DSMFileWriter_1_tLibraryLoad_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
							DSMFileWriter_1_tLibraryLoad_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [DSMFileWriter_1_tLibraryLoad_6 finally ] start
	 */

	

	
	
	currentComponent="DSMFileWriter_1_tLibraryLoad_6";

	

 



/**
 * [DSMFileWriter_1_tLibraryLoad_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("DSMFileWriter_1_tLibraryLoad_6_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_row7Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row7Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1 implements routines.system.IPersistableRow<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_contextOutStruct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_contextOutStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_contextOutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_row4Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row4Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tContextDump_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		EtlcCallbackDSMCollection_1_row4Struct EtlcCallbackDSMCollection_1_row4 = new EtlcCallbackDSMCollection_1_row4Struct();
EtlcCallbackDSMCollection_1_contextOutStruct EtlcCallbackDSMCollection_1_contextOut = new EtlcCallbackDSMCollection_1_contextOutStruct();
EtlcCallbackDSMCollection_1_row7Struct EtlcCallbackDSMCollection_1_row7 = new EtlcCallbackDSMCollection_1_row7Struct();





	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";

	
		int tos_count_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.append("DESTINATION" + " = " + "EtlcCallbackDSMCollection_1_tDenormalize_1");
                log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.append("DENORMALIZE_COLUMNS" + " = " + "[{MERGE="+("false")+", INPUT_COLUMN="+("context")+", DELIMITER="+("\"\\\",\\\"\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut - "  + log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut );

class DenormalizeStructEtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut {
StringBuilder context = new StringBuilder();
}
DenormalizeStructEtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut = null;

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tMap_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tMap_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tMap_1 );




// ###############################
// # Lookup's keys initialization
		int count_EtlcCallbackDSMCollection_1_row4_EtlcCallbackDSMCollection_1_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
// ###############################

// ###############################
// # Outputs initialization
				int count_EtlcCallbackDSMCollection_1_contextOut_EtlcCallbackDSMCollection_1_tMap_1 = 0;
				
EtlcCallbackDSMCollection_1_contextOutStruct EtlcCallbackDSMCollection_1_contextOut_tmp = new EtlcCallbackDSMCollection_1_contextOutStruct();
// ###############################

        
        



        









 



/**
 * [EtlcCallbackDSMCollection_1_tMap_1 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tContextDump_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_1.append("HIDE_PASSWORD" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_1 );
        int nb_line_EtlcCallbackDSMCollection_1_tContextDump_1 = 0;
        java.util.List<String> assignList_EtlcCallbackDSMCollection_1_tContextDump_1 = new java.util.ArrayList<String>();
        	log.info("EtlcCallbackDSMCollection_1_tContextDump_1 - Dumping context.");
        for( java.util.Enumeration<?> en_EtlcCallbackDSMCollection_1_tContextDump_1 = context.propertyNames() ; en_EtlcCallbackDSMCollection_1_tContextDump_1.hasMoreElements() ; ) {        
            nb_line_EtlcCallbackDSMCollection_1_tContextDump_1++;
            Object key_EtlcCallbackDSMCollection_1_tContextDump_1 = en_EtlcCallbackDSMCollection_1_tContextDump_1.nextElement();
            Object value_EtlcCallbackDSMCollection_1_tContextDump_1 = context.getProperty(key_EtlcCallbackDSMCollection_1_tContextDump_1.toString());
                    EtlcCallbackDSMCollection_1_row4.key = key_EtlcCallbackDSMCollection_1_tContextDump_1.toString();
                    EtlcCallbackDSMCollection_1_row4.value = value_EtlcCallbackDSMCollection_1_tContextDump_1.toString();
					
							if(("endDate").equals(key_EtlcCallbackDSMCollection_1_tContextDump_1.toString())){
								if(value_EtlcCallbackDSMCollection_1_tContextDump_1.toString().indexOf(";")>-1){
			                    	EtlcCallbackDSMCollection_1_row4.value = value_EtlcCallbackDSMCollection_1_tContextDump_1.toString().substring(value_EtlcCallbackDSMCollection_1_tContextDump_1.toString().indexOf(";")+1);
			                    }
			                }
						
					
					
					
					
					
					
					
					
					
					
					

 



/**
 * [EtlcCallbackDSMCollection_1_tContextDump_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_1";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tContextDump_1++;

/**
 * [EtlcCallbackDSMCollection_1_tContextDump_1 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row4 - " + (EtlcCallbackDSMCollection_1_row4==null? "": EtlcCallbackDSMCollection_1_row4.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_EtlcCallbackDSMCollection_1_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_1 = false;
		  boolean mainRowRejected_EtlcCallbackDSMCollection_1_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        // ###############################
        // ###############################
        // # Output tables

EtlcCallbackDSMCollection_1_contextOut = null;


// # Output table : 'EtlcCallbackDSMCollection_1_contextOut'
count_EtlcCallbackDSMCollection_1_contextOut_EtlcCallbackDSMCollection_1_tMap_1++;

EtlcCallbackDSMCollection_1_contextOut_tmp.context = EtlcCallbackDSMCollection_1_row4.key +"\":\""+ EtlcCallbackDSMCollection_1_row4.value.replace("\\","/")  ;
EtlcCallbackDSMCollection_1_contextOut = EtlcCallbackDSMCollection_1_contextOut_tmp;
log.debug("EtlcCallbackDSMCollection_1_tMap_1 - Outputting the record " + count_EtlcCallbackDSMCollection_1_contextOut_EtlcCallbackDSMCollection_1_tMap_1 + " of the output table 'EtlcCallbackDSMCollection_1_contextOut'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_1 = false;










 


	tos_count_EtlcCallbackDSMCollection_1_tMap_1++;

/**
 * [EtlcCallbackDSMCollection_1_tMap_1 main ] stop
 */
// Start of branch "EtlcCallbackDSMCollection_1_contextOut"
if(EtlcCallbackDSMCollection_1_contextOut != null) { 



	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut main ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_contextOut - " + (EtlcCallbackDSMCollection_1_contextOut==null? "": EtlcCallbackDSMCollection_1_contextOut.toLogString()));
    			}
    		

if(denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut == null){
	denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut = new DenormalizeStructEtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut();		
	denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.context.append(EtlcCallbackDSMCollection_1_contextOut.context);
			
}else{		
	denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.context.append("\",\"").append(EtlcCallbackDSMCollection_1_contextOut.context);
			
}

 


	tos_count_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut++;

/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut main ] stop
 */

} // End of branch "EtlcCallbackDSMCollection_1_contextOut"







	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_1";

	

        }
        globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_1_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tContextDump_1);
        	log.info("EtlcCallbackDSMCollection_1_tContextDump_1 - Dumped contexts count: " + nb_line_EtlcCallbackDSMCollection_1_tContextDump_1 + ".");
 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tContextDump_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("EtlcCallbackDSMCollection_1_tMap_1 - Written records count in the table 'EtlcCallbackDSMCollection_1_contextOut': " + count_EtlcCallbackDSMCollection_1_contextOut_EtlcCallbackDSMCollection_1_tMap_1 + ".");





 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tMap_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tMap_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut end ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";

	
java.util.List<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1> result_list_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut = new java.util.ArrayList<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1>();
if (denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut != null) {
//generate result begin
	OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1 denormalize_row_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut = new OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1();
                
	denormalize_row_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.context = denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.context.toString();
	
	//in the deepest end
	
	result_list_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.add(denormalize_row_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut);

}
//generate result end
globalMap.put("EtlcCallbackDSMCollection_1_tDenormalize_1", result_list_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut);
globalMap.put("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut_NB_LINE", result_list_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.size()); 
	log.info("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut - Generated records count: " + result_list_EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut.size() + " .");

        


 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut end ] stop
 */


	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row7", false);
		start_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row7", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row7";

	
		int tos_count_tAdvancedHash_EtlcCallbackDSMCollection_1_row7 = 0;
		

			   		// connection name:EtlcCallbackDSMCollection_1_row7
			   		// source node:EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn - inputs:(OnRowsEnd) outputs:(EtlcCallbackDSMCollection_1_row7,EtlcCallbackDSMCollection_1_row7) | target node:tAdvancedHash_EtlcCallbackDSMCollection_1_row7 - inputs:(EtlcCallbackDSMCollection_1_row7) outputs:()
			   		// linked node: EtlcCallbackDSMCollection_1_tMap_2 - inputs:(EtlcCallbackDSMCollection_1_row1,EtlcCallbackDSMCollection_1_row7) outputs:(EtlcCallbackDSMCollection_1_successOut)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_EtlcCallbackDSMCollection_1_row7 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row7Struct> tHash_Lookup_EtlcCallbackDSMCollection_1_row7 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<EtlcCallbackDSMCollection_1_row7Struct>getLookup(matchingModeEnum_EtlcCallbackDSMCollection_1_row7);
	   						   
		   	   	   globalMap.put("tHash_Lookup_EtlcCallbackDSMCollection_1_row7", tHash_Lookup_EtlcCallbackDSMCollection_1_row7);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";

	
		int tos_count_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn = 0;
		

        
        int nb_line_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn = 0;
        java.util.List<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1> list_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn = (java.util.List<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1>)globalMap.get("EtlcCallbackDSMCollection_1_tDenormalize_1");
        if(list_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn == null) {
            list_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn = new java.util.ArrayList<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1>();
        }        
        for(OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_1 row_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn : list_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn){
        					
    						EtlcCallbackDSMCollection_1_row7.context = row_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn.context;
    						

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn main ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn++;

/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn main ] stop
 */

	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row7";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row7 - " + (EtlcCallbackDSMCollection_1_row7==null? "": EtlcCallbackDSMCollection_1_row7.toLogString()));
    			}
    		


			   
			   

					EtlcCallbackDSMCollection_1_row7Struct EtlcCallbackDSMCollection_1_row7_HashRow = new EtlcCallbackDSMCollection_1_row7Struct();
		   	   	   
				
				EtlcCallbackDSMCollection_1_row7_HashRow.context = EtlcCallbackDSMCollection_1_row7.context;
				
			tHash_Lookup_EtlcCallbackDSMCollection_1_row7.put(EtlcCallbackDSMCollection_1_row7_HashRow);
			
            




 


	tos_count_tAdvancedHash_EtlcCallbackDSMCollection_1_row7++;

/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 main ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn end ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";

	
	nb_line_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn++;
}
globalMap.put("EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn);
 

ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn end ] stop
 */

	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row7";

	

tHash_Lookup_EtlcCallbackDSMCollection_1_row7.endPut();

 

ok_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row7", true);
end_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row7", System.currentTimeMillis());




/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 end ] stop
 */












				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
							//free memory for "EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn"
							globalMap.remove("EtlcCallbackDSMCollection_1_tDenormalize_1");
						
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tContextDump_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tMap_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_DenormalizeOut finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_1_ArrayIn finally ] stop
 */

	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row7";

	

 



/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row7 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_1_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_errorOutStruct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_errorOutStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String error;

				public String getError () {
					return this.error;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.error = readString(dis);
					
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.error,dos);
					
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("error="+error);
		sb.append(",context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(error == null){
        					sb.append("<null>");
        				}else{
            				sb.append(error);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_errorOutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_row5Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row5Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_row3Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row3Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class after_EtlcCallbackDSMCollection_1_tLogCatcher_1Struct implements routines.system.IPersistableRow<after_EtlcCallbackDSMCollection_1_tLogCatcher_1Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(after_EtlcCallbackDSMCollection_1_tLogCatcher_1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;


		EtlcCallbackDSMCollection_1_tContextDump_2Process(globalMap);

		EtlcCallbackDSMCollection_1_row3Struct EtlcCallbackDSMCollection_1_row3 = new EtlcCallbackDSMCollection_1_row3Struct();
EtlcCallbackDSMCollection_1_row5Struct EtlcCallbackDSMCollection_1_row5 = new EtlcCallbackDSMCollection_1_row5Struct();
EtlcCallbackDSMCollection_1_errorOutStruct EtlcCallbackDSMCollection_1_errorOut = new EtlcCallbackDSMCollection_1_errorOutStruct();






	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_4", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_4";

	
		int tos_count_EtlcCallbackDSMCollection_1_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_4 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_4 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_4.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("\"{\\\"details\\\":{\\\"time\\\":\\\"\"+TalendDate.formatDate(\"yyyy-MM-dd HH:mm:ss\",TalendDate.getCurrentDate())+\"\\\",\\\"result\\\":\\\"error\\\"\"+EtlcCallbackDSMCollection_1_errorOut.error+EtlcCallbackDSMCollection_1_errorOut.context+\"}}\"")+", KEY="+("\"errorResponse\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_4 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tSetGlobalVar_4 );

 



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_5 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_5", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tMap_5", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_5";

	
		int tos_count_EtlcCallbackDSMCollection_1_tMap_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_5 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tMap_5 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_5 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tMap_5 );




// ###############################
// # Lookup's keys initialization
		int count_EtlcCallbackDSMCollection_1_row5_EtlcCallbackDSMCollection_1_tMap_5 = 0;
		
		int count_EtlcCallbackDSMCollection_1_row8_EtlcCallbackDSMCollection_1_tMap_5 = 0;
		
	
		org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row8Struct> tHash_Lookup_EtlcCallbackDSMCollection_1_row8 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row8Struct>) 
				((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row8Struct>) 
					globalMap.get( "tHash_Lookup_EtlcCallbackDSMCollection_1_row8" ))
					;					
					
	
		tHash_Lookup_EtlcCallbackDSMCollection_1_row8.initGet();
	

EtlcCallbackDSMCollection_1_row8Struct EtlcCallbackDSMCollection_1_row8HashKey = new EtlcCallbackDSMCollection_1_row8Struct();
EtlcCallbackDSMCollection_1_row8Struct EtlcCallbackDSMCollection_1_row8Default = new EtlcCallbackDSMCollection_1_row8Struct();
// ###############################        

// ###############################
// # Vars initialization
// ###############################

// ###############################
// # Outputs initialization
				int count_EtlcCallbackDSMCollection_1_errorOut_EtlcCallbackDSMCollection_1_tMap_5 = 0;
				
EtlcCallbackDSMCollection_1_errorOutStruct EtlcCallbackDSMCollection_1_errorOut_tmp = new EtlcCallbackDSMCollection_1_errorOutStruct();
// ###############################

        
        



        









 



/**
 * [EtlcCallbackDSMCollection_1_tMap_5 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tFilterRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tFilterRow_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tFilterRow_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tFilterRow_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tFilterRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tFilterRow_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append("LOGICAL_OP" + " = " + "&&");
                log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append("CONDITIONS" + " = " + "[{OPERATOR="+(">")+", RVALUE="+("3")+", INPUT_COLUMN="+("priority")+", FUNCTION="+("")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append("USE_ADVANCED" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tFilterRow_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tFilterRow_1 );
    int nb_line_EtlcCallbackDSMCollection_1_tFilterRow_1 = 0;
    int nb_line_ok_EtlcCallbackDSMCollection_1_tFilterRow_1 = 0;
    int nb_line_reject_EtlcCallbackDSMCollection_1_tFilterRow_1 = 0;

    class Operator_EtlcCallbackDSMCollection_1_tFilterRow_1 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_EtlcCallbackDSMCollection_1_tFilterRow_1(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [EtlcCallbackDSMCollection_1_tFilterRow_1 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogCatcher_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append("CATCH_TDIE" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogCatcher_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_1 );

	for (LogCatcherUtils.LogCatcherMessage lcm : EtlcCallbackDSMCollection_1_tLogCatcher_1.getMessages()) {
		EtlcCallbackDSMCollection_1_row3.type = lcm.getType();
		EtlcCallbackDSMCollection_1_row3.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		EtlcCallbackDSMCollection_1_row3.priority = lcm.getPriority();
		EtlcCallbackDSMCollection_1_row3.message = lcm.getMessage();
		EtlcCallbackDSMCollection_1_row3.code = lcm.getCode();
		
		EtlcCallbackDSMCollection_1_row3.moment = java.util.Calendar.getInstance().getTime();
	
    	EtlcCallbackDSMCollection_1_row3.pid = pid;
		EtlcCallbackDSMCollection_1_row3.root_pid = rootPid;
		EtlcCallbackDSMCollection_1_row3.father_pid = fatherPid;
	
    	EtlcCallbackDSMCollection_1_row3.project = projectName;
    	EtlcCallbackDSMCollection_1_row3.job = jobName;
    	EtlcCallbackDSMCollection_1_row3.context = contextStr;
    		
 



/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_1";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tLogCatcher_1++;

/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tFilterRow_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tFilterRow_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row3 - " + (EtlcCallbackDSMCollection_1_row3==null? "": EtlcCallbackDSMCollection_1_row3.toLogString()));
    			}
    		

          EtlcCallbackDSMCollection_1_row5 = null;
    Operator_EtlcCallbackDSMCollection_1_tFilterRow_1 ope_EtlcCallbackDSMCollection_1_tFilterRow_1 = new Operator_EtlcCallbackDSMCollection_1_tFilterRow_1("&&");
            ope_EtlcCallbackDSMCollection_1_tFilterRow_1.matches((EtlcCallbackDSMCollection_1_row3.priority == null? false : EtlcCallbackDSMCollection_1_row3.priority.compareTo(ParserUtils.parseTo_Integer(String.valueOf(3))) > 0)
                           , "priority.compareTo(3) > 0 failed");
		 	
    
    if (ope_EtlcCallbackDSMCollection_1_tFilterRow_1.getMatchFlag()) {
              if(EtlcCallbackDSMCollection_1_row5 == null){ 
                EtlcCallbackDSMCollection_1_row5 = new EtlcCallbackDSMCollection_1_row5Struct();
              }
               EtlcCallbackDSMCollection_1_row5.moment = EtlcCallbackDSMCollection_1_row3.moment;
               EtlcCallbackDSMCollection_1_row5.pid = EtlcCallbackDSMCollection_1_row3.pid;
               EtlcCallbackDSMCollection_1_row5.root_pid = EtlcCallbackDSMCollection_1_row3.root_pid;
               EtlcCallbackDSMCollection_1_row5.father_pid = EtlcCallbackDSMCollection_1_row3.father_pid;
               EtlcCallbackDSMCollection_1_row5.project = EtlcCallbackDSMCollection_1_row3.project;
               EtlcCallbackDSMCollection_1_row5.job = EtlcCallbackDSMCollection_1_row3.job;
               EtlcCallbackDSMCollection_1_row5.context = EtlcCallbackDSMCollection_1_row3.context;
               EtlcCallbackDSMCollection_1_row5.priority = EtlcCallbackDSMCollection_1_row3.priority;
               EtlcCallbackDSMCollection_1_row5.type = EtlcCallbackDSMCollection_1_row3.type;
               EtlcCallbackDSMCollection_1_row5.origin = EtlcCallbackDSMCollection_1_row3.origin;
               EtlcCallbackDSMCollection_1_row5.message = EtlcCallbackDSMCollection_1_row3.message;
               EtlcCallbackDSMCollection_1_row5.code = EtlcCallbackDSMCollection_1_row3.code;
					log.debug("EtlcCallbackDSMCollection_1_tFilterRow_1 - Process the record " + (nb_line_EtlcCallbackDSMCollection_1_tFilterRow_1+1) + ".");
					    
      nb_line_ok_EtlcCallbackDSMCollection_1_tFilterRow_1++;
    } else {
      nb_line_reject_EtlcCallbackDSMCollection_1_tFilterRow_1++;
    }

nb_line_EtlcCallbackDSMCollection_1_tFilterRow_1++;

 


	tos_count_EtlcCallbackDSMCollection_1_tFilterRow_1++;

/**
 * [EtlcCallbackDSMCollection_1_tFilterRow_1 main ] stop
 */
// Start of branch "EtlcCallbackDSMCollection_1_row5"
if(EtlcCallbackDSMCollection_1_row5 != null) { 



	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_5 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_5";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row5 - " + (EtlcCallbackDSMCollection_1_row5==null? "": EtlcCallbackDSMCollection_1_row5.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_EtlcCallbackDSMCollection_1_tMap_5 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_5 = false;
		  boolean mainRowRejected_EtlcCallbackDSMCollection_1_tMap_5 = false;
            				    								  
		

				///////////////////////////////////////////////
				// Starting Lookup Table "EtlcCallbackDSMCollection_1_row8" 
				///////////////////////////////////////////////


				
				
                            
 					    boolean forceLoopEtlcCallbackDSMCollection_1_row8 = false;
       		  	    	
       		  	    	
 							EtlcCallbackDSMCollection_1_row8Struct EtlcCallbackDSMCollection_1_row8ObjectFromLookup = null;
                          
		           		  	if(!rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_5) { // G_TM_M_020

								

								
	  					
	  							
			  					
			  					
	  					
		  							tHash_Lookup_EtlcCallbackDSMCollection_1_row8.lookup( EtlcCallbackDSMCollection_1_row8HashKey );

	  							

	  							

 								
								  
								  if(!tHash_Lookup_EtlcCallbackDSMCollection_1_row8.hasNext()) { // G_TM_M_090

  								
		  				
	  								
						
									
	
		  								forceLoopEtlcCallbackDSMCollection_1_row8 = true;
	  					
  									
  									  		
 								
								  
								  } // G_TM_M_090

  								



							} // G_TM_M_020
			           		  	  
							
								
								else { // G 20 - G 21
   									forceLoopEtlcCallbackDSMCollection_1_row8 = true;
			           		  	} // G 21
                    		  	
                    		

							EtlcCallbackDSMCollection_1_row8Struct EtlcCallbackDSMCollection_1_row8 = null;
                    		  	 
							

								while ((tHash_Lookup_EtlcCallbackDSMCollection_1_row8 != null && tHash_Lookup_EtlcCallbackDSMCollection_1_row8.hasNext()) || forceLoopEtlcCallbackDSMCollection_1_row8) { // G_TM_M_043

								
									 // CALL close loop of lookup 'EtlcCallbackDSMCollection_1_row8'
									
                    		  	 
							   
                    		  	 
	       		  	    	EtlcCallbackDSMCollection_1_row8Struct fromLookup_EtlcCallbackDSMCollection_1_row8 = null;
							EtlcCallbackDSMCollection_1_row8 = EtlcCallbackDSMCollection_1_row8Default;
										 
							
								
								if(!forceLoopEtlcCallbackDSMCollection_1_row8) { // G 46
								
							
								 
							
								
								fromLookup_EtlcCallbackDSMCollection_1_row8 = tHash_Lookup_EtlcCallbackDSMCollection_1_row8.next();

							

							if(fromLookup_EtlcCallbackDSMCollection_1_row8 != null) {
								EtlcCallbackDSMCollection_1_row8 = fromLookup_EtlcCallbackDSMCollection_1_row8;
							}
							
							
							
			  							
								
	                    		  	
		                    
	                    	
	                    		} // G 46
	                    		  	
								forceLoopEtlcCallbackDSMCollection_1_row8 = false;
									 	
							
	            	
	            	
	            // ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        // ###############################
        // ###############################
        // # Output tables

EtlcCallbackDSMCollection_1_errorOut = null;


// # Output table : 'EtlcCallbackDSMCollection_1_errorOut'
count_EtlcCallbackDSMCollection_1_errorOut_EtlcCallbackDSMCollection_1_tMap_5++;

EtlcCallbackDSMCollection_1_errorOut_tmp.error = ",\"error\":{\"project\":\""+EtlcCallbackDSMCollection_1_row5.project+"\",\"job\" : \""+EtlcCallbackDSMCollection_1_row5.job+"\",\"component\" : \""+EtlcCallbackDSMCollection_1_row5.origin+"\",\"message\":\""+EtlcCallbackDSMCollection_1_row5.message.replace("\\","/").replace("\"","")+"\",\"code\":\""+EtlcCallbackDSMCollection_1_row5.code.toString()+"\"}"     ;
EtlcCallbackDSMCollection_1_errorOut_tmp.context = ",\"context\":{\"" + EtlcCallbackDSMCollection_1_row8.context + "\"}" ;
EtlcCallbackDSMCollection_1_errorOut = EtlcCallbackDSMCollection_1_errorOut_tmp;
log.debug("EtlcCallbackDSMCollection_1_tMap_5 - Outputting the record " + count_EtlcCallbackDSMCollection_1_errorOut_EtlcCallbackDSMCollection_1_tMap_5 + " of the output table 'EtlcCallbackDSMCollection_1_errorOut'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_5 = false;










 


	tos_count_EtlcCallbackDSMCollection_1_tMap_5++;

/**
 * [EtlcCallbackDSMCollection_1_tMap_5 main ] stop
 */
// Start of branch "EtlcCallbackDSMCollection_1_errorOut"
if(EtlcCallbackDSMCollection_1_errorOut != null) { 



	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_4";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_errorOut - " + (EtlcCallbackDSMCollection_1_errorOut==null? "": EtlcCallbackDSMCollection_1_errorOut.toLogString()));
    			}
    		

globalMap.put("errorResponse", "{\"details\":{\"time\":\""+TalendDate.formatDate("yyyy-MM-dd HH:mm:ss",TalendDate.getCurrentDate())+"\",\"result\":\"error\""+EtlcCallbackDSMCollection_1_errorOut.error+EtlcCallbackDSMCollection_1_errorOut.context+"}}");

 


	tos_count_EtlcCallbackDSMCollection_1_tSetGlobalVar_4++;

/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 main ] stop
 */

} // End of branch "EtlcCallbackDSMCollection_1_errorOut"



	
		} // close loop of lookup 'EtlcCallbackDSMCollection_1_row8' // G_TM_M_043
	

} // End of branch "EtlcCallbackDSMCollection_1_row5"







	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_1";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogCatcher_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tFilterRow_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tFilterRow_1";

	
    globalMap.put("EtlcCallbackDSMCollection_1_tFilterRow_1_NB_LINE", nb_line_EtlcCallbackDSMCollection_1_tFilterRow_1);
    globalMap.put("EtlcCallbackDSMCollection_1_tFilterRow_1_NB_LINE_OK", nb_line_ok_EtlcCallbackDSMCollection_1_tFilterRow_1);
    globalMap.put("EtlcCallbackDSMCollection_1_tFilterRow_1_NB_LINE_REJECT", nb_line_reject_EtlcCallbackDSMCollection_1_tFilterRow_1);
    
    	log.info("EtlcCallbackDSMCollection_1_tFilterRow_1 - Processed records count:" + nb_line_EtlcCallbackDSMCollection_1_tFilterRow_1 + ". Matched records count:" + nb_line_ok_EtlcCallbackDSMCollection_1_tFilterRow_1 + ". Rejected records count:" + nb_line_reject_EtlcCallbackDSMCollection_1_tFilterRow_1 + ".");

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tFilterRow_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tFilterRow_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tFilterRow_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tFilterRow_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_5 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_5";

	


// ###############################
// # Lookup hashes releasing
					if(tHash_Lookup_EtlcCallbackDSMCollection_1_row8 != null) {
						tHash_Lookup_EtlcCallbackDSMCollection_1_row8.endGet();
					}
					globalMap.remove( "tHash_Lookup_EtlcCallbackDSMCollection_1_row8" );

					
					
				
// ###############################      
				log.debug("EtlcCallbackDSMCollection_1_tMap_5 - Written records count in the table 'EtlcCallbackDSMCollection_1_errorOut': " + count_EtlcCallbackDSMCollection_1_errorOut_EtlcCallbackDSMCollection_1_tMap_5 + ".");





 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_5 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_5", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tMap_5", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tMap_5 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_4";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tSetGlobalVar_4 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_4", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tSetGlobalVar_4", System.currentTimeMillis());

				EtlcCallbackDSMCollection_1_tREST_3Process(globalMap);



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
					     			//free memory for "EtlcCallbackDSMCollection_1_tMap_5"
					     			globalMap.remove("tHash_Lookup_EtlcCallbackDSMCollection_1_row8"); 
				     			
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tFilterRow_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tFilterRow_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tFilterRow_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_5 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_5";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tMap_5 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tSetGlobalVar_4";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tSetGlobalVar_4 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tREST_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tREST_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_3 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tREST_3", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tREST_3", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_3";

	
		int tos_count_EtlcCallbackDSMCollection_1_tREST_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_3 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tREST_3 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append("URL" + " = " + "context.controllerDetailsCallbackUri");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append("METHOD" + " = " + "PUT");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append("HEADERS" + " = " + "[{VALUE="+("\"application/json\"")+", NAME="+("\"Content-Type\"")+"}, {VALUE="+("((String)globalMap.get(\"errorResponse\")).length()")+", NAME="+("\"Content-Length\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append("BODY" + " = " + "((String)globalMap.get(\"errorResponse\"))");
                log4jParamters_EtlcCallbackDSMCollection_1_tREST_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_3 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tREST_3 );
	

	
	String endpoint_EtlcCallbackDSMCollection_1_tREST_3 = context.controllerDetailsCallbackUri;
	
	String trustStoreFile_EtlcCallbackDSMCollection_1_tREST_3 = System.getProperty("javax.net.ssl.trustStore");
	String trustStoreType_EtlcCallbackDSMCollection_1_tREST_3 = System.getProperty("javax.net.ssl.trustStoreType");
	String trustStorePWD_EtlcCallbackDSMCollection_1_tREST_3 = System.getProperty("javax.net.ssl.trustStorePassword");
	
	String keyStoreFile_EtlcCallbackDSMCollection_1_tREST_3 = System.getProperty("javax.net.ssl.keyStore");
	String keyStoreType_EtlcCallbackDSMCollection_1_tREST_3 = System.getProperty("javax.net.ssl.keyStoreType");
	String keyStorePWD_EtlcCallbackDSMCollection_1_tREST_3 = System.getProperty("javax.net.ssl.keyStorePassword");
	
	com.sun.jersey.api.client.config.ClientConfig config_EtlcCallbackDSMCollection_1_tREST_3 = new com.sun.jersey.api.client.config.DefaultClientConfig();
	javax.net.ssl.SSLContext ctx_EtlcCallbackDSMCollection_1_tREST_3 = javax.net.ssl.SSLContext.getInstance("SSL");
	
	javax.net.ssl.TrustManager[] tms_EtlcCallbackDSMCollection_1_tREST_3 = null;
	if(trustStoreFile_EtlcCallbackDSMCollection_1_tREST_3!=null && trustStoreType_EtlcCallbackDSMCollection_1_tREST_3!=null){
		char[] password_EtlcCallbackDSMCollection_1_tREST_3 = null;
		if(trustStorePWD_EtlcCallbackDSMCollection_1_tREST_3!=null)
			password_EtlcCallbackDSMCollection_1_tREST_3 = trustStorePWD_EtlcCallbackDSMCollection_1_tREST_3.toCharArray();
		java.security.KeyStore trustStore_EtlcCallbackDSMCollection_1_tREST_3 = java.security.KeyStore.getInstance(trustStoreType_EtlcCallbackDSMCollection_1_tREST_3);
		trustStore_EtlcCallbackDSMCollection_1_tREST_3.load(new java.io.FileInputStream(trustStoreFile_EtlcCallbackDSMCollection_1_tREST_3), password_EtlcCallbackDSMCollection_1_tREST_3);
		
		javax.net.ssl.TrustManagerFactory tmf_EtlcCallbackDSMCollection_1_tREST_3 = javax.net.ssl.TrustManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        tmf_EtlcCallbackDSMCollection_1_tREST_3.init(trustStore_EtlcCallbackDSMCollection_1_tREST_3);
        tms_EtlcCallbackDSMCollection_1_tREST_3 = tmf_EtlcCallbackDSMCollection_1_tREST_3.getTrustManagers();
	}
	
	javax.net.ssl.KeyManager[] kms_EtlcCallbackDSMCollection_1_tREST_3 = null;
	if(keyStoreFile_EtlcCallbackDSMCollection_1_tREST_3!=null && keyStoreType_EtlcCallbackDSMCollection_1_tREST_3!=null){
		char[] password_EtlcCallbackDSMCollection_1_tREST_3 = null;
		if(keyStorePWD_EtlcCallbackDSMCollection_1_tREST_3!=null)
			password_EtlcCallbackDSMCollection_1_tREST_3 = keyStorePWD_EtlcCallbackDSMCollection_1_tREST_3.toCharArray();
		java.security.KeyStore keyStore_EtlcCallbackDSMCollection_1_tREST_3 = java.security.KeyStore.getInstance(keyStoreType_EtlcCallbackDSMCollection_1_tREST_3);
		keyStore_EtlcCallbackDSMCollection_1_tREST_3.load(new java.io.FileInputStream(keyStoreFile_EtlcCallbackDSMCollection_1_tREST_3), password_EtlcCallbackDSMCollection_1_tREST_3);
		
		javax.net.ssl.KeyManagerFactory kmf_EtlcCallbackDSMCollection_1_tREST_3 = javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm());
        kmf_EtlcCallbackDSMCollection_1_tREST_3.init(keyStore_EtlcCallbackDSMCollection_1_tREST_3,password_EtlcCallbackDSMCollection_1_tREST_3);
        kms_EtlcCallbackDSMCollection_1_tREST_3 = kmf_EtlcCallbackDSMCollection_1_tREST_3.getKeyManagers();
	}
	
    ctx_EtlcCallbackDSMCollection_1_tREST_3.init(kms_EtlcCallbackDSMCollection_1_tREST_3, tms_EtlcCallbackDSMCollection_1_tREST_3 , null);
    config_EtlcCallbackDSMCollection_1_tREST_3.getProperties().put(com.sun.jersey.client.urlconnection.HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
                new com.sun.jersey.client.urlconnection.HTTPSProperties(new javax.net.ssl.HostnameVerifier() {

                    public boolean verify(String hostName, javax.net.ssl.SSLSession session) {
                        return true;
                    }
                }, ctx_EtlcCallbackDSMCollection_1_tREST_3));

	com.sun.jersey.api.client.Client restClient_EtlcCallbackDSMCollection_1_tREST_3 = com.sun.jersey.api.client.Client.create(config_EtlcCallbackDSMCollection_1_tREST_3);
	com.sun.jersey.api.client.WebResource restResource_EtlcCallbackDSMCollection_1_tREST_3;
	if(endpoint_EtlcCallbackDSMCollection_1_tREST_3!=null && !("").equals(endpoint_EtlcCallbackDSMCollection_1_tREST_3)){
		restResource_EtlcCallbackDSMCollection_1_tREST_3 = restClient_EtlcCallbackDSMCollection_1_tREST_3.resource(endpoint_EtlcCallbackDSMCollection_1_tREST_3);
	}else{
		throw new IllegalArgumentException("url can't be empty!");
	}
	
	com.sun.jersey.api.client.ClientResponse errorResponse_EtlcCallbackDSMCollection_1_tREST_3 = null;
	String restResponse_EtlcCallbackDSMCollection_1_tREST_3 = "";
	try{
		
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tREST_3 - "  + "Prepare to send request to rest server." );
		restResponse_EtlcCallbackDSMCollection_1_tREST_3 = restResource_EtlcCallbackDSMCollection_1_tREST_3
		
        	.header("Content-Type","application/json")
		
        	.header("Content-Length",((String)globalMap.get("errorResponse")).length())
		  
		
			.put(String.class,((String)globalMap.get("errorResponse")));
		
	}catch (com.sun.jersey.api.client.UniformInterfaceException ue) {
        errorResponse_EtlcCallbackDSMCollection_1_tREST_3 = ue.getResponse();
    }
	
                if(log.isInfoEnabled())
            log.info("EtlcCallbackDSMCollection_1_tREST_3 - "  + "Has sent request to rest server." );
	// for output
	

 



/**
 * [EtlcCallbackDSMCollection_1_tREST_3 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_3 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_3";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tREST_3++;

/**
 * [EtlcCallbackDSMCollection_1_tREST_3 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_3 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_3";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tREST_3 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tREST_3", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tREST_3", System.currentTimeMillis());

				EtlcCallbackDSMCollection_1_tDie_1Process(globalMap);



/**
 * [EtlcCallbackDSMCollection_1_tREST_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tREST_3 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tREST_3";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tREST_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tREST_3_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_row9Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row9Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String logOut;

				public String getLogOut () {
					return this.logOut;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.logOut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.logOut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("logOut="+logOut);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(logOut == null){
        					sb.append("<null>");
        				}else{
            				sb.append(logOut);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tRowGenerator_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tRowGenerator_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		EtlcCallbackDSMCollection_1_row9Struct EtlcCallbackDSMCollection_1_row9 = new EtlcCallbackDSMCollection_1_row9Struct();




	
	/**
	 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tFileOutputDelimited_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("USESTREAM" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("FILENAME" + " = " + "context.outputDirectory +\"/error_message.log\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("APPEND" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("INCLUDEHEADER" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("CSV_OPTION" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("CREATE" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("SPLIT" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("FLUSHONROW" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("ROW_MODE" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append("DELETE_EMPTYFILE" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 );

String fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = "";
    fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = (new java.io.File(context.outputDirectory +"/error_message.log")).getAbsolutePath().replace("\\","/");
    String fullName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = null;
    String extension_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = null;
    String directory_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = null;
    if((fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.indexOf("/") != -1)) {
        if(fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf(".") < fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf("/")) {
            fullName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1;
            extension_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = "";
        } else {
            fullName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.substring(0, fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf("."));
            extension_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.substring(fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf("."));
        }
        directory_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.substring(0, fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf("/"));
    } else {
        if(fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
            fullName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.substring(0, fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf("."));
            extension_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.substring(fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.lastIndexOf("."));
        } else {
            fullName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1;
            extension_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = "";
        }
        directory_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = "";
    }
    boolean isFileGenerated_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = true;
    java.io.File fileEtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = new java.io.File(fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);
    globalMap.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1_FILE_NAME",fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);
        if(fileEtlcCallbackDSMCollection_1_tFileOutputDelimited_1.exists()){
            isFileGenerated_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = false;
        }
            int nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = 0;
            int splitEvery_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = 1000;
            int splitedFileNo_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = 0;
            int currentRow_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = 0;

            final String OUT_DELIM_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = /** Start field EtlcCallbackDSMCollection_1_tFileOutputDelimited_1:FIELDSEPARATOR */";"/** End field EtlcCallbackDSMCollection_1_tFileOutputDelimited_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = /** Start field EtlcCallbackDSMCollection_1_tFileOutputDelimited_1:ROWSEPARATOR */"\n"/** End field EtlcCallbackDSMCollection_1_tFileOutputDelimited_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 != null && directory_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.trim().length() != 0) {
                        java.io.File dir_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = new java.io.File(directory_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);
                        if(!dir_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.exists()) {
                                log.info("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - Creating directory '" + dir_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.getCanonicalPath() +"'.");
                            dir_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.mkdirs();
                                log.info("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - The directory '"+ dir_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = null;

                        outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1, true),"UTF-8"));


        resourceMap.put("out_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1);
resourceMap.put("nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);

 



/**
 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tRowGenerator_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tRowGenerator_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tRowGenerator_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tRowGenerator_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tRowGenerator_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tRowGenerator_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tRowGenerator_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tRowGenerator_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tRowGenerator_1 );


int nb_line_EtlcCallbackDSMCollection_1_tRowGenerator_1 = 0;
int nb_max_row_EtlcCallbackDSMCollection_1_tRowGenerator_1 = 1;


class EtlcCallbackDSMCollection_1_tRowGenerator_1Randomizer {
	public String getRandomlogOut() {
		 
		return ((String)globalMap.get("errorResponse"));
		
	}
}
	EtlcCallbackDSMCollection_1_tRowGenerator_1Randomizer randEtlcCallbackDSMCollection_1_tRowGenerator_1 = new EtlcCallbackDSMCollection_1_tRowGenerator_1Randomizer();
	
    	log.info("EtlcCallbackDSMCollection_1_tRowGenerator_1 - Generating records.");
	for (int iEtlcCallbackDSMCollection_1_tRowGenerator_1=0; iEtlcCallbackDSMCollection_1_tRowGenerator_1<nb_max_row_EtlcCallbackDSMCollection_1_tRowGenerator_1 ;iEtlcCallbackDSMCollection_1_tRowGenerator_1++) {
		EtlcCallbackDSMCollection_1_row9.logOut = randEtlcCallbackDSMCollection_1_tRowGenerator_1.getRandomlogOut();
		nb_line_EtlcCallbackDSMCollection_1_tRowGenerator_1++;
		
			log.debug("EtlcCallbackDSMCollection_1_tRowGenerator_1 - Retrieving the record " + nb_line_EtlcCallbackDSMCollection_1_tRowGenerator_1 + ".");
		

 



/**
 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tRowGenerator_1";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tRowGenerator_1++;

/**
 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tFileOutputDelimited_1";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row9 - " + (EtlcCallbackDSMCollection_1_row9==null? "": EtlcCallbackDSMCollection_1_row9.toLogString()));
    			}
    		


                    StringBuilder sb_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = new StringBuilder();
                            if(EtlcCallbackDSMCollection_1_row9.logOut != null) {
                        sb_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(
                            EtlcCallbackDSMCollection_1_row9.logOut
                        );
                            }
                    sb_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);


                    nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1++;
                    resourceMap.put("nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);

                        outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1.write(sb_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1.toString());
                        log.debug("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - Writing the record " + nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 + ".");




 


	tos_count_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1++;

/**
 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 main ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tRowGenerator_1";

	

}
globalMap.put("EtlcCallbackDSMCollection_1_tRowGenerator_1_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tRowGenerator_1);
	log.info("EtlcCallbackDSMCollection_1_tRowGenerator_1 - Generated records count:" + nb_line_EtlcCallbackDSMCollection_1_tRowGenerator_1 + " .");

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tRowGenerator_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tRowGenerator_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tRowGenerator_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tFileOutputDelimited_1";

	



		
			
					if(outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1!=null) {
						outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1.flush();
						outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1.close();
					}
				
				globalMap.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);
				globalMap.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1_FILE_NAME",fileName_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", true);
	
				log.debug("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - Written records count: " + nb_line_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tFileOutputDelimited_1", System.currentTimeMillis());

				EtlcCallbackDSMCollection_1_tDie_1Process(globalMap);



/**
 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tRowGenerator_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tRowGenerator_1 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1") == null){ 
			
				
						java.io.Writer outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1 = (java.io.Writer)resourceMap.get("out_EtlcCallbackDSMCollection_1_tFileOutputDelimited_1");
						if(outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1!=null) {
							outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1.flush();
							outEtlcCallbackDSMCollection_1_tFileOutputDelimited_1.close();
						}
					
				
			
		}
	

 



/**
 * [EtlcCallbackDSMCollection_1_tFileOutputDelimited_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tRowGenerator_1_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tDie_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_1 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tDie_1", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tDie_1", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_1";

	
		int tos_count_EtlcCallbackDSMCollection_1_tDie_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDie_1 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tDie_1 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append("MESSAGE" + " = " + "\"the end is near\"");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append("CODE" + " = " + "2");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append("PRIORITY" + " = " + "6");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append("EXIT_JVM" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tDie_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDie_1 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tDie_1 );

 



/**
 * [EtlcCallbackDSMCollection_1_tDie_1 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_1 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_1";

	


				EtlcCallbackDSMCollection_1_tLogCatcher_2.addMessage("tDie", "EtlcCallbackDSMCollection_1_tDie_1", 6, "the end is near", 2);
				EtlcCallbackDSMCollection_1_tLogCatcher_2Process(globalMap);
				
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_1_DIE_PRIORITY", 6);
	System.err.println("the end is near");
	
		log.error("EtlcCallbackDSMCollection_1_tDie_1 - The die message: "+"the end is near");
	
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_1_DIE_MESSAGE", "the end is near");
	globalMap.put("EtlcCallbackDSMCollection_1_tDie_1_DIE_MESSAGES", "the end is near");
	currentComponent = "EtlcCallbackDSMCollection_1_tDie_1";
	status = "failure";
        errorCode = new Integer(2);
        globalMap.put("EtlcCallbackDSMCollection_1_tDie_1_DIE_CODE", errorCode);        
    
	if(true){	
	    throw new TDieException();
	}

 


	tos_count_EtlcCallbackDSMCollection_1_tDie_1++;

/**
 * [EtlcCallbackDSMCollection_1_tDie_1 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_1 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_1";

	

 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDie_1 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tDie_1", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tDie_1", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tDie_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDie_1 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tDie_1";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tDie_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tDie_1_SUBPROCESS_STATE", 1);
	}
	


public static class EtlcCallbackDSMCollection_1_row8Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row8Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2 implements routines.system.IPersistableRow<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_copyOfcontextOutStruct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_copyOfcontextOutStruct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String context;

				public String getContext () {
					return this.context;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.context = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.context,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("context="+context);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_copyOfcontextOutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class EtlcCallbackDSMCollection_1_row2Struct implements routines.system.IPersistableRow<EtlcCallbackDSMCollection_1_row2Struct> {
    final static byte[] commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];
    static byte[] commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length) {
				if(length < 1024 && commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties.length == 0) {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[1024];
				} else {
   					commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length);
			strReturn = new String(commonByteArray_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CLIENT_ANNTAYLOR_anntaylorInternalInventoryProperties) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(EtlcCallbackDSMCollection_1_row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void EtlcCallbackDSMCollection_1_tContextDump_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		EtlcCallbackDSMCollection_1_row2Struct EtlcCallbackDSMCollection_1_row2 = new EtlcCallbackDSMCollection_1_row2Struct();
EtlcCallbackDSMCollection_1_copyOfcontextOutStruct EtlcCallbackDSMCollection_1_copyOfcontextOut = new EtlcCallbackDSMCollection_1_copyOfcontextOutStruct();
EtlcCallbackDSMCollection_1_row8Struct EtlcCallbackDSMCollection_1_row8 = new EtlcCallbackDSMCollection_1_row8Struct();





	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";

	
		int tos_count_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.append("DESTINATION" + " = " + "EtlcCallbackDSMCollection_1_tDenormalize_2");
                log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.append("DENORMALIZE_COLUMNS" + " = " + "[{MERGE="+("false")+", INPUT_COLUMN="+("context")+", DELIMITER="+("\"\\\",\\\"\"")+"}]");
                log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut - "  + log4jParamters_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut );

class DenormalizeStructEtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut {
StringBuilder context = new StringBuilder();
}
DenormalizeStructEtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut = null;

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_3", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tMap_3", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_3";

	
		int tos_count_EtlcCallbackDSMCollection_1_tMap_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_3 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tMap_3 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tMap_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_3 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tMap_3 );




// ###############################
// # Lookup's keys initialization
		int count_EtlcCallbackDSMCollection_1_row2_EtlcCallbackDSMCollection_1_tMap_3 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
// ###############################

// ###############################
// # Outputs initialization
				int count_EtlcCallbackDSMCollection_1_copyOfcontextOut_EtlcCallbackDSMCollection_1_tMap_3 = 0;
				
EtlcCallbackDSMCollection_1_copyOfcontextOutStruct EtlcCallbackDSMCollection_1_copyOfcontextOut_tmp = new EtlcCallbackDSMCollection_1_copyOfcontextOutStruct();
// ###############################

        
        



        









 



/**
 * [EtlcCallbackDSMCollection_1_tMap_3 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tContextDump_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_2 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_2 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_2.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_2.append("HIDE_PASSWORD" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_2 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tContextDump_2 );
        int nb_line_EtlcCallbackDSMCollection_1_tContextDump_2 = 0;
        java.util.List<String> assignList_EtlcCallbackDSMCollection_1_tContextDump_2 = new java.util.ArrayList<String>();
        	log.info("EtlcCallbackDSMCollection_1_tContextDump_2 - Dumping context.");
        for( java.util.Enumeration<?> en_EtlcCallbackDSMCollection_1_tContextDump_2 = context.propertyNames() ; en_EtlcCallbackDSMCollection_1_tContextDump_2.hasMoreElements() ; ) {        
            nb_line_EtlcCallbackDSMCollection_1_tContextDump_2++;
            Object key_EtlcCallbackDSMCollection_1_tContextDump_2 = en_EtlcCallbackDSMCollection_1_tContextDump_2.nextElement();
            Object value_EtlcCallbackDSMCollection_1_tContextDump_2 = context.getProperty(key_EtlcCallbackDSMCollection_1_tContextDump_2.toString());
                    EtlcCallbackDSMCollection_1_row2.key = key_EtlcCallbackDSMCollection_1_tContextDump_2.toString();
                    EtlcCallbackDSMCollection_1_row2.value = value_EtlcCallbackDSMCollection_1_tContextDump_2.toString();
					
							if(("endDate").equals(key_EtlcCallbackDSMCollection_1_tContextDump_2.toString())){
								if(value_EtlcCallbackDSMCollection_1_tContextDump_2.toString().indexOf(";")>-1){
			                    	EtlcCallbackDSMCollection_1_row2.value = value_EtlcCallbackDSMCollection_1_tContextDump_2.toString().substring(value_EtlcCallbackDSMCollection_1_tContextDump_2.toString().indexOf(";")+1);
			                    }
			                }
						
					
					
					
					
					
					
					
					
					
					
					

 



/**
 * [EtlcCallbackDSMCollection_1_tContextDump_2 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_2";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tContextDump_2++;

/**
 * [EtlcCallbackDSMCollection_1_tContextDump_2 main ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_3 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_3";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row2 - " + (EtlcCallbackDSMCollection_1_row2==null? "": EtlcCallbackDSMCollection_1_row2.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_EtlcCallbackDSMCollection_1_tMap_3 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_3 = false;
		  boolean mainRowRejected_EtlcCallbackDSMCollection_1_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        // ###############################
        // ###############################
        // # Output tables

EtlcCallbackDSMCollection_1_copyOfcontextOut = null;


// # Output table : 'EtlcCallbackDSMCollection_1_copyOfcontextOut'
count_EtlcCallbackDSMCollection_1_copyOfcontextOut_EtlcCallbackDSMCollection_1_tMap_3++;

EtlcCallbackDSMCollection_1_copyOfcontextOut_tmp.context = EtlcCallbackDSMCollection_1_row2.key +"\":\""+ EtlcCallbackDSMCollection_1_row2.value.replace("\\","/")  ;
EtlcCallbackDSMCollection_1_copyOfcontextOut = EtlcCallbackDSMCollection_1_copyOfcontextOut_tmp;
log.debug("EtlcCallbackDSMCollection_1_tMap_3 - Outputting the record " + count_EtlcCallbackDSMCollection_1_copyOfcontextOut_EtlcCallbackDSMCollection_1_tMap_3 + " of the output table 'EtlcCallbackDSMCollection_1_copyOfcontextOut'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_EtlcCallbackDSMCollection_1_tMap_3 = false;










 


	tos_count_EtlcCallbackDSMCollection_1_tMap_3++;

/**
 * [EtlcCallbackDSMCollection_1_tMap_3 main ] stop
 */
// Start of branch "EtlcCallbackDSMCollection_1_copyOfcontextOut"
if(EtlcCallbackDSMCollection_1_copyOfcontextOut != null) { 



	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut main ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_copyOfcontextOut - " + (EtlcCallbackDSMCollection_1_copyOfcontextOut==null? "": EtlcCallbackDSMCollection_1_copyOfcontextOut.toLogString()));
    			}
    		

if(denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut == null){
	denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut = new DenormalizeStructEtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut();		
	denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.context.append(EtlcCallbackDSMCollection_1_copyOfcontextOut.context);
			
}else{		
	denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.context.append("\",\"").append(EtlcCallbackDSMCollection_1_copyOfcontextOut.context);
			
}

 


	tos_count_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut++;

/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut main ] stop
 */

} // End of branch "EtlcCallbackDSMCollection_1_copyOfcontextOut"







	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_2";

	

        }
        globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_2_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tContextDump_2);
        	log.info("EtlcCallbackDSMCollection_1_tContextDump_2 - Dumped contexts count: " + nb_line_EtlcCallbackDSMCollection_1_tContextDump_2 + ".");
 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tContextDump_2 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tContextDump_2", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tContextDump_2 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_3 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("EtlcCallbackDSMCollection_1_tMap_3 - Written records count in the table 'EtlcCallbackDSMCollection_1_copyOfcontextOut': " + count_EtlcCallbackDSMCollection_1_copyOfcontextOut_EtlcCallbackDSMCollection_1_tMap_3 + ".");





 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tMap_3 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tMap_3", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tMap_3", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tMap_3 end ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut end ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";

	
java.util.List<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2> result_list_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut = new java.util.ArrayList<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2>();
if (denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut != null) {
//generate result begin
	OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2 denormalize_row_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut = new OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2();
                
	denormalize_row_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.context = denormalize_result_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.context.toString();
	
	//in the deepest end
	
	result_list_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.add(denormalize_row_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut);

}
//generate result end
globalMap.put("EtlcCallbackDSMCollection_1_tDenormalize_2", result_list_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut);
globalMap.put("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut_NB_LINE", result_list_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.size()); 
	log.info("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut - Generated records count: " + result_list_EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut.size() + " .");

        


 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut end ] stop
 */


	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 begin ] start
	 */

	

	
		
		ok_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row8", false);
		start_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row8", System.currentTimeMillis());
		
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row8";

	
		int tos_count_tAdvancedHash_EtlcCallbackDSMCollection_1_row8 = 0;
		

			   		// connection name:EtlcCallbackDSMCollection_1_row8
			   		// source node:EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn - inputs:(OnRowsEnd) outputs:(EtlcCallbackDSMCollection_1_row8,EtlcCallbackDSMCollection_1_row8) | target node:tAdvancedHash_EtlcCallbackDSMCollection_1_row8 - inputs:(EtlcCallbackDSMCollection_1_row8) outputs:()
			   		// linked node: EtlcCallbackDSMCollection_1_tMap_5 - inputs:(EtlcCallbackDSMCollection_1_row5,EtlcCallbackDSMCollection_1_row8) outputs:(EtlcCallbackDSMCollection_1_errorOut)
			   
			   		org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_EtlcCallbackDSMCollection_1_row8 = 
			   			org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;
			   			
			   
	   			org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<EtlcCallbackDSMCollection_1_row8Struct> tHash_Lookup_EtlcCallbackDSMCollection_1_row8 =org.talend.designer.components.lookup.memory.AdvancedMemoryLookup.
	   						<EtlcCallbackDSMCollection_1_row8Struct>getLookup(matchingModeEnum_EtlcCallbackDSMCollection_1_row8);
	   						   
		   	   	   globalMap.put("tHash_Lookup_EtlcCallbackDSMCollection_1_row8", tHash_Lookup_EtlcCallbackDSMCollection_1_row8);
		   	   	   
				
           

 



/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 begin ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";

	
		int tos_count_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn = 0;
		

        
        int nb_line_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn = 0;
        java.util.List<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2> list_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn = (java.util.List<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2>)globalMap.get("EtlcCallbackDSMCollection_1_tDenormalize_2");
        if(list_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn == null) {
            list_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn = new java.util.ArrayList<OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2>();
        }        
        for(OnRowsEndStructEtlcCallbackDSMCollection_1_tDenormalize_2 row_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn : list_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn){
        					
    						EtlcCallbackDSMCollection_1_row8.context = row_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn.context;
    						

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn main ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn++;

/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn main ] stop
 */

	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 main ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row8";

	
    			if(log.isTraceEnabled()){
    				log.trace("EtlcCallbackDSMCollection_1_row8 - " + (EtlcCallbackDSMCollection_1_row8==null? "": EtlcCallbackDSMCollection_1_row8.toLogString()));
    			}
    		


			   
			   

					EtlcCallbackDSMCollection_1_row8Struct EtlcCallbackDSMCollection_1_row8_HashRow = new EtlcCallbackDSMCollection_1_row8Struct();
		   	   	   
				
				EtlcCallbackDSMCollection_1_row8_HashRow.context = EtlcCallbackDSMCollection_1_row8.context;
				
			tHash_Lookup_EtlcCallbackDSMCollection_1_row8.put(EtlcCallbackDSMCollection_1_row8_HashRow);
			
            




 


	tos_count_tAdvancedHash_EtlcCallbackDSMCollection_1_row8++;

/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 main ] stop
 */



	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn end ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";

	
	nb_line_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn++;
}
globalMap.put("EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn_NB_LINE",nb_line_EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn);
 

ok_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn", System.currentTimeMillis());




/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn end ] stop
 */

	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 end ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row8";

	

tHash_Lookup_EtlcCallbackDSMCollection_1_row8.endPut();

 

ok_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row8", true);
end_Hash.put("tAdvancedHash_EtlcCallbackDSMCollection_1_row8", System.currentTimeMillis());




/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 end ] stop
 */












				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
							//free memory for "EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn"
							globalMap.remove("EtlcCallbackDSMCollection_1_tDenormalize_2");
						
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tContextDump_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tContextDump_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tContextDump_2 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tMap_3 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tMap_3";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tMap_3 finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_DenormalizeOut finally ] stop
 */

	
	/**
	 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";
	
	currentComponent="EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tDenormalize_2_ArrayIn finally ] stop
 */

	
	/**
	 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 finally ] start
	 */

	

	
	
	currentComponent="tAdvancedHash_EtlcCallbackDSMCollection_1_row8";

	

 



/**
 * [tAdvancedHash_EtlcCallbackDSMCollection_1_row8 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tContextDump_2_SUBPROCESS_STATE", 1);
	}
	

public void EtlcCallbackDSMCollection_1_tLogCatcher_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("EtlcCallbackDSMCollection_1_tLogCatcher_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 begin ] start
	 */

	

	
		
		ok_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_2", false);
		start_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_2", System.currentTimeMillis());
		
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_2";

	
		int tos_count_EtlcCallbackDSMCollection_1_tLogCatcher_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogCatcher_2 - "  + "Start to work." );
            StringBuilder log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2 = new StringBuilder();
            log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append("Parameters:");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append(" | ");
                    log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append("CATCH_TWARN" + " = " + "false");
                log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogCatcher_2 - "  + log4jParamters_EtlcCallbackDSMCollection_1_tLogCatcher_2 );

	for (LogCatcherUtils.LogCatcherMessage lcm : EtlcCallbackDSMCollection_1_tLogCatcher_2.getMessages()) {
 



/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 begin ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 main ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_2";

	

 


	tos_count_EtlcCallbackDSMCollection_1_tLogCatcher_2++;

/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 main ] stop
 */
	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 end ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_2";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("EtlcCallbackDSMCollection_1_tLogCatcher_2 - "  + "Done." );

ok_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_2", true);
end_Hash.put("EtlcCallbackDSMCollection_1_tLogCatcher_2", System.currentTimeMillis());

   			if (globalMap.get("jobInfoWritten") == null) {
   				
    			EtlcCallbackDSMCollection_1_tJava_2Process(globalMap);
   			}

			



/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 finally ] start
	 */

	

	
	
	currentComponent="EtlcCallbackDSMCollection_1_tLogCatcher_2";

	

 



/**
 * [EtlcCallbackDSMCollection_1_tLogCatcher_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("EtlcCallbackDSMCollection_1_tLogCatcher_2_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final anntaylorInternalInventoryProperties anntaylorInternalInventoryPropertiesClass = new anntaylorInternalInventoryProperties();

        int exitCode = anntaylorInternalInventoryPropertiesClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'anntaylorInternalInventoryProperties' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'anntaylorInternalInventoryProperties' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }


        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = anntaylorInternalInventoryProperties.class.getClassLoader().getResourceAsStream("client_anntaylor/anntaylorinternalinventoryproperties_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
                context.outputDirectory=(String) context.getProperty("outputDirectory");
            try{
                String context_endDate_value = context.getProperty("endDate");
                if (context_endDate_value == null){
                    context_endDate_value = "";
                }
                int context_endDate_pos = context_endDate_value.indexOf(";");
                String context_endDate_pattern =  "yyyy-MM-dd HH:mm:ss";
                if(context_endDate_pos > -1){
                    context_endDate_pattern = context_endDate_value.substring(0, context_endDate_pos);
                    context_endDate_value = context_endDate_value.substring(context_endDate_pos + 1);
                }

                context.endDate=(java.util.Date)(new java.text.SimpleDateFormat(context_endDate_pattern).parse(context_endDate_value));

            }catch(ParseException e)
            {
                context.endDate=null;
            }
             try{
                 context.maxAllowedRejections=routines.system.ParserUtils.parseTo_Integer (context.getProperty("maxAllowedRejections"));
             }catch(NumberFormatException e){
                 context.maxAllowedRejections=null;
              }
                context.controllerFileCallbackUri=(String) context.getProperty("controllerFileCallbackUri");
                context.controllerDetailsCallbackUri=(String) context.getProperty("controllerDetailsCallbackUri");
             try{
                 context.useCallback=routines.system.ParserUtils.parseTo_Boolean (context.getProperty("useCallback"));
             }catch(NumberFormatException e){
                 context.useCallback=null;
              }
             try{
                 context.useDsm=routines.system.ParserUtils.parseTo_Boolean (context.getProperty("useDsm"));
             }catch(NumberFormatException e){
                 context.useDsm=null;
              }
                context.dsmEndPoint=(String) context.getProperty("dsmEndPoint");
                context.clientId=(String) context.getProperty("clientId");
                context.path=(String) context.getProperty("path");
                context.file=(String) context.getProperty("file");
                context.inputDirectory=(String) context.getProperty("inputDirectory");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("outputDirectory")) {
                context.outputDirectory = (String) parentContextMap.get("outputDirectory");
            }if (parentContextMap.containsKey("endDate")) {
                context.endDate = (java.util.Date) parentContextMap.get("endDate");
            }if (parentContextMap.containsKey("maxAllowedRejections")) {
                context.maxAllowedRejections = (Integer) parentContextMap.get("maxAllowedRejections");
            }if (parentContextMap.containsKey("controllerFileCallbackUri")) {
                context.controllerFileCallbackUri = (String) parentContextMap.get("controllerFileCallbackUri");
            }if (parentContextMap.containsKey("controllerDetailsCallbackUri")) {
                context.controllerDetailsCallbackUri = (String) parentContextMap.get("controllerDetailsCallbackUri");
            }if (parentContextMap.containsKey("useCallback")) {
                context.useCallback = (Boolean) parentContextMap.get("useCallback");
            }if (parentContextMap.containsKey("useDsm")) {
                context.useDsm = (Boolean) parentContextMap.get("useDsm");
            }if (parentContextMap.containsKey("dsmEndPoint")) {
                context.dsmEndPoint = (String) parentContextMap.get("dsmEndPoint");
            }if (parentContextMap.containsKey("clientId")) {
                context.clientId = (String) parentContextMap.get("clientId");
            }if (parentContextMap.containsKey("path")) {
                context.path = (String) parentContextMap.get("path");
            }if (parentContextMap.containsKey("file")) {
                context.file = (String) parentContextMap.get("file");
            }if (parentContextMap.containsKey("inputDirectory")) {
                context.inputDirectory = (String) parentContextMap.get("inputDirectory");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));




	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob




this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;DSMRetailerFileFetch_1_tFileExist_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_DSMRetailerFileFetch_1_tFileExist_1) {
globalMap.put("DSMRetailerFileFetch_1_tFileExist_1_SUBPROCESS_STATE", -1);

e_DSMRetailerFileFetch_1_tFileExist_1.printStackTrace();

}
try {
errorCode = null;DSMFileWriter_1_tLibraryLoad_6Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_DSMFileWriter_1_tLibraryLoad_6) {
globalMap.put("DSMFileWriter_1_tLibraryLoad_6_SUBPROCESS_STATE", -1);

e_DSMFileWriter_1_tLibraryLoad_6.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : anntaylorInternalInventoryProperties");
        }





    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }




		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     654795 characters generated by Talend Data Integration 
 *     on the June 11, 2018 12:24:29 AM UTC
 ************************************************************************************************/